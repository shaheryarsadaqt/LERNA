#!/usr/bin/env python3
"""LERNA Step 5 preparation, round 6: read-only facts (5 November 2026).

It writes only into --out, which must not exist. It never writes into the repository, the
environments, /raid or the Hugging Face caches. Every section is independent: a failure is
recorded in report.json and the next section still runs. Exit 0 means the report was written,
whatever it found; exit 2 means a bad argument, an existing --out or a wrong kit file.

Sections:
  prereg        the frozen PREREG_V4.md blob, saved byte for byte, its id recomputed, and the
                lines on TOST, margins, B17 and attention, plus lines 150-165
  tost_commits  the commits from the "96/96 validated" tag target to the "TOST margin 0.5 pp"
                tag targets, with their patches
  modeling_utils  lerna's transformers/modeling_utils.py against the official 4.48.3 file
  cohorts       interpreter paths and library versions recorded in archived run JSON files
  raid_listing  the top level of /raid (names, types, times), to locate the other cohorts
  hf_inventory  which models and datasets are in the local Hugging Face caches
  git_refs      refs under refs/archive and the object counts

Usage:
  python -s -B LERNA_STEP5_PREP6_FACTS.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

VERSION = "LERNA_STEP5_PREP6_FACTS 2026-11-05"
OFFICIAL_MU_SHA256 = "977e5f089928f6a4dd4db0270e411c898921c7cd6ba6d12e1c3f88a1916c5820"
PREREG_BLOB = "e689deb9727e1ae04bedcf2f1947138e0b69be01"
# "96/96 validated" tag target, then the two "TOST margin 0.5 pp" tag targets (7 Oct)
LOG_FROM = "168a8204d5ff149c9af4ea79a70f6e80ab7311fa"
COMMITS = ["ac1a952910a759f0c5650d0317bc555e811d16f4", "72b202da91e32c9a7a305b0278851abe82e8dd9b"]
ROOTS = ["/raid/stage0_real", "/raid/stage2_confirmatory", "/raid/stage2_timing", "/raid/stage2_e1",
         "/raid/stage2_e3", "/raid/stage2_e3_fixed", "/raid/sst2_replication", "/raid/smoke_forward_gate_mrpc",
         "/raid/lerna-pilot-plan-output", "/home/nanhangproj/LERNA/experiments",
         "/home/nanhangproj/LERNA/lerna-pilot-plan-output"]
KEYS = {"torch", "torch_version", "transformers", "transformers_version", "datasets", "datasets_version",
        "tokenizers", "python_version", "cuda", "cuda_version", "cudnn", "git_commit", "commit", "git_sha",
        "code_commit", "head", "executable", "sys_executable", "python_executable", "sys_prefix", "prefix"}
INTERP = re.compile(r"/bin/python[0-9.]*$")
PATTERN = re.compile(r"TOST|margin|equivalen|B17|eager|sdpa|attn_implementation|attention", re.I)
MAX_JSON_FILES = 50000
MAX_JSON_BYTES = 50 * 1024 * 1024
MAX_TEXT = 4 * 1024 * 1024


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def err(e):
    return f"{type(e).__name__}: {e}"


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args, timeout=300, text=True):
    r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, timeout=timeout, text=text)
    return r.returncode, r.stdout, r.stderr


def stamp(p):
    st = os.stat(p)
    return {"size": st.st_size, "mtime": time.strftime("%Y-%m-%d %H:%M:%S %z", time.localtime(st.st_mtime)),
            "ctime": time.strftime("%Y-%m-%d %H:%M:%S %z", time.localtime(st.st_ctime))}


# --------------------------------------------------------------------------- sections

def section_prereg(a, out):
    rc, raw, e = git(a.repo, "cat-file", "blob", a.prereg_blob, text=False)
    if rc != 0:
        return {"error": f"git cat-file failed ({rc}): {e.decode(errors='replace')[:400].strip()}"}
    name = f"PREREG_V4_{a.prereg_blob[:8]}.md"
    (out / name).write_bytes(raw)
    recomputed = hashlib.sha1(b"blob %d\0" % len(raw) + raw).hexdigest()
    lines = raw.decode("utf-8", errors="replace").splitlines()
    hits = [{"line": i + 1, "text": t[:300]} for i, t in enumerate(lines) if PATTERN.search(t)]
    window = [{"line": i + 1, "text": lines[i][:300]} for i in range(149, min(165, len(lines)))]
    return {"blob": a.prereg_blob, "saved_as": name, "bytes": len(raw), "lines": len(lines),
            "id_recomputed": recomputed, "id_matches": recomputed == a.prereg_blob,
            "matching_lines": hits[:400], "lines_150_165": window}


def section_tost_commits(a, out):
    res = {"log_from": a.log_from, "commits": {}}
    rc, o, e = git(a.repo, "log", "--format=%H %cI %s", f"{a.log_from}..{a.commits[-1]}")
    res["log"] = o.splitlines() if rc == 0 else f"git log failed ({rc}): {e[:400].strip()}"
    for c in a.commits:
        rc, o, e = git(a.repo, "show", "--format=fuller", "--stat", "--patch", c)
        if rc != 0:
            res["commits"][c] = {"error": f"git show failed ({rc}): {e[:400].strip()}"}
            continue
        name = f"commit_{c[:8]}.patch"
        (out / name).write_text(o[:MAX_TEXT])
        files = []
        rc2, o2, _ = git(a.repo, "show", "--format=", "--name-status", c)
        if rc2 == 0:
            files = o2.splitlines()
        res["commits"][c] = {"saved_as": name, "chars": len(o), "truncated": len(o) > MAX_TEXT, "files": files}
    return res


def section_modeling_utils(a, kit_file, out):
    res = {"official": str(kit_file), "official_sha256": sha256_file(kit_file), "files": {}}
    off = kit_file.read_text(encoding="utf-8").splitlines(keepends=True)
    cands = {"lerna": Path(a.lerna_prefix) / "lib/python3.10/site-packages/transformers/modeling_utils.py",
             "user_site": Path(a.local_site) / "transformers/modeling_utils.py"}
    for label, p in cands.items():
        e = {"path": str(p), "exists": p.is_file()}
        if p.is_file():
            e.update(stamp(p))
            e["sha256"] = sha256_file(p)
            e["is_official_4_48_3"] = e["sha256"] == res["official_sha256"]
            if not e["is_official_4_48_3"]:
                mine = p.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
                d = list(difflib.unified_diff(off, mine, "official-4.48.3/modeling_utils.py", f"{label}/modeling_utils.py"))
                name = f"modeling_utils_{label}_vs_official.diff"
                (out / name).write_text("".join(d))
                e.update(diff_file=name, diff_lines=len(d),
                         changed_lines=sum(1 for l in d if l[:1] in "+-" and not l.startswith(("+++", "---"))))
        res["files"][label] = e
    return res


def walk_json(obj, found, depth=0):
    if depth > 60:
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            lk = str(k).lower()
            if lk in KEYS and isinstance(v, (str, int, float)) and len(str(v)) <= 300:
                found.setdefault("keys", {}).setdefault(lk, {}).setdefault(str(v), 0)
                found["keys"][lk][str(v)] += 1
            walk_json(v, found, depth + 1)
    elif isinstance(obj, list):
        for v in obj[:100000]:
            walk_json(v, found, depth + 1)
    elif isinstance(obj, str) and len(obj) <= 300 and INTERP.search(obj):
        found.setdefault("interpreters", {}).setdefault(obj, 0)
        found["interpreters"][obj] += 1


def section_cohorts(a):
    res = {}
    for root in a.roots:
        r = {"exists": os.path.isdir(root)}
        res[root] = r
        if not r["exists"]:
            continue
        n = parsed = bad = big = 0
        mt = []
        by = {}
        truncated = False
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames.sort()
            for fn in sorted(filenames):
                if not fn.endswith(".json"):
                    continue
                p = os.path.join(dirpath, fn)
                if n >= MAX_JSON_FILES:
                    truncated = True
                    break
                n += 1
                try:
                    st = os.stat(p)
                    if st.st_size > MAX_JSON_BYTES:
                        big += 1
                        continue
                    mt.append(st.st_mtime)
                    with open(p, "rb") as f:
                        obj = json.loads(f.read().decode("utf-8", errors="replace"))
                    parsed += 1
                except Exception:
                    bad += 1
                    continue
                rel = os.path.relpath(p, root).split(os.sep)
                sub = rel[0] if len(rel) > 1 else "."
                b = by.setdefault(sub, {"files": 0})
                b["files"] += 1
                walk_json(obj, b)
            if truncated:
                break
        r.update(json_files=n, parsed=parsed, parse_errors=bad, skipped_large=big, truncated=truncated, by_subdir=by)
        if mt:
            r["mtime_min"] = time.strftime("%Y-%m-%d %H:%M %z", time.localtime(min(mt)))
            r["mtime_max"] = time.strftime("%Y-%m-%d %H:%M %z", time.localtime(max(mt)))
    return res


def section_raid_listing(a):
    rows = []
    with os.scandir(a.raid) as it:
        for d in sorted(it, key=lambda x: x.name):
            try:
                st = d.stat(follow_symlinks=False)
                row = {"name": d.name, "type": "link" if d.is_symlink() else ("dir" if d.is_dir(follow_symlinks=False) else "file"),
                       "mtime": time.strftime("%Y-%m-%d %H:%M %z", time.localtime(st.st_mtime))}
                if row["type"] == "dir":
                    try:
                        row["entries"] = len(os.listdir(d.path))
                    except Exception as e:
                        row["entries_error"] = err(e)
                rows.append(row)
            except Exception as e:
                rows.append({"name": d.name, "error": err(e)})
    return {"path": a.raid, "entries": rows}


def count_tree(p, cap=20000):
    files = size = 0
    for dirpath, _, filenames in os.walk(p, followlinks=False):
        for fn in filenames:
            files += 1
            try:
                size += os.lstat(os.path.join(dirpath, fn)).st_size
            except Exception:
                pass
            if files >= cap:
                return files, size, True
    return files, size, False


def section_hf_inventory(a):
    res = {"hub_cache": a.hub_cache, "repos": {}, "prepared_cache": a.prepared_cache, "prepared": {}}
    hubs = [Path(a.hub_cache)]
    if (Path(a.hub_cache) / "hub").is_dir():
        hubs.append(Path(a.hub_cache) / "hub")
    for hub in hubs:
        if not hub.is_dir():
            continue
        for d in sorted(hub.iterdir()):
            if not d.is_dir() or not d.name.startswith(("models--", "datasets--")):
                continue
            e = {"snapshots": {}}
            ref = d / "refs" / "main"
            if ref.is_file():
                e["refs_main"] = ref.read_text().strip()[:80]
            snaps = d / "snapshots"
            if snaps.is_dir():
                for s in sorted(snaps.iterdir()):
                    files, _, trunc = count_tree(s, cap=5000)
                    e["snapshots"][s.name] = {"files": files, "truncated": trunc}
            res["repos"][str(d.relative_to(Path(a.hub_cache)))] = e
    pc = Path(a.prepared_cache)
    if pc.is_dir():
        for name in sorted(pc.iterdir()):
            if not name.is_dir() or name.name.startswith("downloads"):
                continue
            entry = {}
            for cfg in sorted(x for x in name.iterdir() if x.is_dir()):
                for ver in sorted(x for x in cfg.iterdir() if x.is_dir()):
                    for rev in sorted(x for x in ver.iterdir() if x.is_dir()):
                        files, size, trunc = count_tree(rev, cap=5000)
                        entry[f"{cfg.name}/{ver.name}/{rev.name}"] = {"files": files, "bytes": size, "truncated": trunc}
            res["prepared"][name.name] = entry
    return res


def section_git_refs(a):
    rc, o, e = git(a.repo, "for-each-ref", "--format=%(refname) %(objecttype) %(objectname)", "refs/archive/")
    rc2, o2, _ = git(a.repo, "count-objects", "-v")
    rc3, o3, _ = git(a.repo, "rev-parse", "HEAD")
    rc4, o4, _ = git(a.repo, "status", "--porcelain")
    return {"archive_refs": o.splitlines() if rc == 0 else f"failed ({rc}): {e[:300].strip()}",
            "count_objects": o2.splitlines(), "head": o3.strip(), "status_porcelain_lines": len(o4.splitlines())}


# --------------------------------------------------------------------------- main

def glance(rep):
    L = [f"AT A GLANCE ({VERSION})"]
    p = rep.get("prereg", {})
    if "error" in p or not p:
        L.append(f"prereg: {p.get('error', 'missing')}")
    else:
        L.append(f"prereg: blob {p['blob'][:8]} saved ({p['bytes']} bytes, {p['lines']} lines); id matches: {p['id_matches']}; "
                 f"{len(p['matching_lines'])} lines mention TOST/margin/B17/attention")
    t = rep.get("tost_commits", {})
    for c, v in (t.get("commits") or {}).items():
        L.append(f"commit {c[:8]}: " + (v.get("error") or f"{len(v.get('files', []))} files changed, saved {v.get('saved_as')}"))
    if isinstance(t.get("log"), list):
        last = list((t.get("commits") or {"?": 0}).keys())[-1]
        L.append(f"commits {str(t.get('log_from'))[:8]}..{last[:8]}: {len(t['log'])}")
    m = rep.get("modeling_utils", {})
    for label, v in (m.get("files") or {}).items():
        if not v.get("exists"):
            L.append(f"modeling_utils {label}: not found")
        else:
            L.append(f"modeling_utils {label}: official={v.get('is_official_4_48_3')}"
                     + (f", {v.get('changed_lines')} changed lines" if "changed_lines" in v else "") + f", mtime {v.get('mtime')}")
    for root, v in (rep.get("cohorts") or {}).items():
        if not isinstance(v, dict) or not v.get("exists"):
            L.append(f"cohort {root}: missing")
            continue
        interp = {}
        for b in v.get("by_subdir", {}).values():
            for k, n in b.get("interpreters", {}).items():
                interp[k] = interp.get(k, 0) + n
        L.append(f"cohort {root}: {v['parsed']} JSON files read ({v['parse_errors']} unreadable); interpreters: " + (", ".join(f"{k} x{n}" for k, n in sorted(interp.items())) or "none recorded"))
    h = rep.get("hf_inventory", {})
    if h.get("repos") is not None:
        L.append("hub cache: " + ", ".join(sorted(h["repos"])))
        L.append("prepared datasets: " + ", ".join(f"{k} ({len(v)})" for k, v in sorted((h.get("prepared") or {}).items())))
    g = rep.get("git_refs", {})
    if g:
        L.append(f"git: HEAD {str(g.get('head'))[:8]}, status lines {g.get('status_porcelain_lines')}, archive refs {len(g.get('archive_refs') or [])}")
    if rep.get("section_errors"):
        L.append("section errors: " + ", ".join(sorted(rep["section_errors"])))
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--kit", default=str(Path(__file__).resolve().parent))
    ap.add_argument("--lerna-prefix", default="/new_raid/nanhangproj/conda_envs/lerna")
    ap.add_argument("--local-site", default=os.path.expanduser("~/.local/lib/python3.10/site-packages"))
    ap.add_argument("--hub-cache", default="/raid/hf_cache")
    ap.add_argument("--prepared-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--raid", default="/raid")
    ap.add_argument("--roots", nargs="*", default=ROOTS)
    ap.add_argument("--prereg-blob", default=PREREG_BLOB)
    ap.add_argument("--log-from", default=LOG_FROM)
    ap.add_argument("--commits", nargs="*", default=COMMITS)
    a = ap.parse_args()
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    kit_file = Path(a.kit) / "modeling_utils_4.48.3_official.py"
    if not kit_file.is_file() or sha256_file(kit_file) != OFFICIAL_MU_SHA256:
        print("modeling_utils_4.48.3_official.py is missing or not the issued file", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "python": sys.executable,
           "script_sha256": sha256_file(Path(__file__).resolve()), "section_errors": {}, "seconds": {}}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e)}
            rep["section_errors"][name] = err(e)
        rep["seconds"][name] = round(time.time() - t0, 1)
        save()

    section("prereg", section_prereg, a, out)
    section("tost_commits", section_tost_commits, a, out)
    section("modeling_utils", section_modeling_utils, a, kit_file, out)
    section("cohorts", section_cohorts, a)
    section("raid_listing", section_raid_listing, a)
    section("hf_inventory", section_hf_inventory, a)
    section("git_refs", section_git_refs, a)
    rep["finished"] = now()
    g = glance(rep)
    rep["glance"] = g
    save()
    (out / "glance.txt").write_text(g + "\n")
    print(g)
    return 0


if __name__ == "__main__":
    sys.exit(main())

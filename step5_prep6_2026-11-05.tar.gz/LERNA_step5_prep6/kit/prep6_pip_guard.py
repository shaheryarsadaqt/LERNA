#!/usr/bin/env python3
"""LERNA Step 5 preparation, round 6: guard for the pytest install into qwen-v100 (5 November 2026).

Run it with the target interpreter and -I, so it sees exactly that environment.

  plan   reads pip's --dry-run --report JSON. It passes (exit 0) only if exactly one package
         was requested, with the wanted name and version, and if none of the packages pip
         would install is already installed. It then writes the exact list to --out-req.
  after  compares two `pip list --format=freeze` outputs. It passes (exit 0) only if nothing
         was removed or changed and the added packages are exactly the planned list.

Exit 3 means "stop": the guard found something it doesn't allow. Exit 2 means bad arguments.
"""
import argparse
import importlib.metadata
import json
import os
import re
import sys


def norm(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def installed():
    res = {}
    for d in importlib.metadata.distributions():
        n = d.metadata["Name"]
        if n:
            res[norm(n)] = d.version
    return res


def parse_freeze(path):
    res = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if " @ " in line:
                name, ver = line.split(" @ ", 1)
            elif "==" in line:
                name, ver = line.split("==", 1)
            else:
                name, ver = line, ""
            res[norm(name.strip())] = ver.strip()
    return res


def plan(a):
    want_name, _, want_ver = a.want.partition("==")
    if not want_ver:
        print("--want must be name==version", file=sys.stderr)
        return 2
    prefix = os.path.realpath(sys.prefix)
    print(f"interpreter: {sys.executable}  prefix: {prefix}")
    if prefix != os.path.realpath(a.expect_prefix):
        print(f"STOP: this interpreter's prefix is {prefix}, not {a.expect_prefix}")
        return 3
    with open(a.report, encoding="utf-8") as f:
        rep = json.load(f)
    items = rep.get("install")
    if not isinstance(items, list) or not items:
        print("STOP: the dry-run report lists nothing to install (is the package already there?)")
        return 3
    have = installed()
    rows, requested, conflicts = [], [], []
    for it in items:
        md = it.get("metadata") or {}
        name, ver = md.get("name"), md.get("version")
        if not name or not ver:
            print(f"STOP: a report entry has no name or version: {json.dumps(it)[:300]}")
            return 3
        rows.append((norm(name), name, ver))
        if it.get("requested"):
            requested.append((norm(name), ver))
        if norm(name) in have:
            conflicts.append(f"{name}: installed {have[norm(name)]}, pip would install {ver}")
    print("pip would install: " + ", ".join(f"{n}=={v}" for _, n, v in sorted(rows)))
    if requested != [(norm(want_name), want_ver)]:
        print(f"STOP: requested packages are {requested}, expected only {want_name}=={want_ver}")
        return 3
    if conflicts:
        print("STOP: the install would change packages that are already installed:")
        for c in conflicts:
            print("  " + c)
        return 3
    with open(a.out_req, "x", encoding="utf-8") as f:
        for _, n, v in sorted(rows):
            f.write(f"{n}=={v}\n")
    print(f"OK: {len(rows)} new packages, none already installed; list written to {a.out_req}")
    return 0


def after(a):
    before, now_ = parse_freeze(a.before), parse_freeze(a.after)
    want = parse_freeze(a.req)
    removed = sorted(n for n in before if n not in now_)
    changed = sorted(f"{n}: {before[n]} -> {now_[n]}" for n in before if n in now_ and before[n] != now_[n])
    added = {n: v for n, v in now_.items() if n not in before}
    print(f"before: {len(before)} packages; after: {len(now_)}")
    print("added: " + (", ".join(f"{n}=={v}" for n, v in sorted(added.items())) or "none"))
    print("removed: " + (", ".join(removed) or "none"))
    print("changed: " + (", ".join(changed) or "none"))
    if removed or changed or added != want:
        print("STOP: the environment changed in a way the plan didn't allow")
        return 3
    print("OK: only the planned packages were added; nothing else changed")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--report", required=True)
    p.add_argument("--want", required=True)
    p.add_argument("--expect-prefix", required=True)
    p.add_argument("--out-req", required=True)
    q = sub.add_parser("after")
    q.add_argument("--before", required=True)
    q.add_argument("--after", required=True)
    q.add_argument("--req", required=True)
    a = ap.parse_args()
    try:
        return plan(a) if a.cmd == "plan" else after(a)
    except FileExistsError as e:
        print(f"STOP: {e}")
        return 3
    except (OSError, ValueError) as e:
        print(f"STOP: {type(e).__name__}: {e}")
        return 3


if __name__ == "__main__":
    sys.exit(main())

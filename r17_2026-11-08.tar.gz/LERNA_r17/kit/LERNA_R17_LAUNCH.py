#!/usr/bin/env python3
"""LERNA round 17: the second model's launcher (8 November 2026).

It runs the round fixed in claude/LERNA_R17_SECOND_MODEL_PLAN_2026-11-08.md: every method of
round 16's final comparison on a second, newer pretrained model, UltraBERT-150M
(dmis-lab/UltraBERT-150M, October 2026), on MRPC (T = 1150) and RTE (T = 780), 10 epochs, seeds 11,
13, 17, 19, 23, 29, 31, 37, 41 and 43, in qwen-v100, one GPU per run, with the round-16 recipe
(linear decay, warmup 6% of T, eager attention, FP32, batch 32, AdamW) at the learning rate the
pilot's rule chooses. 38 arms x 10 seeds x 2 tasks = 760 runs.

Before anything runs it checks the checkout (round 17's commit on round 16's), the model's pin
(MODEL_PIN.json: the commit and every file's SHA-256, all re-hashed here) and the model check
(MODEL_CHECK.json, written by LERNA_R17_MODEL_CHECK.py: PASS, on the same commit).

Stage 1, the learning-rate pilot. Full fine-tuning at 1e-5, 2e-5 and 3e-5 on MRPC and RTE, seeds
47, 53 and 59 (outside the main seeds): 18 runs. Each must pass the full fine-tuning checks. The
rule, fixed in the plan: m(lr) = the mean accuracy of the six runs at lr; keep 2e-5 (Ettin's
recipe) unless the best m is above m(2e-5) by more than 1.0 point, then take the best (ties go to
2e-5, then to the smaller rate). It writes LR_RULE.json.

Stage 2, the smoke gate. Fourteen MRPC runs at seed 11, as in round 16: the eleven compared
methods, LERNA v2 without the learning-rate factor at 60%, full fine-tuning and LERNA v1. Each is
checked (status OK, the exact counts, a final LR of 0, the chosen learning rate, the model and its
revision, and the method's own accounting). It writes SMOKE_GATE.json.

Stage 3, the other 746 runs, longest first, on every GPU.

A failed pilot or gate stops the launch (DONE.json says where). There are no retries and no seed
changes. Each GPU has one private copy of each task's prepared cache. The model is read from the
private Hub cache (--model-cache), offline.

With --resume on an existing --out it continues an interrupted launch: it skips the runs that
started, never reruns a failed run, and holds back any run that started but has no end record. A
pilot rule or a gate that already passed is not redone.

It writes only into --out, which must not exist (unless --resume):
  ds_cache/   per GPU, one private copy of each task's prepared cache, checked byte for byte
  runs/       one output folder per run
  logs/       one log per run
  plan.json, ledger.jsonl, LR_RULE.json, SMOKE_GATE.json and DONE.json

Usage:
  python -s -B LERNA_R17_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder> \\
      --model-cache <private Hub cache> --model-pin <MODEL_PIN.json> --model-check <MODEL_CHECK.json>
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R17_LAUNCH 2026-11-08"
EXPECT = {
    "parent": "8e3d0bc327035025323dbf7298ec8a702a6dea90",
    "subject": "Round 17 runner: UltraBERT, the second model, and the learning-rate option",
    "model_id": "dmis-lab/UltraBERT-150M",
}
FILES = {
    "scripts/run_controller_ablation.py": "be1c632e50a105035f8072c7cae36fba17d596f32c6554f9ad896f7700cfff1a",
    "lerna/utils/ultrabert_model.py": "cf9fc2ed533c20c4527ad83c1ba85df46b720a35c0608bb4c0021550501acc48",
    "lerna/utils/model_loader.py": "d668f28bfd7e807494c995c4a578674d7be39b72524ea02d2748458268a18fbb",
    "lerna/utils/compared_methods.py": "53f90fae4cd46a4609752ad5e7990fcae0bd378823f011060a7d1df719862031",
    "lerna/utils/budget_selection.py": "df970102a7684df4d7f054b51867b5a08077efdfa2b8e69919a0894f16b62bea",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"mrpc": "mrpc", "rte": "rte"}
SHORT = {"mrpc": "mrpc", "rte": "rte"}
TASKS = ("mrpc", "rte")
# T and W = floor(0.06 T): MRPC 115 and RTE 78 batches per epoch, 10 epochs (as in round 16)
HORIZON = {"mrpc": {"total_steps": 1150, "min_step": 69}, "rte": {"total_steps": 780, "min_step": 46}}
TRAIN_ROWS = {"mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
SEEDS = (11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
PILOT_SEEDS = (47, 53, 59)
PILOT_LRS = (1e-5, 2e-5, 3e-5)
DEFAULT_LR = 2e-5
LR_MARGIN = 1.0  # accuracy points
# controller-budgeted arms: arm -> budget
BUDGET = {"lerna2_b035": 0.35, "lerna2_nolr_b035": 0.35, "randkeep_lr_b035": 0.35, "randkeep_b035": 0.35,
          "lerna2_b040": 0.40, "randkeep_b040": 0.40, "lerna2_b060": 0.60, "lerna2_b083": 0.83,
          "randkeep_b060": 0.60, "randkeep_b083": 0.83, "el2n_topk_b035": 0.35, "el2n_topk_b060": 0.60,
          "lerna2_nolr_b040": 0.40, "lerna2_nolr_b060": 0.60, "lerna2_nolr_b083": 0.83}
TOPK = ("el2n_topk_b035", "el2n_topk_b060")
RANKED = {"egreedy_b035": (0.35, "egreedy"), "ucb_b035": (0.35, "ucb"), "orderdp_b035": (0.35, "orderdp")}
FRESH_IS = {"isfresh_b060": 0.60, "isfresh_b083": 0.83}
SB = {"sb_b060": 0.60, "sb_b083": 0.83}
DROPBP = {"dropbp_p050": 0.5, "dropbp_p0875": 0.875}
GATE_TOLERANCE = 0.005
GATES = ("gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4")
ARM_SPEC = {a: ("uniform", "legacy_v4", 1) for a in
            list(BUDGET) + list(RANKED) + list(FRESH_IS) + list(SB) + list(DROPBP)
            + ["kakurenbo", "ies", "full_finetune", "reduced_steps", "equal_compute", "plain_030", "plain_050",
               "plain_070", "infobatch"]}
ARM_SPEC.update({"gate_s1_p4": ("s1", "phase_exact_v1", 4), "control_uniform_p4": ("uniform", "phase_exact_v1", 4),
                 "gate_loss_p4": ("loss", "phase_exact_v1", 4), "stale_s1_p4": ("s1_stale", "phase_exact_v1", 4)})
VARIANTS = {"infobatch_max": ("infobatch", ["--infobatch-prune-ratio", "0.9", "--infobatch-anneal-fraction", "1.0"])}
EXISTING = ("full_finetune", "plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070",
            "gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4", "infobatch", "infobatch_max",
            "el2n_topk_b035", "el2n_topk_b060", "randkeep_b035", "randkeep_b040", "randkeep_b060", "randkeep_b083",
            "randkeep_lr_b035", "lerna2_b035", "lerna2_b040", "lerna2_b060", "lerna2_b083", "lerna2_nolr_b035")
NOLR_EXTRA = ("lerna2_nolr_b040", "lerna2_nolr_b060", "lerna2_nolr_b083")
COMPARED = ("egreedy_b035", "ucb_b035", "orderdp_b035", "isfresh_b060", "isfresh_b083", "sb_b060", "sb_b083",
            "kakurenbo", "ies", "dropbp_p050", "dropbp_p0875")
LABELS = EXISTING + NOLR_EXTRA + COMPARED  # round 16's 38 MRPC/RTE arms
SMOKE_LABELS = COMPARED + ("lerna2_nolr_b060", "full_finetune", "gate_s1_p4")
SMOKE = tuple(f"mrpc_{lab}_seed11" for lab in SMOKE_LABELS)
STEP_SECONDS = {"mrpc": 0.25, "rte": 0.5}
MIN_FREE_GB = 15
RUN_TIMEOUT = 3 * 3600


def lr_tag(lr):
    return f"lr{lr:.0e}".replace("e-0", "e-")


PILOT = tuple((f"{SHORT[t]}_pilot_full_finetune_{lr_tag(lr)}_seed{s}", t, s, lr)
              for t in TASKS for lr in PILOT_LRS for s in PILOT_SEEDS)


def relative_cost(label):
    if label == "full_finetune":
        return 1.0
    fixed = {"plain_030": 0.30, "reduced_steps": 0.40, "plain_050": 0.50, "equal_compute": 0.60, "plain_070": 0.70,
             "gate_s1_p4": 0.62, "control_uniform_p4": 0.62, "gate_loss_p4": 0.62, "stale_s1_p4": 0.52,
             "infobatch": 0.88, "infobatch_max": 0.70, "kakurenbo": 0.95, "ies": 0.90}
    if label in fixed:
        return fixed[label]
    if label in DROPBP:
        return (1.0 + 2.0 * (1.0 - DROPBP[label])) / 3.0 + 0.1
    if label in FRESH_IS or label in SB:
        return (FRESH_IS.get(label) or SB.get(label)) + 0.25
    b = BUDGET.get(label) or RANKED[label][0]
    return b + 0.18


def _entry(name, task, seed, arm_or_variant):
    arm, extra = VARIANTS.get(arm_or_variant, (arm_or_variant, []))
    return (name, task, seed, arm) + ARM_SPEC[arm] + (HORIZON[task], list(extra), arm_or_variant)


def build_plan():
    entries = [_entry(f"{SHORT[t]}_{lab}_seed{s}", t, s, lab) for t in TASKS for lab in LABELS for s in SEEDS]

    def cost(p):
        return HORIZON[p[1]]["total_steps"] * STEP_SECONDS[p[1]] * relative_cost(p[9])

    smoke = [next(p for p in entries if p[0] == n) for n in SMOKE]
    rest = sorted([p for p in entries if p[0] not in SMOKE], key=lambda p: (-cost(p), p[0]))
    return smoke + rest


def lr_rule(accuracies):
    """accuracies: {lr: [accuracy in %, ...]} over the pilot runs. Returns (choice, means, best)."""
    means = {lr: sum(v) / len(v) for lr, v in accuracies.items()}
    best = max(PILOT_LRS, key=lambda lr: (means[lr], lr == DEFAULT_LR, -lr))
    choice = best if means[best] - means[DEFAULT_LR] > LR_MARGIN else DEFAULT_LR
    return choice, means, best


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def snapshot_dir(model_cache, revision):
    return Path(model_cache) / ("models--" + EXPECT["model_id"].replace("/", "--")) / "snapshots" / revision


def command(a, rev, lr, name, task, seed, arm, source, controller, phases, horizon, extra, label):
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--learning-rate", repr(float(lr)), "--device", "cuda",
           "--model-id", EXPECT["model_id"], "--tokenizer-id", EXPECT["model_id"],
           "--model-revision", rev, "--tokenizer-revision", rev, "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    return cmd + list(extra)


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def read_manifest(out, name):
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return None, f"{len(found)} execution manifests found"
    return json.loads(found[0].read_text()), None


def common_checks(m, task, arm, lr, rev):
    """Checks every run must pass: status, counts, final LR, learning rate, model and revision."""
    T = HORIZON[task]["total_steps"]
    fails = []
    if m.get("status") != "OK":
        return [f"status {m.get('status')}: {str(m.get('reason'))[:300]}"]
    r = m.get("result", {})
    c = m.get("config", {})
    q = int(round(0.60 * T)) if arm in GATES else 0
    for k, v in (("skipped", q), ("backwards", T - q), ("forwards", T), ("forward_skipped", 0),
                 ("scheduler_advances", T), ("optimizer_updates", T - q)):
        if r.get(k) != v:
            fails.append(f"{k}={r.get(k)}, expected {v}")
    acc = r.get("final_eval_accuracy")
    if not isinstance(acc, (int, float)) or not 0.0 <= acc <= 1.0:
        fails.append(f"final_eval_accuracy={acc}")
    flr = r.get("final_learning_rate")
    if not isinstance(flr, (int, float)) or abs(flr) > 1e-12:
        fails.append(f"final_learning_rate={flr}")
    if c.get("learning_rate") != lr or r.get("learning_rate") != lr:
        fails.append(f"learning rate {c.get('learning_rate')}/{r.get('learning_rate')}, expected {lr}")
    if c.get("model_id") != EXPECT["model_id"] or c.get("model_revision") != rev or c.get("tokenizer_revision") != rev:
        fails.append(f"model {c.get('model_id')}@{c.get('model_revision')}, expected {EXPECT['model_id']}@{rev}")
    rt = m.get("runtime") or {}
    if rt.get("attn_implementation") != "eager" or rt.get("model_dtype") != "torch.float32":
        fails.append(f"runtime attention {rt.get('attn_implementation')}, dtype {rt.get('model_dtype')}")
    return fails


def gate_check(out, entry, end, lr, rev, dropbp_layers):
    """The smoke gate's checks of one run (round 16's, on the second model). [] = pass."""
    name, task, seed, arm, label = entry[0], entry[1], entry[2], entry[3], entry[9]
    T = HORIZON[task]["total_steps"]
    W = int(math.floor(0.06 * T + 1e-9))
    bpe = math.ceil(TRAIN_ROWS[task] / BATCH_SIZE)
    if end is None:
        return ["no end record (interrupted)"]
    fails = [] if end.get("exit") == 0 else [f"exit code {end.get('exit')}"]
    m, err = read_manifest(out, name)
    if m is None:
        return fails + [err]
    fails += common_checks(m, task, arm, lr, rev)
    if fails or arm in ("full_finetune",) + GATES:
        return fails
    r = m.get("result", {})
    sel = r.get("selection") or {}
    dropped = r.get("examples_dropped_before_forward")
    if not isinstance(dropped, int) or dropped != sel.get("pruned_examples"):
        fails.append(f"examples_dropped={dropped}, policy pruned={sel.get('pruned_examples')}")
    if sel.get("steps_seen") != T:
        fails.append(f"steps_seen={sel.get('steps_seen')}, expected {T}")
    ca = r.get("compute_accounting") or {}
    frac = ca.get("compute_fraction_within_arm")
    if arm in BUDGET or arm in RANKED or arm in FRESH_IS:
        budget = BUDGET.get(arm) or (RANKED.get(arm) or (None,))[0] or FRESH_IS.get(arm)
        want_policy = ("ranked_subset" if arm in RANKED else "fresh_importance_sampling" if arm in FRESH_IS
                       else "lerna_budget")
        if sel.get("policy") != want_policy:
            fails.append(f"selection policy {sel.get('policy')!r}, expected {want_policy!r}")
        want_mode = (RANKED[arm][1] if arm in RANKED else "topk" if arm in TOPK else "sample")
        if sel.get("selection") != want_mode:
            fails.append(f"selection mode {sel.get('selection')!r}, expected {want_mode!r}")
        if sel.get("budget") != budget:
            fails.append(f"budget {sel.get('budget')}, expected {budget}")
        rf = sel.get("realized_fraction")
        if not isinstance(rf, (int, float)) or abs(rf - budget) > GATE_TOLERANCE:
            fails.append(f"spent {rf} of the scheduled compute, budget {budget} +/- {GATE_TOLERANCE}")
        if sel.get("pruned_during_warmup") != 0:
            fails.append(f"pruned_during_warmup={sel.get('pruned_during_warmup')}")
        if sel.get("warmup_steps") != W:
            fails.append(f"warmup_steps={sel.get('warmup_steps')}, expected {W}")
        if not isinstance(dropped, int) or dropped <= 0:
            fails.append("no example dropped")
        if arm in FRESH_IS and sel.get("scoring_passes") != T - W:
            fails.append(f"scoring_passes={sel.get('scoring_passes')}, expected {T - W}")
        if arm in (tuple(RANKED) + tuple(FRESH_IS)) and (not isinstance(frac, (int, float)) or abs(frac - rf) > 1e-9):
            fails.append(f"compute accounting {frac} differs from the policy's {rf}")
    elif arm in SB:
        want_beta = 1.0 / (SB[arm] - 1.0 / 3.0) - 1.0
        if sel.get("policy") != "selective_backprop" or not isinstance(sel.get("beta"), (int, float)) \
                or abs(sel["beta"] - want_beta) > 1e-12:
            fails.append(f"Selective Backprop policy {sel.get('policy')!r}, beta {sel.get('beta')}")
        if sel.get("scoring_passes") != T:
            fails.append(f"scoring_passes={sel.get('scoring_passes')}, expected {T}")
        if not isinstance(frac, (int, float)) or not 1.0 / 3.0 < frac < 1.0:
            fails.append(f"measured compute {frac}")
    elif arm == "kakurenbo":
        ep = sel.get("epochs") or []
        if sel.get("policy") != "kakurenbo_fixed_steps" or len(ep) != math.ceil(T / bpe):
            fails.append(f"KAKURENBO policy {sel.get('policy')!r} with {len(ep)} epochs, expected {math.ceil(T / bpe)}")
        elif ep[0].get("hidden") != 0:
            fails.append("KAKURENBO hid examples in the first epoch")
    elif arm == "ies":
        if sel.get("policy") != "ies_fixed_steps" or sel.get("batches_per_epoch") != bpe:
            fails.append(f"IES policy {sel.get('policy')!r}, batches per epoch {sel.get('batches_per_epoch')}")
        early = [v.get("mastered") for k, v in (sel.get("epochs") or {}).items() if int(k) < 3]
        if any(x != 0 for x in early):
            fails.append("IES excluded examples before the fourth epoch")
    elif arm in DROPBP:
        dc = sel.get("drop_counts") or []
        frac_blocks = sel.get("dropped_block_fraction")
        if sel.get("policy") != "dropbp_uniform" or len(dc) != T:
            fails.append(f"DropBP policy {sel.get('policy')!r} with {len(dc)} steps recorded")
        if not isinstance(frac_blocks, (int, float)) or abs(frac_blocks - DROPBP[arm]) > 0.05:
            fails.append(f"dropped block fraction {frac_blocks}, drop rate {DROPBP[arm]}")
        if dropped != 0:
            fails.append(f"DropBP dropped {dropped} examples")
        fpt = sel.get("flops_per_token") or {}
        if fpt != dropbp_layers:
            fails.append(f"DropBP multiply-adds {fpt}, expected from the model's configuration {dropbp_layers}")
    else:
        fails.append(f"no smoke check for {arm}")
    return fails


def pilot_check(out, name, task, lr, end, rev):
    if end is None:
        return ["no end record (interrupted)"], None
    fails = [] if end.get("exit") == 0 else [f"exit code {end.get('exit')}"]
    m, err = read_manifest(out, name)
    if m is None:
        return fails + [err], None
    fails += common_checks(m, task, "full_finetune", lr, rev)
    acc = (m.get("result") or {}).get("final_eval_accuracy")
    return fails, (100.0 * acc if isinstance(acc, (int, float)) else None)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model-cache", required=True, help="the private Hub cache holding the UltraBERT snapshot")
    ap.add_argument("--model-pin", required=True, help="MODEL_PIN.json from the download step")
    ap.add_argument("--model-check", required=True, help="MODEL_CHECK.json from LERNA_R17_MODEL_CHECK.py")
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--resume", action="store_true", help="continue an interrupted launch in --out")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    PLAN = build_plan()
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    # the runs start with the repository as their working folder, so their paths must be absolute
    a.out, a.repo = str(out), str(repo)
    if out.exists() and not a.resume:
        print(f"--out {out} already exists; choose a new folder, or add --resume", file=sys.stderr)
        return 2
    if a.resume and not (out / "plan.json").is_file():
        print(f"--resume needs an earlier launch in {out}", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    parent = git(repo, "rev-parse", "HEAD^")
    subject = git(repo, "log", "-1", "--format=%s")
    if parent != EXPECT["parent"]:
        problems.append(f"HEAD^ is {parent}, expected {EXPECT['parent']} (round 16's commit)")
    if subject != EXPECT["subject"]:
        problems.append(f"HEAD's subject is {subject!r}, expected the round-17 commit")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the committed round-17 version")
    # the model: pin, files, check
    rev, dropbp_layers = None, None
    try:
        pin = json.loads(Path(a.model_pin).read_text())
        rev = pin.get("revision")
        if pin.get("repo_id") != EXPECT["model_id"] or not isinstance(rev, str) or len(rev) != 40 \
                or any(ch not in "0123456789abcdef" for ch in rev):
            problems.append(f"MODEL_PIN.json names {pin.get('repo_id')}@{rev}")
        else:
            snap = snapshot_dir(a.model_cache, rev)
            files = pin.get("files") or {}
            if not files:
                problems.append("MODEL_PIN.json lists no files")
            for fn, info in files.items():
                p = snap / fn
                if not p.is_file() or sha256_file(p) != info.get("sha256"):
                    problems.append(f"model file {fn} is missing or differs from MODEL_PIN.json")
    except Exception as e:
        problems.append(f"MODEL_PIN.json unreadable: {type(e).__name__}: {e}")
    try:
        mc = json.loads(Path(a.model_check).read_text())
        if mc.get("pass") is not True or mc.get("revision") != rev:
            problems.append(f"MODEL_CHECK.json: pass={mc.get('pass')}, revision {mc.get('revision')}")
        if mc.get("implementation_sha256") != FILES["lerna/utils/ultrabert_model.py"]:
            problems.append("MODEL_CHECK.json checked another version of lerna/utils/ultrabert_model.py")
        dropbp_layers = (mc.get("model") or {}).get("dropbp_macs")
        if not isinstance(dropbp_layers, dict) or not dropbp_layers.get("layers"):
            problems.append("MODEL_CHECK.json has no DropBP multiply-adds")
    except Exception as e:
        problems.append(f"MODEL_CHECK.json unreadable: {type(e).__name__}: {e}")
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out if out.exists() else (out.parent if out.parent.exists() else "/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    for task in TASKS:
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    ledger = out / "ledger.jsonl"
    pid_file = out / "launcher.pid"
    held_back = []
    started = set()
    if a.resume and pid_file.is_file():
        try:
            other = int(pid_file.read_text().strip())
            os.kill(other, 0)
            print(f"STOP: another launcher (pid {other}) is still running on {out}", file=sys.stderr)
            return 2
        except (ValueError, ProcessLookupError):
            pass
        except PermissionError:
            print(f"STOP: a process with the launcher's pid is still running on {out}", file=sys.stderr)
            return 2
    if a.resume:
        meta = json.loads((out / "plan.json").read_text())
        if [x["name"] for x in meta["plan"]] != [p[0] for p in PLAN] or \
                [x["name"] for x in meta["pilot"]] != [p[0] for p in PILOT]:
            print("STOP: the plan in plan.json differs from this launcher's plan", file=sys.stderr)
            return 2
        if meta.get("model_revision") != rev:
            print(f"STOP: the earlier launch used revision {meta.get('model_revision')}", file=sys.stderr)
            return 2
        for fname in ("LR_RULE.json", "SMOKE_GATE.json"):
            prev = json.loads((out / fname).read_text()) if (out / fname).is_file() else None
            if prev is not None and not prev.get("pass"):
                print(f"STOP: {fname} failed in the earlier launch; nothing more is run", file=sys.stderr)
                return 3
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e["event"] == "start":
                    started.add(e["name"])
                elif e["event"] == "end":
                    ends[e["name"]] = e
        held_back = sorted(n for n in started if n not in ends)
        meta.setdefault("resumes", []).append({"time": now(), "argv": sys.argv, "finished": len(ends),
                                               "held_back_interrupted": held_back})
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
        print(json.dumps({"resume": True, "already_finished": len(ends), "interrupted_held_back": held_back},
                         indent=1))
    else:
        out.mkdir(parents=True)
        (out / "runs").mkdir()
        (out / "logs").mkdir()
        source_sha = {t: {f: sha256_file(cache_dir(a.source_cache, t) / f) for f in CACHE_FILES} for t in TASKS}
        copies = {"source_sha256": source_sha, "gpus": {}}
        for g in gpus:
            for t in TASKS:
                dst = cache_dir(out / "ds_cache" / f"gpu{g}", t)
                dst.mkdir(parents=True)
                for f in CACHE_FILES:
                    shutil.copy2(cache_dir(a.source_cache, t) / f, dst / f)
                same = all(sha256_file(dst / f) == source_sha[t][f] for f in CACHE_FILES)
                copies["gpus"][f"{g}/{t}"] = same
                if not same:
                    print(f"STOP: the private {t} cache copy for GPU {g} differs from its source", file=sys.stderr)
                    return 2
        meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "repo_parent": parent,
                "files": FILES, "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
                "model_id": EXPECT["model_id"], "model_revision": rev, "model_cache": str(Path(a.model_cache).resolve()),
                "model_pin": json.loads(Path(a.model_pin).read_text()),
                "model_check_sha256": sha256_file(a.model_check), "dropbp_macs": dropbp_layers,
                "pilot_seeds": list(PILOT_SEEDS), "pilot_lrs": list(PILOT_LRS), "default_lr": DEFAULT_LR,
                "lr_margin": LR_MARGIN, "smoke": list(SMOKE), "gate_tolerance": GATE_TOLERANCE,
                "pilot": [{"name": n, "task": t, "seed": s, "learning_rate": lr} for n, t, s, lr in PILOT],
                "plan": [{"name": p[0], "task": p[1], "seed": p[2], "arm": p[3], "score_source": p[4],
                          "controller": p[5], "n_phases": p[6], **p[7], "extra": p[8], "label": p[9]}
                         for p in PLAN]}
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
    pid_file.write_text(str(os.getpid()))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false",
                     "HF_HUB_CACHE": str(Path(a.model_cache).resolve())})
    lock = threading.Lock()

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def run_queue(queue, gpu_list):
        """queue items: (name, cmd)"""
        def worker(gpu):
            while True:
                with lock:
                    if not queue:
                        return
                    name, cmd = queue.pop(0)
                env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu),
                           HF_DATASETS_CACHE=str(out / "ds_cache" / f"gpu{gpu}"))
                t0 = time.time()
                record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
                with open(out / "logs" / f"{name}.log", "wb") as log:
                    try:
                        rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=RUN_TIMEOUT).returncode
                    except subprocess.TimeoutExpired:
                        rc = "timeout"
                manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
                record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                        "seconds": round(time.time() - t0, 1), "manifests": manifests})

        threads = [threading.Thread(target=worker, args=(g,)) for g in gpu_list]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    def all_ends():
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e.get("event") == "end":
                    ends[e["name"]] = e
        return ends

    def finish(extra):
        ends = all_ends()
        done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends.values() if e["exit"] == 0),
                "failed": sorted(n for n, e in ends.items() if e["exit"] != 0), "held_back_interrupted": held_back}
        done.update(extra)
        (out / "DONE.json").write_text(json.dumps(done, indent=1))
        print(json.dumps(done, indent=1))
        try:
            pid_file.unlink()
        except FileNotFoundError:
            pass

    # --- stage 1: the learning-rate pilot and its rule ---
    rule_file = out / "LR_RULE.json"
    if not rule_file.is_file():
        pilot_queue = []
        for n, t, s, lr in PILOT:
            if n in started:
                continue
            entry = _entry(n, t, s, "full_finetune")
            pilot_queue.append((n, command(a, rev, lr, *entry)))
        if pilot_queue:
            run_queue(pilot_queue, gpus)
        ends = all_ends()
        checks, accs = {}, {lr: [] for lr in PILOT_LRS}
        for n, t, s, lr in PILOT:
            fails, acc = pilot_check(out, n, t, lr, ends.get(n), rev)
            checks[n] = {"pass": not fails, "fails": fails, "accuracy": acc, "task": t, "seed": s,
                         "learning_rate": lr}
            if not fails:
                accs[lr].append(acc)
        ok = all(c["pass"] for c in checks.values())
        rule = {"time": now(), "pass": ok, "runs": checks, "default_lr": DEFAULT_LR, "margin_points": LR_MARGIN}
        if ok:
            choice, means, best = lr_rule(accs)
            rule.update(means={repr(k): v for k, v in means.items()}, best=best, choice=choice)
        rule_file.write_text(json.dumps(rule, indent=1))
        print(json.dumps({"lr_rule": {k: rule.get(k) for k in ("pass", "means", "best", "choice")}}, indent=1))
        if not ok:
            finish({"stopped_at": "learning-rate pilot", "pilot_pass": False})
            return 3
    rule = json.loads(rule_file.read_text())
    lr = rule["choice"]
    if lr not in PILOT_LRS:
        print(f"STOP: LR_RULE.json chose {lr}", file=sys.stderr)
        return 2
    # --- stage 2: the smoke gate ---
    gate_file = out / "SMOKE_GATE.json"
    if not gate_file.is_file():
        smoke_queue = [(p[0], command(a, rev, lr, *p)) for p in PLAN if p[0] in SMOKE and p[0] not in started]
        if smoke_queue:
            run_queue(smoke_queue, gpus)
        ends = all_ends()
        results = {p[0]: gate_check(out, p, ends.get(p[0]), lr, rev, dropbp_layers) for p in PLAN if p[0] in SMOKE}
        gate = {"time": now(), "pass": all(not f for f in results.values()), "tolerance": GATE_TOLERANCE,
                "learning_rate": lr, "runs": {n: {"pass": not f, "fails": f} for n, f in results.items()}}
        gate_file.write_text(json.dumps(gate, indent=1))
        print(json.dumps({"smoke_gate": gate}, indent=1))
        if not gate["pass"]:
            finish({"stopped_at": "smoke gate", "pilot_pass": True, "smoke_gate_pass": False, "learning_rate": lr})
            return 3
    # --- stage 3: the other runs ---
    queue = [(p[0], command(a, rev, lr, *p)) for p in PLAN if p[0] not in SMOKE and p[0] not in started]
    run_queue(queue, gpus)
    finish({"pilot_pass": True, "smoke_gate_pass": True, "learning_rate": lr})
    return 0


if __name__ == "__main__":
    sys.exit(main())

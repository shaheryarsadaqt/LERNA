#!/usr/bin/env python3
"""LERNA round 17: fetch the second model, UltraBERT-150M, into a private Hub cache and pin it
(8 November 2026).

Two ways, both ending in the same layout, <cache>/models--dmis-lab--UltraBERT-150M/snapshots/<commit>/,
and the same MODEL_PIN.json (the repository, the commit, and every file's size and SHA-256):

  1. From a Hub endpoint (default https://hf-mirror.com):
       python -s -B LERNA_R17_DOWNLOAD.py --cache <dir> --pin <MODEL_PIN.json> [--endpoint URL]
     It reads the repository's current commit from <endpoint>/api/models/dmis-lab/UltraBERT-150M,
     lists that commit's files, downloads only the ones a model needs (config.json, the
     safetensors weights and their index if any, tokenizer.json, tokenizer_config.json,
     special_tokens_map.json; never code files), and checks each weight file's SHA-256 against the
     listing's LFS hash.
  2. From a folder the user copied in (when the server cannot reach any endpoint):
       python -s -B LERNA_R17_DOWNLOAD.py --cache <dir> --pin <MODEL_PIN.json> \\
           --from-folder <folder> --revision <40-hex commit>
     It copies the same files from the folder.

It writes only into --cache (which must not already hold this commit) and --pin (which must not
exist). Nothing is executed from the downloaded files.
"""
import argparse
import hashlib
import json
import shutil
import sys
import time
import urllib.request
from pathlib import Path

VERSION = "LERNA_R17_DOWNLOAD 2026-11-08"
REPO_ID = "dmis-lab/UltraBERT-150M"
WANTED_EXACT = ("config.json", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
                "model.safetensors", "model.safetensors.index.json")
REQUIRED = ("config.json", "tokenizer.json", "tokenizer_config.json")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def is_commit(s):
    return isinstance(s, str) and len(s) == 40 and all(c in "0123456789abcdef" for c in s)


def wanted(name):
    if "/" in name:
        return False
    return name in WANTED_EXACT or (name.startswith("model-") and name.endswith(".safetensors"))


def get_json(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "lerna-round17/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def snapshot(cache, rev):
    return Path(cache) / ("models--" + REPO_ID.replace("/", "--")) / "snapshots" / rev


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--cache", required=True)
    ap.add_argument("--pin", required=True)
    ap.add_argument("--endpoint", default="https://hf-mirror.com")
    ap.add_argument("--from-folder", default=None)
    ap.add_argument("--revision", default=None, help="with --from-folder: the commit the files came from")
    a = ap.parse_args()
    pin_path = Path(a.pin)
    if pin_path.exists():
        print(f"STOP: {pin_path} already exists", file=sys.stderr)
        return 2
    pin = {"version": VERSION, "repo_id": REPO_ID, "time": time.strftime("%Y-%m-%d %H:%M:%S %z")}
    if a.from_folder:
        if not is_commit(a.revision):
            print("STOP: --from-folder needs --revision, the 40-character commit the files came from", file=sys.stderr)
            return 2
        src = Path(a.from_folder)
        names = sorted(p.name for p in src.iterdir() if p.is_file() and wanted(p.name))
        missing = [n for n in REQUIRED if n not in names]
        if missing or not any(n.endswith(".safetensors") for n in names):
            print(f"STOP: the folder lacks {missing or ['the safetensors weights']}", file=sys.stderr)
            return 2
        dst = snapshot(a.cache, a.revision)
        if dst.exists():
            print(f"STOP: {dst} already exists", file=sys.stderr)
            return 2
        dst.mkdir(parents=True)
        for n in names:
            shutil.copy2(src / n, dst / n)
        pin.update(source="folder", folder=str(src.resolve()), revision=a.revision, endpoint=None, listing=None)
    else:
        base = a.endpoint.rstrip("/")
        try:
            info = get_json(f"{base}/api/models/{REPO_ID}")
        except Exception as e:
            print(f"STOP: {base} not reachable ({type(e).__name__}: {e})", file=sys.stderr)
            return 4
        rev = info.get("sha")
        if not is_commit(rev):
            print(f"STOP: the endpoint gave no commit for {REPO_ID}: {rev!r}", file=sys.stderr)
            return 2
        try:
            listing = get_json(f"{base}/api/models/{REPO_ID}/revision/{rev}?blobs=true")
        except Exception as e:
            print(f"STOP: the file listing failed ({type(e).__name__}: {e})", file=sys.stderr)
            return 4
        sibs = {s["rfilename"]: s for s in listing.get("siblings", [])}
        names = sorted(n for n in sibs if wanted(n))
        missing = [n for n in REQUIRED if n not in names]
        if missing or not any(n.endswith(".safetensors") for n in names):
            print(f"STOP: the repository lacks {missing or ['the safetensors weights']}; files: {sorted(sibs)}",
                  file=sys.stderr)
            return 2
        dst = snapshot(a.cache, rev)
        if dst.exists():
            print(f"STOP: {dst} already exists", file=sys.stderr)
            return 2
        from huggingface_hub import hf_hub_download

        for n in names:
            hf_hub_download(repo_id=REPO_ID, filename=n, revision=rev, cache_dir=a.cache, endpoint=base)
        lfs = {n: (sibs[n].get("lfs") or {}).get("sha256") for n in names}
        for n, h in lfs.items():
            if h and sha256_file(dst / n) != h:
                print(f"STOP: {n}'s SHA-256 differs from the listing's LFS hash", file=sys.stderr)
                return 2
        card = info.get("cardData") or {}
        pin.update(source="endpoint", endpoint=base, revision=rev, last_modified=info.get("lastModified"),
                   license=card.get("license") or [t for t in info.get("tags", []) if t.startswith("license:")],
                   listing={n: {"size": sibs[n].get("size"), "lfs_sha256": lfs[n]} for n in names},
                   all_files=sorted(sibs))
    files = {}
    for p in sorted(snapshot(a.cache, pin["revision"]).iterdir()):
        files[p.name] = {"size": p.stat().st_size, "sha256": sha256_file(p)}
    pin["files"] = files
    pin_path.write_text(json.dumps(pin, indent=1))
    print(json.dumps({"revision": pin["revision"], "files": files}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA round 17: check the second model before any training (8 November 2026).

It loads UltraBERT-150M from the private Hub cache with LERNA's own implementation
(lerna/utils/ultrabert_model.py, for transformers 4.56) and checks it against the float32 outputs
that transformers 5.22.2's integration test expects from the original checkpoint
(tests/models/ultrabert/test_modeling_ultrabert.py, test_inference_masked_lm_150m, file SHA-256
9ccf2d2db4e6c5e621aef6a46e1f8894ceeaafa7006b2caaad13735ebc6a0b90):

  1. every file listed in MODEL_PIN.json is present with its SHA-256;
  2. the tokenizer: "The capital of France is <|mask|>." and "The capital of Germany is <|mask|>."
     give 2 x 8 token ids with one <|mask|> each;
  3. the masked-LM logits: shape (2, 8, 49152); at the two masks, the first five logits equal
     the test's within rtol 1e-4, atol 1e-4 (torch.testing.assert_close's rule); the top tokens
     decode to " Paris" and " Berlin";
  4. the classifier: every encoder tensor loaded, only classifier.weight and classifier.bias new,
     only prediction-head tensors unused; one forward and backward pass on a sentence pair.

It records the configuration, the parameter counts, the tokenizer's special tokens and pair
template, and DropBP's multiply-adds per layer computed from the configuration (the launcher's
smoke gate compares the runs' own counts with these). It writes --out (which must not exist);
"pass" is true only if every check passes. Exit code 0 on PASS, 1 on FAIL.

Usage:
  python -s -B LERNA_R17_MODEL_CHECK.py --repo /home/nanhangproj/LERNA --model-cache <dir> \\
      --model-pin <MODEL_PIN.json> --out <MODEL_CHECK.json> [--device cuda]
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

VERSION = "LERNA_R17_MODEL_CHECK 2026-11-08"
MODEL_ID = "dmis-lab/UltraBERT-150M"
SENTENCES = ["The capital of France is <|mask|>.", "The capital of Germany is <|mask|>."]
EXPECTED_SHAPE = (2, 8, 49152)
EXPECTED_SLICE = [[-173.299500, -172.092453, -172.083084, -166.659607, -168.356415],
                  [-166.776337, -165.526764, -165.573578, -160.336792, -161.950073]]
EXPECTED_WORDS = [" Paris", " Berlin"]
RTOL = ATOL = 1e-4
PAIR = ("The company said it expects revenue to rise.", "Revenue is expected to increase, the firm said.")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--model-cache", required=True)
    ap.add_argument("--model-pin", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()
    out = Path(a.out)
    if out.exists():
        print(f"STOP: {out} already exists", file=sys.stderr)
        return 2
    sys.path.insert(0, str(Path(a.repo).resolve()))
    import torch
    from lerna.utils import ultrabert_model as ub

    report = {"version": VERSION, "time": time.strftime("%Y-%m-%d %H:%M:%S %z"), "model_id": MODEL_ID,
              "implementation": str(Path(ub.__file__).resolve()),
              "implementation_sha256": sha256_file(ub.__file__), "checks": {}, "fails": []}
    fails = report["fails"]

    def check(name, ok, detail=None):
        report["checks"][name] = {"pass": bool(ok), "detail": detail}
        if not ok:
            fails.append(f"{name}: {detail}")
        return ok

    pin = json.loads(Path(a.model_pin).read_text())
    rev = pin.get("revision")
    report["revision"] = rev
    snap = Path(a.model_cache) / ("models--" + MODEL_ID.replace("/", "--")) / "snapshots" / str(rev)
    report["snapshot"] = str(snap)
    bad = [fn for fn, info in (pin.get("files") or {}).items()
           if not (snap / fn).is_file() or sha256_file(snap / fn) != info.get("sha256")]
    check("files_match_pin", pin.get("repo_id") == MODEL_ID and pin.get("files") and not bad, bad or pin.get("repo_id"))
    if fails:
        report["pass"] = False
        out.write_text(json.dumps(report, indent=1))
        print(json.dumps({"pass": False, "fails": fails}, indent=1))
        return 1
    device = torch.device(a.device if (a.device != "cuda" or torch.cuda.is_available()) else "cpu")
    report["device"] = str(device)
    import transformers
    report["versions"] = {"torch": torch.__version__, "transformers": transformers.__version__}
    try:
        tok = ub.load_ultrabert_tokenizer(MODEL_ID, revision=rev, snapshot=snap)
        report["tokenizer"] = {"class": type(tok).__name__, "vocab_size": len(tok),
                               "special_tokens": tok.special_tokens_map, "pad_token_id": tok.pad_token_id,
                               "mask_token_id": tok.mask_token_id, "bos_token_id": tok.bos_token_id,
                               "eos_token_id": tok.eos_token_id, "model_input_names": tok.model_input_names,
                               "padding_side": tok.padding_side}
        enc = tok(SENTENCES, padding=True, return_tensors="pt")
        ids = enc["input_ids"]
        report["tokenizer"]["sentences"] = [tok.convert_ids_to_tokens(r) for r in ids.tolist()]
        pair = tok(*PAIR)
        report["tokenizer"]["pair_tokens"] = tok.convert_ids_to_tokens(pair["input_ids"])
        report["tokenizer"]["pair_keys"] = sorted(pair.keys())
        check("tokenizer_shape", tuple(ids.shape) == EXPECTED_SHAPE[:2], tuple(ids.shape))
        check("one_mask_each", tok.mask_token_id is not None
              and (ids == tok.mask_token_id).sum(dim=1).tolist() == [1, 1],
              (ids == tok.mask_token_id).sum(dim=1).tolist() if tok.mask_token_id is not None else None)
        mlm = ub.load_ultrabert_for_masked_lm(MODEL_ID, revision=rev, snapshot=snap).to(device).eval()
        report["masked_lm_load"] = mlm.lerna_checkpoint_report
        with torch.no_grad():
            logits = mlm(**{k: v.to(device) for k, v in enc.items() if k in ("input_ids", "attention_mask")}).logits
        check("mlm_logits_shape", tuple(logits.shape) == EXPECTED_SHAPE, tuple(logits.shape))
        if tuple(logits.shape) == EXPECTED_SHAPE and not fails:
            masked = logits[ids.to(device) == tok.mask_token_id][:, :5].float().cpu()
            want = torch.tensor(EXPECTED_SLICE)
            diff = (masked - want).abs()
            allowed = ATOL + RTOL * want.abs()
            report["mlm_logits"] = {"got": masked.tolist(), "expected": EXPECTED_SLICE,
                                    "max_abs_diff": float(diff.max()), "max_ratio_to_allowed": float((diff / allowed).max())}
            check("mlm_logits_match_transformers_test", bool((diff <= allowed).all()), report["mlm_logits"]["max_abs_diff"])
            top = logits[ids.to(device) == tok.mask_token_id].argmax(-1)[:, None].cpu()
            words = tok.batch_decode(top)
            check("top_words", words == EXPECTED_WORDS, words)
        del mlm
        cls = ub.load_ultrabert_for_sequence_classification(MODEL_ID, revision=rev, snapshot=snap, num_labels=2)
        rep = cls.lerna_checkpoint_report
        report["classifier_load"] = rep
        check("classifier_only_new", set(rep["missing"]) == {"classifier.weight", "classifier.bias"}
              and all(not k.startswith("model.") for k in rep["unused"]), {"missing": rep["missing"], "unused": rep["unused"]})
        cfg = cls.config
        report["model"] = {
            "class": type(cls).__name__,
            "config": {k: getattr(cfg, k) for k in ("vocab_size", "hidden_size", "intermediate_size", "num_hidden_layers",
                                                    "num_attention_heads", "num_key_value_heads", "head_dim",
                                                    "hidden_act", "rms_norm_eps", "sliding_window", "layer_types",
                                                    "rope_parameters", "attention_bias", "mlp_bias",
                                                    "classifier_pooling", "classifier_dropout", "pad_token_id",
                                                    "bos_token_id", "eos_token_id", "max_position_embeddings",
                                                    "tie_word_embeddings")},
            "parameters": int(sum(p.numel() for p in cls.parameters())),
            "encoder_parameters": int(sum(p.numel() for p in cls.model.parameters())),
            "dropbp_macs": ub.dropbp_macs_from_config(cfg),
            "attn_implementation": cfg._attn_implementation,
        }
        cls = cls.to(device).train()
        penc = tok([PAIR[0]], [PAIR[1]], return_tensors="pt")
        o = cls(input_ids=penc["input_ids"].to(device), attention_mask=penc["attention_mask"].to(device),
                labels=torch.tensor([1], device=device))
        o.loss.backward()
        gnorm = float(sum(float(p.grad.norm()) ** 2 for p in cls.parameters() if p.grad is not None) ** 0.5)
        check("classifier_forward_backward", torch.isfinite(o.loss).item() and gnorm > 0 and o.logits.shape == (1, 2),
              {"loss": float(o.loss), "grad_norm": gnorm})
    except Exception as e:
        import traceback
        check("no_exception", False, f"{type(e).__name__}: {e}")
        report["traceback"] = traceback.format_exc()[-4000:]
    report["pass"] = not fails
    out.write_text(json.dumps(report, indent=1, default=str))
    print(json.dumps({"pass": report["pass"], "fails": fails, "mlm_logits": report.get("mlm_logits"),
                      "model": {k: (report.get("model") or {}).get(k) for k in ("parameters", "dropbp_macs")}},
                     indent=1, default=str))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())

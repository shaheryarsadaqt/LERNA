#!/usr/bin/env python3
"""LERNA round 18: the causal LLMs' launcher (9 November 2026).

It runs the round fixed in claude/LERNA_R18_LLM_PLAN_2026-11-09.md: LERNA v2 and seven reference
methods on three decoder-only LLMs (Llama-3.2-1B, Qwen3-0.6B-Base and the mixture-of-experts
Granite-3.1-1B-A400M-Base), on MRPC (T = 345) and RTE (T = 234), 3 epochs, seeds 11, 13 and 17,
in qwen-v100, one GPU per run: AdamW, batch 32, linear decay after a warmup of 6% of T, FP32,
eager attention, gradient checkpointing, at the learning rate each model's pilot chooses.
8 methods x 3 seeds x 2 tasks x 3 models = 144 runs.

Before anything runs it checks the checkout (round 18's commit on round 17's), each model's pin
(MODEL_PIN.<model>.json: the commit and every file's SHA-256, all re-hashed here) and the model
check (MODEL_CHECK.json, written by LERNA_R18_MODEL_CHECK.py: PASS, with the same commits and the
committed lerna/utils/causal_lm_classifier.py).

Stage 1, the learning-rate pilot. Full fine-tuning at 5e-6, 1e-5 and 2e-5 on MRPC and RTE, seeds 47
and 53 (outside the main seeds), for each model: 36 runs. Each must pass the run checks. The rule,
fixed in the plan, for each model: m(lr) = the mean accuracy of its four runs at lr; keep 1e-5
unless the best m is above m(1e-5) by more than 1.0 point, then take the best (ties go to 1e-5,
then to the smaller rate). It writes LR_RULE.json.

Stage 2, the smoke gate: MRPC, seed 11, every method on every model (24 runs), each checked (status
OK, the exact counts, a final LR of 0, its model's learning rate, model, revision and parameter
count, FP32, eager attention, gradient checkpointing, and the method's own accounting). It writes
SMOKE_GATE.json.

Stage 3, the other 120 runs, longest first, on every GPU.

A failed pilot or gate stops the launch (DONE.json says where). There are no retries and no seed
changes. Each GPU has one private copy of each task's prepared cache. The models are read from
the private Hub cache (--model-cache), offline.

With --resume on an existing --out it continues an interrupted launch: it skips the runs that
started, never reruns a failed run, and holds back any run that started but has no end record. A
pilot rule or a gate that already passed is not redone.

It writes only into --out, which must not exist (unless --resume):
  ds_cache/   per GPU, one private copy of each task's prepared cache, checked byte for byte
  runs/       one output folder per run
  logs/       one log per run
  plan.json, ledger.jsonl, LR_RULE.json, SMOKE_GATE.json and DONE.json

Usage:
  python -s -B LERNA_R18_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder> \\
      --model-cache <private Hub cache> --model-pins <llama pin> <qwen pin> <granite pin> \\
      --model-check <MODEL_CHECK.json>
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R18_LAUNCH 2026-11-09"
EXPECT = {
    "parent": "ce2bb360e3deca7d6faa9e5b22053fcd5e6bbbb5",
    "subject": "Round 18 runner: causal LLMs (Llama, Qwen3, a Granite MoE) and the plain run at 35%",
}
FILES = {
    "scripts/run_controller_ablation.py": "3ed7d6498ad1fc6e85940e8a4922f3ca2dad1f2b102887713d24ddaa7dfea0dd",
    "lerna/utils/causal_lm_classifier.py": "ae722af37ffa5d73053736ee6c14d57802adbad600613ed52e846088a68cbe98",
    "lerna/utils/model_loader.py": "b25495256b20575f9230368e249c7f0c75735f4b4c6e53819b57bcbc00534808",
    "lerna/utils/compared_methods.py": "53f90fae4cd46a4609752ad5e7990fcae0bd378823f011060a7d1df719862031",
    "lerna/utils/budget_selection.py": "df970102a7684df4d7f054b51867b5a08077efdfa2b8e69919a0894f16b62bea",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
MODELS = {"llama": "alpindale/Llama-3.2-1B", "qwen": "Qwen/Qwen3-0.6B-Base",
          "granite": "ibm-granite/granite-3.1-1b-a400m-base"}
MODEL_TYPE = {"llama": "llama", "qwen": "qwen3", "granite": "granitemoe"}
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"mrpc": "mrpc", "rte": "rte"}
TASKS = ("mrpc", "rte")
# T = 3 epochs of MRPC's 115 and RTE's 78 batches; min_step = W = floor(0.06 T)
HORIZON = {"mrpc": {"total_steps": 345, "min_step": 20}, "rte": {"total_steps": 234, "min_step": 14}}
TRAIN_ROWS = {"mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
SEEDS = (11, 13, 17)
PILOT_SEEDS = (47, 53)
PILOT_LRS = (5e-6, 1e-5, 2e-5)
DEFAULT_LR = 1e-5
LR_MARGIN = 1.0  # accuracy points
RATE = 0.60
LABELS = ("full_finetune", "plain_035", "equal_compute", "lerna2_nolr_b035", "lerna2_nolr_b060", "randkeep_b035",
          "infobatch", "gate_s1_p4")
BUDGET = {"lerna2_nolr_b035": 0.35, "lerna2_nolr_b060": 0.60, "randkeep_b035": 0.35}
GATES = ("gate_s1_p4",)
ARM_SPEC = {a: ("uniform", "legacy_v4", 1) for a in LABELS}
ARM_SPEC["gate_s1_p4"] = ("s1", "phase_exact_v1", 4)
GATE_TOLERANCE = 0.005
SMOKE = tuple(f"{m}_mrpc_{lab}_seed11" for m in MODELS for lab in LABELS)
# estimated seconds per step on a V100 (FP32, checkpointing), for the order of the runs only
STEP_SECONDS = {("llama", "mrpc"): 2.6, ("llama", "rte"): 5.3, ("qwen", "mrpc"): 1.4, ("qwen", "rte"): 2.9,
                ("granite", "mrpc"): 1.8, ("granite", "rte"): 3.7}
REL_COST = {"full_finetune": 1.0, "plain_035": 0.35, "equal_compute": 0.60, "lerna2_nolr_b035": 0.42,
            "lerna2_nolr_b060": 0.64, "randkeep_b035": 0.42, "infobatch": 0.80, "gate_s1_p4": 0.62}
MIN_FREE_GB = 2
RUN_TIMEOUT = 3 * 3600
CUDA_ALLOC_CONF = "expandable_segments:True"


def lr_tag(lr):
    return f"lr{lr:.0e}".replace("e-0", "e-")


PILOT = tuple((f"{m}_{t}_pilot_full_finetune_{lr_tag(lr)}_seed{s}", m, t, s, lr)
              for m in MODELS for t in TASKS for lr in PILOT_LRS for s in PILOT_SEEDS)


def horizon_of(arm, T):
    """Scheduled batches of an arm (the runner's arm_horizon)."""
    q = int(round(RATE * T))
    if arm == "equal_compute":
        return T - (2 * q + 2) // 3
    if arm == "plain_035":
        return int(round(0.35 * T))
    return T


def skips_of(arm, T):
    return int(round(RATE * T)) if arm in GATES else 0


def _entry(name, model, task, seed, arm):
    return (name, model, task, seed, arm) + ARM_SPEC[arm] + (HORIZON[task], [], arm)


def build_plan():
    entries = [_entry(f"{m}_{t}_{lab}_seed{s}", m, t, s, lab) for m in MODELS for t in TASKS for lab in LABELS
               for s in SEEDS]

    def cost(p):
        return HORIZON[p[2]]["total_steps"] * STEP_SECONDS[(p[1], p[2])] * REL_COST[p[10]]

    smoke = [next(p for p in entries if p[0] == n) for n in SMOKE]
    rest = sorted([p for p in entries if p[0] not in SMOKE], key=lambda p: (-cost(p), p[0]))
    return smoke + rest


def lr_rule(accuracies):
    """accuracies: {lr: [accuracy in %, ...]} over one model's pilot runs. Returns (choice, means, best)."""
    means = {lr: sum(v) / len(v) for lr, v in accuracies.items()}
    best = max(PILOT_LRS, key=lambda lr: (means[lr], lr == DEFAULT_LR, -lr))
    choice = best if means[best] - means[DEFAULT_LR] > LR_MARGIN else DEFAULT_LR
    return choice, means, best


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def snapshot_dir(model_cache, model_id, revision):
    return Path(model_cache) / ("models--" + model_id.replace("/", "--")) / "snapshots" / revision


def command(a, revs, lrs, name, model, task, seed, arm, source, controller, phases, horizon, extra, label):
    mid = MODELS[model]
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--learning-rate", repr(float(lrs[model])), "--device", "cuda",
           "--model-id", mid, "--tokenizer-id", mid, "--model-revision", revs[model],
           "--tokenizer-revision", revs[model], "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    return cmd + list(extra)


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def read_manifest(out, name):
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return None, f"{len(found)} execution manifests found"
    return json.loads(found[0].read_text()), None


def common_checks(m, model, task, arm, lr, rev, parameters):
    """Checks every run must pass: status, counts, final LR, learning rate, model, revision and runtime."""
    T = HORIZON[task]["total_steps"]
    H, q = horizon_of(arm, T), skips_of(arm, T)
    fails = []
    if m.get("status") != "OK":
        return [f"status {m.get('status')}: {str(m.get('reason'))[:300]}"]
    r = m.get("result", {})
    c = m.get("config", {})
    for k, v in (("skipped", q), ("backwards", H - q), ("forwards", H), ("forward_skipped", 0),
                 ("scheduler_advances", H), ("optimizer_updates", H - q), ("effective_total", H)):
        if r.get(k) != v:
            fails.append(f"{k}={r.get(k)}, expected {v}")
    acc = r.get("final_eval_accuracy")
    if not isinstance(acc, (int, float)) or not 0.0 <= acc <= 1.0:
        fails.append(f"final_eval_accuracy={acc}")
    flr = r.get("final_learning_rate")
    if not isinstance(flr, (int, float)) or abs(flr) > 1e-12:
        fails.append(f"final_learning_rate={flr}")
    if c.get("learning_rate") != lr or r.get("learning_rate") != lr:
        fails.append(f"learning rate {c.get('learning_rate')}/{r.get('learning_rate')}, expected {lr}")
    mid = MODELS[model]
    if (c.get("model_id") != mid or c.get("tokenizer_id") != mid or c.get("model_revision") != rev
            or c.get("tokenizer_revision") != rev):
        fails.append(f"model {c.get('model_id')}@{c.get('model_revision')}, expected {mid}@{rev}")
    rt = m.get("runtime") or {}
    if rt.get("attn_implementation") != "eager" or rt.get("model_dtype") != "torch.float32":
        fails.append(f"runtime attention {rt.get('attn_implementation')}, dtype {rt.get('model_dtype')}")
    if rt.get("gradient_checkpointing") is not True or rt.get("model_class") != "CausalLMForSequenceClassification" \
            or rt.get("model_type") != MODEL_TYPE[model]:
        fails.append(f"runtime checkpointing {rt.get('gradient_checkpointing')}, class {rt.get('model_class')}, "
                     f"type {rt.get('model_type')}")
    if rt.get("parameters") != parameters:
        fails.append(f"parameters {rt.get('parameters')}, the model check recorded {parameters}")
    return fails


def gate_check(out, entry, end, lr, rev, parameters):
    """The smoke gate's checks of one run. [] = pass."""
    name, model, task, seed, arm = entry[0], entry[1], entry[2], entry[3], entry[4]
    T = HORIZON[task]["total_steps"]
    W = int(math.floor(0.06 * T + 1e-9))
    bpe = math.ceil(TRAIN_ROWS[task] / BATCH_SIZE)
    if end is None:
        return ["no end record (interrupted)"]
    fails = [] if end.get("exit") == 0 else [f"exit code {end.get('exit')}"]
    m, err = read_manifest(out, name)
    if m is None:
        return fails + [err]
    fails += common_checks(m, model, task, arm, lr, rev, parameters)
    if fails:
        return fails
    r = m.get("result", {})
    sel = r.get("selection") or {}
    dropped = r.get("examples_dropped_before_forward")
    if arm in ("full_finetune", "plain_035", "equal_compute") + GATES:
        if dropped != 0:
            fails.append(f"examples_dropped={dropped}")
        return fails
    if not isinstance(dropped, int) or dropped != sel.get("pruned_examples"):
        fails.append(f"examples_dropped={dropped}, policy pruned={sel.get('pruned_examples')}")
    if not isinstance(dropped, int) or dropped <= 0:
        fails.append("no example dropped")
    if sel.get("steps_seen", T) != T and arm in BUDGET:
        fails.append(f"steps_seen={sel.get('steps_seen')}, expected {T}")
    if arm in BUDGET:
        budget = BUDGET[arm]
        if sel.get("policy") != "lerna_budget" or sel.get("selection") != "sample" or sel.get("budget") != budget:
            fails.append(f"selection {sel.get('policy')!r}/{sel.get('selection')!r}, budget {sel.get('budget')}")
        rf = sel.get("realized_fraction")
        if not isinstance(rf, (int, float)) or abs(rf - budget) > GATE_TOLERANCE:
            fails.append(f"spent {rf} of the scheduled compute, budget {budget} +/- {GATE_TOLERANCE}")
        if sel.get("pruned_during_warmup") != 0:
            fails.append(f"pruned_during_warmup={sel.get('pruned_during_warmup')}")
        if sel.get("warmup_steps") != W:
            fails.append(f"warmup_steps={sel.get('warmup_steps')}, expected {W}")
        if sel.get("use_scores") != (arm != "randkeep_b035") or sel.get("use_lr_weight") is not False:
            fails.append(f"use_scores {sel.get('use_scores')}, use_lr_weight {sel.get('use_lr_weight')}")
    elif arm == "infobatch":
        if sel.get("num_examples") != TRAIN_ROWS[task] or sel.get("batches_per_epoch") != bpe:
            fails.append(f"InfoBatch num_examples {sel.get('num_examples')}, batches per epoch "
                         f"{sel.get('batches_per_epoch')}")
        if sel.get("stop_prune_step") != int(math.floor(0.875 * T + 1e-9)):
            fails.append(f"stop_prune_step={sel.get('stop_prune_step')}")
        if sel.get("empty_batch_fallbacks") != 0:
            fails.append(f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
    else:
        fails.append(f"no smoke check for {arm}")
    return fails


def pilot_check(out, name, model, task, lr, end, rev, parameters):
    if end is None:
        return ["no end record (interrupted)"], None
    fails = [] if end.get("exit") == 0 else [f"exit code {end.get('exit')}"]
    m, err = read_manifest(out, name)
    if m is None:
        return fails + [err], None
    fails += common_checks(m, model, task, "full_finetune", lr, rev, parameters)
    acc = (m.get("result") or {}).get("final_eval_accuracy")
    return fails, (100.0 * acc if isinstance(acc, (int, float)) else None)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model-cache", required=True, help="the private Hub cache holding the three models")
    ap.add_argument("--model-pins", nargs=3, required=True, help="the three MODEL_PIN files from the download step")
    ap.add_argument("--model-check", required=True, help="MODEL_CHECK.json from LERNA_R18_MODEL_CHECK.py")
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--resume", action="store_true", help="continue an interrupted launch in --out")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    PLAN = build_plan()
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    # the runs start with the repository as their working folder, so their paths must be absolute
    a.out, a.repo = str(out), str(repo)
    if out.exists() and not a.resume:
        print(f"--out {out} already exists; choose a new folder, or add --resume", file=sys.stderr)
        return 2
    if a.resume and not (out / "plan.json").is_file():
        print(f"--resume needs an earlier launch in {out}", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    parent = git(repo, "rev-parse", "HEAD^")
    subject = git(repo, "log", "-1", "--format=%s")
    if parent != EXPECT["parent"]:
        problems.append(f"HEAD^ is {parent}, expected {EXPECT['parent']} (round 17's commit)")
    if subject != EXPECT["subject"]:
        problems.append(f"HEAD's subject is {subject!r}, expected the round-18 commit")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the committed round-18 version")
    # the models: pins, files, check
    revs, pins, parameters = {}, {}, {}
    by_id = {v: k for k, v in MODELS.items()}
    for pf in a.model_pins:
        try:
            pin = json.loads(Path(pf).read_text())
            key = by_id.get(pin.get("repo_id"))
            rev = pin.get("revision")
            if key is None or key in pins or not isinstance(rev, str) or len(rev) != 40 \
                    or any(ch not in "0123456789abcdef" for ch in rev):
                problems.append(f"{pf} names {pin.get('repo_id')}@{rev}")
                continue
            pins[key], revs[key] = pin, rev
            snap = snapshot_dir(a.model_cache, MODELS[key], rev)
            files = pin.get("files") or {}
            if not files:
                problems.append(f"{pf} lists no files")
            for fn, info in files.items():
                p = snap / fn
                if not p.is_file() or sha256_file(p) != info.get("sha256"):
                    problems.append(f"{MODELS[key]}: file {fn} is missing or differs from its pin")
            if key == "llama" and (pin.get("reference") or {}).get("status") not in ("identical", "unavailable"):
                problems.append(f"the Llama pin's comparison with Meta's listing: {(pin.get('reference') or {}).get('status')}")
        except Exception as e:
            problems.append(f"{pf} unreadable: {type(e).__name__}: {e}")
    if set(pins) != set(MODELS):
        problems.append(f"pins for {sorted(pins)}, expected {sorted(MODELS)}")
    try:
        mc = json.loads(Path(a.model_check).read_text())
        if mc.get("pass") is not True:
            problems.append(f"MODEL_CHECK.json: pass={mc.get('pass')}")
        if mc.get("implementation_sha256") != FILES["lerna/utils/causal_lm_classifier.py"]:
            problems.append("MODEL_CHECK.json checked another version of lerna/utils/causal_lm_classifier.py")
        for key, mid in MODELS.items():
            rec = (mc.get("models") or {}).get(mid) or {}
            if rec.get("revision") != revs.get(key):
                problems.append(f"MODEL_CHECK.json checked {mid}@{rec.get('revision')}, the pin has {revs.get(key)}")
            if key in pins and rec.get("pin_sha256") != sha256_file(
                    [pf for pf in a.model_pins if json.loads(Path(pf).read_text()).get("repo_id") == mid][0]):
                problems.append(f"MODEL_CHECK.json read another pin for {mid}")
            n = (rec.get("parameters") or {}).get("total")
            if not isinstance(n, int) or n <= 0:
                problems.append(f"MODEL_CHECK.json has no parameter count for {mid}")
            parameters[key] = n
    except Exception as e:
        problems.append(f"MODEL_CHECK.json unreadable: {type(e).__name__}: {e}")
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out if out.exists() else (out.parent if out.parent.exists() else "/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    for task in TASKS:
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    ledger = out / "ledger.jsonl"
    pid_file = out / "launcher.pid"
    held_back = []
    started = set()
    if a.resume and pid_file.is_file():
        try:
            other = int(pid_file.read_text().strip())
            os.kill(other, 0)
            print(f"STOP: another launcher (pid {other}) is still running on {out}", file=sys.stderr)
            return 2
        except (ValueError, ProcessLookupError):
            pass
        except PermissionError:
            print(f"STOP: a process with the launcher's pid is still running on {out}", file=sys.stderr)
            return 2
    if a.resume:
        meta = json.loads((out / "plan.json").read_text())
        if [x["name"] for x in meta["plan"]] != [p[0] for p in PLAN] or \
                [x["name"] for x in meta["pilot"]] != [p[0] for p in PILOT]:
            print("STOP: the plan in plan.json differs from this launcher's plan", file=sys.stderr)
            return 2
        if meta.get("model_revisions") != revs:
            print(f"STOP: the earlier launch used revisions {meta.get('model_revisions')}", file=sys.stderr)
            return 2
        for fname in ("LR_RULE.json", "SMOKE_GATE.json"):
            prev = json.loads((out / fname).read_text()) if (out / fname).is_file() else None
            if prev is not None and not prev.get("pass"):
                print(f"STOP: {fname} failed in the earlier launch; nothing more is run", file=sys.stderr)
                return 3
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e["event"] == "start":
                    started.add(e["name"])
                elif e["event"] == "end":
                    ends[e["name"]] = e
        held_back = sorted(n for n in started if n not in ends)
        meta.setdefault("resumes", []).append({"time": now(), "argv": sys.argv, "finished": len(ends),
                                               "held_back_interrupted": held_back})
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
        print(json.dumps({"resume": True, "already_finished": len(ends), "interrupted_held_back": held_back},
                         indent=1))
    else:
        out.mkdir(parents=True)
        (out / "runs").mkdir()
        (out / "logs").mkdir()
        source_sha = {t: {f: sha256_file(cache_dir(a.source_cache, t) / f) for f in CACHE_FILES} for t in TASKS}
        copies = {"source_sha256": source_sha, "gpus": {}}
        for g in gpus:
            for t in TASKS:
                dst = cache_dir(out / "ds_cache" / f"gpu{g}", t)
                dst.mkdir(parents=True)
                for f in CACHE_FILES:
                    shutil.copy2(cache_dir(a.source_cache, t) / f, dst / f)
                same = all(sha256_file(dst / f) == source_sha[t][f] for f in CACHE_FILES)
                copies["gpus"][f"{g}/{t}"] = same
                if not same:
                    print(f"STOP: the private {t} cache copy for GPU {g} differs from its source", file=sys.stderr)
                    return 2
        meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "repo_parent": parent,
                "files": FILES, "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
                "models": MODELS, "model_revisions": revs, "model_cache": str(Path(a.model_cache).resolve()),
                "model_pins": {k: pins[k] for k in MODELS}, "model_check_sha256": sha256_file(a.model_check),
                "parameters": parameters, "pilot_seeds": list(PILOT_SEEDS), "pilot_lrs": list(PILOT_LRS),
                "default_lr": DEFAULT_LR, "lr_margin": LR_MARGIN, "smoke": list(SMOKE),
                "gate_tolerance": GATE_TOLERANCE, "cuda_alloc_conf": CUDA_ALLOC_CONF,
                "pilot": [{"name": n, "model": m, "task": t, "seed": s, "learning_rate": lr} for n, m, t, s, lr in PILOT],
                "plan": [{"name": p[0], "model": p[1], "task": p[2], "seed": p[3], "arm": p[4], "score_source": p[5],
                          "controller": p[6], "n_phases": p[7], **p[8], "extra": p[9], "label": p[10]}
                         for p in PLAN]}
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
    pid_file.write_text(str(os.getpid()))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false",
                     "HF_HUB_CACHE": str(Path(a.model_cache).resolve()),
                     # the LLMs fill most of a 32 GB V100 and their batches change length: let the
                     # allocator grow its segments instead of fragmenting (no effect on the arithmetic;
                     # the model check runs with the same setting)
                     "PYTORCH_CUDA_ALLOC_CONF": CUDA_ALLOC_CONF})
    lock = threading.Lock()

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def run_queue(queue, gpu_list):
        """queue items: (name, cmd)"""
        def worker(gpu):
            while True:
                with lock:
                    if not queue:
                        return
                    name, cmd = queue.pop(0)
                env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu),
                           HF_DATASETS_CACHE=str(out / "ds_cache" / f"gpu{gpu}"))
                t0 = time.time()
                record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
                with open(out / "logs" / f"{name}.log", "wb") as log:
                    try:
                        rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=RUN_TIMEOUT).returncode
                    except subprocess.TimeoutExpired:
                        rc = "timeout"
                manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
                record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                        "seconds": round(time.time() - t0, 1), "manifests": manifests})

        threads = [threading.Thread(target=worker, args=(g,)) for g in gpu_list]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    def all_ends():
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e.get("event") == "end":
                    ends[e["name"]] = e
        return ends

    def finish(extra):
        ends = all_ends()
        done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends.values() if e["exit"] == 0),
                "failed": sorted(n for n, e in ends.items() if e["exit"] != 0), "held_back_interrupted": held_back}
        done.update(extra)
        (out / "DONE.json").write_text(json.dumps(done, indent=1))
        print(json.dumps(done, indent=1))
        try:
            pid_file.unlink()
        except FileNotFoundError:
            pass

    # --- stage 1: the learning-rate pilot and its rule, for each model ---
    rule_file = out / "LR_RULE.json"
    if not rule_file.is_file():
        def pilot_cost(x):
            return HORIZON[x[2]]["total_steps"] * STEP_SECONDS[(x[1], x[2])]

        pilot_queue = []
        for n, m, t, s, lr in sorted(PILOT, key=lambda x: (-pilot_cost(x), x[0])):
            if n in started:
                continue
            entry = _entry(n, m, t, s, "full_finetune")
            pilot_queue.append((n, command(a, revs, {m: lr}, *entry)))
        if pilot_queue:
            run_queue(pilot_queue, gpus)
        ends = all_ends()
        checks = {}
        rule = {"time": now(), "default_lr": DEFAULT_LR, "margin_points": LR_MARGIN, "models": {}}
        for n, m, t, s, lr in PILOT:
            fails, acc = pilot_check(out, n, m, t, lr, ends.get(n), revs[m], parameters[m])
            checks[n] = {"pass": not fails, "fails": fails, "accuracy": acc, "model": m, "task": t, "seed": s,
                         "learning_rate": lr}
        ok = all(c["pass"] for c in checks.values())
        rule["pass"] = ok
        rule["runs"] = checks
        if ok:
            for m in MODELS:
                accs = {lr: [c["accuracy"] for c in checks.values() if c["model"] == m and c["learning_rate"] == lr]
                        for lr in PILOT_LRS}
                choice, means, best = lr_rule(accs)
                rule["models"][m] = {"model_id": MODELS[m], "means": {repr(k): v for k, v in means.items()},
                                     "best": best, "choice": choice}
        rule_file.write_text(json.dumps(rule, indent=1))
        print(json.dumps({"lr_rule": {"pass": rule["pass"], "models": rule["models"]}}, indent=1))
        if not ok:
            finish({"stopped_at": "learning-rate pilot", "pilot_pass": False})
            return 3
    rule = json.loads(rule_file.read_text())
    lrs = {m: (rule.get("models") or {}).get(m, {}).get("choice") for m in MODELS}
    if any(lr not in PILOT_LRS for lr in lrs.values()):
        print(f"STOP: LR_RULE.json chose {lrs}", file=sys.stderr)
        return 2
    # --- stage 2: the smoke gate ---
    gate_file = out / "SMOKE_GATE.json"
    if not gate_file.is_file():
        smoke_queue = [(p[0], command(a, revs, lrs, *p)) for p in PLAN if p[0] in SMOKE and p[0] not in started]
        if smoke_queue:
            run_queue(smoke_queue, gpus)
        ends = all_ends()
        results = {p[0]: gate_check(out, p, ends.get(p[0]), lrs[p[1]], revs[p[1]], parameters[p[1]])
                   for p in PLAN if p[0] in SMOKE}
        gate = {"time": now(), "pass": all(not f for f in results.values()), "tolerance": GATE_TOLERANCE,
                "learning_rates": lrs, "runs": {n: {"pass": not f, "fails": f} for n, f in results.items()}}
        gate_file.write_text(json.dumps(gate, indent=1))
        print(json.dumps({"smoke_gate": gate}, indent=1))
        if not gate["pass"]:
            finish({"stopped_at": "smoke gate", "pilot_pass": True, "smoke_gate_pass": False, "learning_rates": lrs})
            return 3
    # --- stage 3: the other runs ---
    queue = [(p[0], command(a, revs, lrs, *p)) for p in PLAN if p[0] not in SMOKE and p[0] not in started]
    run_queue(queue, gpus)
    finish({"pilot_pass": True, "smoke_gate_pass": True, "learning_rates": lrs})
    return 0


if __name__ == "__main__":
    sys.exit(main())

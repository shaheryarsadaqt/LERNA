#!/usr/bin/env python3
"""LERNA round 18: check the three causal LLMs on a GPU before any training (9 November 2026).

  python -s -B LERNA_R18_MODEL_CHECK.py --repo /home/nanhangproj/LERNA --model-cache <private Hub cache> \\
      --pins <MODEL_PIN.llama.json> <MODEL_PIN.qwen.json> <MODEL_PIN.granite.json> \\
      --out MODEL_CHECK.json [--device cuda]

For each model, with the round-18 code of the checkout (lerna/utils/causal_lm_classifier.py):
  1. the files: every file of the pin is in the snapshot with the pinned SHA-256;
  2. the classifier: it loads with every tensor of the checkpoint and nothing unused, only the
     head (score.weight) new, FP32, eager attention, gradient checkpointing on; its parameter count
     equals the one computed from the configuration;
  3. the language model: on "The capital of France is", " Paris" is among the five most likely
     next tokens; the perplexity of a fixed English paragraph is below 40 (random weights give tens
     of thousands); the classifier's body gives the language model's own hidden states;
  4. the data: every MRPC and RTE example (train and validation, from the prepared caches, read
     only) in the round-18 format: the longest, the mean, and how many exceed 512 tokens (those
     would be truncated; none expected);
  5. memory: two training steps (forward, backward, gradient clipping, AdamW) on the worst batch the
     runs can meet, 32 copies of the longest training example, must fit on the GPU; the peak memory
     and the step time are recorded (and a typical batch's step time, for the time estimate).
PASS when every model passes 1-3 and 5 (4 is recorded). Writes only --out.
"""
import argparse
import gc
import hashlib
import json
import math
import sys
import time
from pathlib import Path

VERSION = "LERNA_R18_MODEL_CHECK 2026-11-09"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
TASKS = ("mrpc", "rte")
BATCH = 32
MAX_LENGTH = 512
PPL_MAX = 40.0
CUDA_ALLOC_CONF = "expandable_segments:True"
PROMPT = "The capital of France is"
PARAGRAPH = ("The water cycle describes how water moves around the Earth. Water evaporates from oceans, lakes and "
             "rivers, rises into the air as vapour, and cools to form clouds. When the droplets in the clouds grow "
             "heavy enough, they fall back to the ground as rain or snow. Some of this water flows into rivers and "
             "returns to the sea, while some soaks into the ground and is stored for many years.")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_parameters(cfg, num_labels=2):
    """Parameters of the body (embeddings, layers, final norm) plus the head, from the configuration."""
    h, L, V = int(cfg.hidden_size), int(cfg.num_hidden_layers), int(cfg.vocab_size)
    nh = int(cfg.num_attention_heads)
    nkv = int(getattr(cfg, "num_key_value_heads", None) or nh)
    hd = int(getattr(cfg, "head_dim", None) or h // nh)
    attn = h * nh * hd + 2 * h * nkv * hd + nh * hd * h
    if getattr(cfg, "attention_bias", False):
        attn += nh * hd + 2 * nkv * hd + h
    if cfg.model_type == "qwen3":
        attn += 2 * hd  # q_norm and k_norm
    i = int(cfg.intermediate_size)
    if cfg.model_type == "granitemoe":
        E = int(cfg.num_local_experts)
        mlp = E * (h * 2 * i + i * h) + h * E  # experts (input and output maps) and the router
    else:
        mlp = 3 * h * i
    layer = attn + mlp + 2 * h
    body = V * h + L * layer + h
    out = {"body": body, "head": h * num_labels, "total": body + h * num_labels}
    if cfg.model_type == "granitemoe":
        experts = L * int(cfg.num_local_experts) * (h * 2 * i + i * h)
        out["experts"] = experts
        out["active_per_token"] = out["total"] - experts + experts * int(cfg.num_experts_per_tok) // int(
            cfg.num_local_experts)
    return out


def glue_rows(source_cache, task, split):
    from datasets import Dataset

    f = Path(source_cache) / "glue" / task / "0.0.0" / GLUE_REV / f"glue-{split}.arrow"
    ds = Dataset.from_file(str(f), in_memory=True)
    return list(zip(ds["sentence1"], ds["sentence2"]))


def check_model(a, cl, model_id, pin, torch, dev):
    fails, rec = [], {"model_id": model_id, "revision": pin.get("revision")}
    rev = pin.get("revision")
    snap = Path(a.model_cache) / ("models--" + model_id.replace("/", "--")) / "snapshots" / str(rev)
    # 1. the files
    for fn, info in (pin.get("files") or {}).items():
        p = snap / fn
        if not p.is_file() or sha256_file(p) != info.get("sha256"):
            fails.append(f"file {fn} is missing or differs from the pin")
    if not pin.get("files"):
        fails.append("the pin lists no files")
    if fails:
        return rec, fails
    # 2. the classifier
    tok = cl.load_causal_lm_tokenizer(model_id, revision=rev)
    model = cl.load_causal_lm_for_sequence_classification(model_id, revision=rev, num_labels=2)
    rep = model.lerna_checkpoint_report
    rec["loading"] = rep
    if rep.get("missing_keys") or rep.get("unexpected_keys") or rep.get("mismatched_keys") or rep.get("new") != [
            "score.weight"]:
        fails.append(f"loading report {rep}")
    counts = cl.parameter_counts(model)
    want = expected_parameters(model.config)
    rec["parameters"] = counts
    rec["parameters_from_config"] = want
    if counts["total"] != want["total"] or counts.get("active_per_token") != want.get("active_per_token"):
        fails.append(f"parameter count {counts} differs from the configuration's {want}")
    dtypes = sorted({str(p.dtype) for p in model.parameters()})
    rec["dtypes"] = dtypes
    rec["attn_implementation"] = model.config._attn_implementation
    rec["gradient_checkpointing"] = model.is_gradient_checkpointing
    rec["model_type"] = model.config.model_type
    if dtypes != ["torch.float32"] or model.config._attn_implementation != "eager" or not model.is_gradient_checkpointing:
        fails.append(f"dtypes {dtypes}, attention {model.config._attn_implementation}, "
                     f"checkpointing {model.is_gradient_checkpointing}")
    if model.config.model_type != cl.CAUSAL_LM_MODELS[model_id][1]:
        fails.append(f"model_type {model.config.model_type}")
    rec["tokenizer"] = {"class": type(tok.tokenizer).__name__, "eos_token_id": tok.eos_token_id,
                        "pad_token_id": tok.pad_token_id, "pad_source": tok.pad_source,
                        "bos_token_id": tok.bos_token_id, "vocab": len(tok)}
    ex = tok("The cat sat on the mat.", "A cat was sitting on a mat.")["input_ids"]
    rec["example_ids"] = ex
    rec["example_text"] = tok.decode(ex)
    if ex[-1] != tok.eos_token_id or not rec["example_text"].startswith(
            ("Sentence 1:", tok.tokenizer.decode([tok.bos_token_id]) if tok.bos_token_id is not None else "\0")):
        fails.append(f"the example does not have the round-18 format: {rec['example_text']!r}")
    # 3. the language model
    lm, _ = cl.load_causal_lm(model_id, revision=rev)
    lm.to(dev).eval()
    hf = tok.tokenizer
    with torch.no_grad():
        ids = hf(PROMPT, return_tensors="pt")["input_ids"].to(dev)
        logits = lm(input_ids=ids).logits[0, -1].float()
        top = torch.topk(logits, 5).indices.tolist()
        rec["capital_top5"] = [hf.decode([t]) for t in top]
        if " Paris" not in rec["capital_top5"]:
            fails.append(f"' Paris' is not among the top 5 next tokens: {rec['capital_top5']}")
        p_ids = hf(PARAGRAPH, return_tensors="pt")["input_ids"].to(dev)
        out = lm(input_ids=p_ids, labels=p_ids)
        rec["paragraph_tokens"] = int(p_ids.shape[1])
        rec["paragraph_perplexity"] = float(math.exp(float(out.loss)))
        if not rec["paragraph_perplexity"] < PPL_MAX:
            fails.append(f"perplexity {rec['paragraph_perplexity']:.1f} >= {PPL_MAX}")
        model.to(dev).eval()
        batch = tok(["The cat sat on the mat.", "Two men played chess in the park on Sunday afternoon."],
                    ["A cat was sitting on a mat.", "Nobody played."], padding=True, return_tensors="pt")
        batch = {k: v.to(dev) for k, v in batch.items()}
        h1 = model.model(**batch, use_cache=False).last_hidden_state
        h2 = lm.model(**batch, use_cache=False).last_hidden_state
        m = batch["attention_mask"].bool()
        rec["body_vs_lm_max_abs_diff"] = float((h1 - h2)[m].abs().max())
        if not rec["body_vs_lm_max_abs_diff"] <= 1e-5:
            fails.append(f"the classifier's body differs from the language model's: {rec['body_vs_lm_max_abs_diff']}")
        rec["head_logits_example"] = model(**batch).logits.float().tolist()
    lm.to("cpu")
    del lm
    gc.collect()
    torch.cuda.empty_cache() if dev.type == "cuda" else None
    # 4. the data
    lengths = {}
    longest = (0, None)
    for task in TASKS:
        for split in ("train", "validation"):
            rows = glue_rows(a.source_cache, task, split)
            ls = [len(tok(s1, s2)["input_ids"]) for s1, s2 in rows]
            srt = sorted(ls)
            lengths[f"{task}/{split}"] = {"examples": len(ls), "max": srt[-1], "mean": round(sum(ls) / len(ls), 2),
                                          "p99": srt[int(0.99 * (len(srt) - 1))],
                                          "over_512": sum(1 for x in ls if x > MAX_LENGTH)}
            if split == "train":
                i = max(range(len(ls)), key=lambda k: ls[k])
                if ls[i] > longest[0]:
                    longest = (ls[i], (task, rows[i]))
    rec["lengths"] = lengths
    # 5. memory and time
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=1e-5, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01)
    task, (s1, s2) = longest[1]
    enc = tok([s1] * BATCH, [s2] * BATCH, truncation=True, max_length=MAX_LENGTH, padding=True, return_tensors="pt")
    labels = torch.tensor([i % 2 for i in range(BATCH)])
    typical = {}
    for t in TASKS:
        rows = glue_rows(a.source_cache, t, "train")
        ls = sorted(range(len(rows)), key=lambda k: len(tok(*rows[k])["input_ids"]))
        # a typical batch: its longest example is the 90th percentile (dynamic padding pads to it)
        k = ls[int(0.90 * (len(ls) - 1))]
        typical[t] = tok([rows[k][0]] * BATCH, [rows[k][1]] * BATCH, padding=True, return_tensors="pt")

    def step(b):
        b = {k: v.to(dev) for k, v in b.items()}
        if dev.type == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        out = model(**b, labels=labels.to(dev))
        out.loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        opt.zero_grad(set_to_none=True)
        if dev.type == "cuda":
            torch.cuda.synchronize()
        return time.perf_counter() - t0, float(out.loss)

    if dev.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    try:
        times = [step(enc) for _ in range(2)]
        rec["worst_batch"] = {"task": task, "length": int(enc["input_ids"].shape[1]), "batch": BATCH,
                              "seconds": [round(t, 3) for t, _ in times], "loss": [round(l, 4) for _, l in times]}
        if dev.type == "cuda":
            rec["worst_batch"]["peak_allocated_gib"] = round(torch.cuda.max_memory_allocated() / 2 ** 30, 2)
            rec["worst_batch"]["peak_reserved_gib"] = round(torch.cuda.max_memory_reserved() / 2 ** 30, 2)
            rec["worst_batch"]["device_total_gib"] = round(
                torch.cuda.get_device_properties(dev).total_memory / 2 ** 30, 2)
        for t, b in typical.items():
            st = [step(b)[0] for _ in range(2)]
            rec.setdefault("typical_batch", {})[t] = {"length": int(b["input_ids"].shape[1]),
                                                     "seconds": round(st[-1], 3)}
    except RuntimeError as e:
        fails.append(f"a training step failed: {type(e).__name__}: {str(e)[:300]}")
    del opt, model
    gc.collect()
    torch.cuda.empty_cache() if dev.type == "cuda" else None
    return rec, fails


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--model-cache", required=True)
    ap.add_argument("--pins", nargs=3, required=True)
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()
    out = Path(a.out)
    if out.exists():
        print(f"STOP: {out} already exists", file=sys.stderr)
        return 2
    import os

    os.environ["HF_HUB_CACHE"] = str(Path(a.model_cache).resolve())
    os.environ["HF_HUB_OFFLINE"] = "1"
    # the launcher's allocator setting, so the memory measured here is the runs' (set before torch loads)
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = CUDA_ALLOC_CONF
    sys.path.insert(0, str(Path(a.repo).resolve()))
    import torch
    from lerna.utils import causal_lm_classifier as cl

    impl = Path(a.repo) / "lerna" / "utils" / "causal_lm_classifier.py"
    dev = torch.device(a.device)
    report = {"version": VERSION, "time": time.strftime("%Y-%m-%d %H:%M:%S %z"), "device": a.device,
              "implementation_sha256": sha256_file(impl), "torch": torch.__version__, "models": {}, "fails": {},
              "cuda_alloc_conf": os.environ.get("PYTORCH_CUDA_ALLOC_CONF")}
    if dev.type == "cuda":
        report["gpu"] = torch.cuda.get_device_name(dev)
    import transformers

    report["transformers"] = transformers.__version__
    seen = set()
    for pin_file in a.pins:
        pin = json.loads(Path(pin_file).read_text())
        mid = pin.get("repo_id")
        if mid not in cl.CAUSAL_LM_MODELS or mid in seen:
            report["fails"][str(pin_file)] = [f"the pin names {mid!r}"]
            continue
        seen.add(mid)
        try:
            rec, fails = check_model(a, cl, mid, pin, torch, dev)
        except Exception as e:
            rec, fails = {"model_id": mid, "revision": pin.get("revision")}, [f"{type(e).__name__}: {str(e)[:500]}"]
        rec["pin_sha256"] = sha256_file(pin_file)
        report["models"][mid] = rec
        report["fails"][mid] = fails
        print(json.dumps({mid: {"fails": fails, "parameters": rec.get("parameters"),
                                "capital_top5": rec.get("capital_top5"),
                                "paragraph_perplexity": rec.get("paragraph_perplexity"),
                                "worst_batch": rec.get("worst_batch"), "typical_batch": rec.get("typical_batch")}},
                         indent=1), flush=True)
    report["pass"] = (len(seen) == 3 and set(seen) == set(cl.CAUSAL_LM_MODELS)
                      and not any(report["fails"].values()))
    out.write_text(json.dumps(report, indent=1))
    print(json.dumps({"pass": report["pass"], "fails": report["fails"]}, indent=1))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())

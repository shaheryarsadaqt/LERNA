#!/usr/bin/env python3
"""LERNA round 18: checks and the causal LLMs' pre-specified tables (9 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, LR_RULE.json, SMOKE_GATE.json, DONE.json,
runs/), the three MODEL_PIN files and MODEL_CHECK.json. It writes only check_report.json,
CHECK_SUMMARY.txt, FINAL_TABLE.csv and MAIN_TABLE.csv into the launcher's folder. Exit 0 means the
report was written; the verdict is inside it. Exit 2 means the folder isn't a finished launch.

Per run (the 36 pilot runs and the 144 runs of the comparison), it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, the learning rate (the
    pilot's own, or its model's rule choice), the model and its pinned revision for weights and
    tokenizer, the dataset revision, device, and each method's own options;
  - the exact counts and a final LR of 0;
  - the runtime block: interpreter, versions, GPU, the parameter count MODEL_CHECK.json recorded, no
    LayerNorm biases, eager attention, FP32, gradient checkpointing, the round-18 classifier and the
    model's type, AdamW betas and eps, the pinned GPU;
  - the batch log and each method's own accounting against it (LERNA v2 and random keep: the
    budget spent within 0.005, no example dropped in the warmup; InfoBatch: its schedule);
  - that every run with full fine-tuning's step count trained on full fine-tuning's scheduled
    batches (same model, task and seed), row for row.
It recomputes each model's learning-rate rule from the pilot runs and checks it against LR_RULE.json.

Then the reading fixed in claude/LERNA_R18_LLM_PLAN_2026-11-09.md:
  THE FINAL TABLE: each method on each model, MRPC and RTE accuracy (mean and sd over the seeds),
    their mean, and the measured compute;
  THE MAIN TABLE (the primary reading): seven contrasts of LERNA v2 (35% or 60%), each over the 18
    paired differences (3 models x 2 tasks x 3 seeds, paired by seed), a two-sided t-test, Holm over
    the seven rows; EDGE / LOSS / no significant difference. For LERNA v1 and InfoBatch, whose
    compute isn't controlled, LERNA v2 runs at its largest budget not above the method's measured
    compute (per model and task);
  per model (6 differences each) and per model and task (3 each): the same contrasts, exploratory;
  budget exactness, the measured compute of InfoBatch and LERNA v1, and wall-clock time.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R18_CHECK 2026-11-09"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "attn_implementation": "eager",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "implementation_sha256": "ae722af37ffa5d73053736ee6c14d57802adbad600613ed52e846088a68cbe98",
}
MODELS = {"llama": "alpindale/Llama-3.2-1B", "qwen": "Qwen/Qwen3-0.6B-Base",
          "granite": "ibm-granite/granite-3.1-1b-a400m-base"}
MODEL_NAME = {"llama": "Llama-3.2-1B", "qwen": "Qwen3-0.6B-Base", "granite": "Granite-3.1-1B-A400M (MoE)"}
MODEL_TYPE = {"llama": "llama", "qwen": "qwen3", "granite": "granitemoe"}
SEEDS = (11, 13, 17)
PILOT_SEEDS = (47, 53)
PILOT_LRS = (5e-6, 1e-5, 2e-5)
DEFAULT_LR = 1e-5
LR_MARGIN = 1.0
TASKS = ("mrpc", "rte")
TASK_NAME = {"mrpc": "MRPC", "rte": "RTE"}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
HORIZON = {"mrpc": 345, "rte": 234}
RATE = 0.60
LABELS = ("full_finetune", "plain_035", "equal_compute", "lerna2_nolr_b035", "lerna2_nolr_b060", "randkeep_b035",
          "infobatch", "gate_s1_p4")
LERNA2 = {"lerna2_nolr_b035": (0.35, True, False), "lerna2_nolr_b060": (0.60, True, False),
          "randkeep_b035": (0.35, False, False)}
LERNA2_OPTIONS = {"lerna2_pi_min": 0.1, "lerna2_window": 64, "lerna2_chunks": 16}
SELECTION_ARMS = ("infobatch",) + tuple(LERNA2)
GATES = ("gate_s1_p4",)
ARM_SPEC = {a: ("uniform", "legacy_v4", 1) for a in LABELS}
ARM_SPEC["gate_s1_p4"] = ("s1", "phase_exact_v1", 4)
BUDGET_TOLERANCE = 0.005
LABEL = {"full_finetune": "Full dataset, full fine-tuning", "plain_035": "Plain training, 35% of steps",
         "equal_compute": "Plain training, 60% of steps", "lerna2_nolr_b035": "LERNA v2, 35% (ours)",
         "lerna2_nolr_b060": "LERNA v2, 60% (ours)", "randkeep_b035": "Random keep, 35%",
         "infobatch": "InfoBatch (ICLR 2024)", "gate_s1_p4": "LERNA v1 (batch skipping)"}
FINAL_ROWS = ["full_finetune", "infobatch", "gate_s1_p4", "equal_compute", "lerna2_nolr_b060", "plain_035",
              "randkeep_b035", "lerna2_nolr_b035"]
BUDGETS = (("lerna2_nolr_b035", 0.35), ("lerna2_nolr_b060", 0.60))
MAIN = [("vs_plain_35", "lerna2_nolr_b035", "plain_035"), ("vs_random_keep_35", "lerna2_nolr_b035", "randkeep_b035"),
        ("vs_full_35", "lerna2_nolr_b035", "full_finetune"), ("vs_plain_60", "lerna2_nolr_b060", "equal_compute"),
        ("vs_lerna_v1", "auto", "gate_s1_p4"), ("vs_infobatch", "auto", "infobatch"),
        ("vs_full_60", "lerna2_nolr_b060", "full_finetune")]


def lr_rule(accuracies):
    means = {lr: sum(v) / len(v) for lr, v in accuracies.items()}
    best = max(PILOT_LRS, key=lambda lr: (means[lr], lr == DEFAULT_LR, -lr))
    choice = best if means[best] - means[DEFAULT_LR] > LR_MARGIN else DEFAULT_LR
    return choice, means, best


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm == "plain_035":
        eff, skips = int(round(0.35 * T)), 0
    elif arm in GATES:
        eff, skips = T, q
    else:
        eff, skips = T, 0
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def _betacf(a, b, x):
    tiny, eps = 1e-300, 1e-15
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def betainc(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x)
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbeta) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbeta) * _betacf(b, a, 1.0 - x) / b


def t_two_sided_p(t, df):
    return betainc(df / 2.0, 0.5, df / (df + t * t))


def t975(df):
    """The 97.5% quantile of Student's t with df degrees of freedom (bisection on the p-value)."""
    lo, hi = 0.0, 100.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if t_two_sided_p(mid, df) > 0.05:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def holm(pvals):
    idx = [i for i, p in enumerate(pvals) if isinstance(p, (int, float))]
    order = sorted(idx, key=lambda i: pvals[i])
    m = len(order)
    adj = [None] * len(pvals)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * pvals[i]))
        adj[i] = running
    return adj


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def summarize(values):
    """values: {unit: difference}. Mean, sd, the t-test against 0 and its 95% interval."""
    vals = [g for g in values.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0),
           "negative": sum(1 for g in vals if g < 0), "by_unit": values}
    if n >= 2 and sd is not None:
        half = t975(n - 1) * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
        if sd > 0:
            out["p"] = t_two_sided_p(m / (sd / math.sqrt(n)), n - 1)
        else:
            out["p"] = 1.0 if m == 0 else 0.0
    return out


def read_out(d, pa):
    if d["n"] < 3 or pa is None:
        return "too few pairs"
    if pa < 0.05 and d["mean"] > 0:
        return "EDGE"
    if pa < 0.05 and d["mean"] < 0:
        return "LOSS"
    return "no significant difference"


def check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts):
    """LERNA v2, random keep and InfoBatch: each method's own accounting against its batch log."""
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    W = exp["warmup"]
    sched_tokens = sum(int(x[8]) for x in rows) if rows else None
    sched_examples = sum(int(x[7]) for x in rows) if rows else None
    if arm in LERNA2:
        budget, scores, lr = LERNA2[arm]
        for k, want in (("policy", "lerna_budget"), ("selection", "sample"), ("budget", budget),
                        ("use_scores", scores), ("use_lr_weight", lr), ("pi_min", 0.1), ("window", 64),
                        ("chunks", 16), ("warmup_steps", W), ("total_steps", T), ("steps_seen", T),
                        ("batches_per_epoch", bpe), ("num_examples", n_train), ("pruned_examples", dropped),
                        ("pruned_during_warmup", 0)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        rf = sel.get("realized_fraction")
        need(isinstance(rf, (int, float)) and abs(rf - budget) <= BUDGET_TOLERANCE,
             f"spent {rf} of the scheduled compute, budget {budget} +/- {BUDGET_TOLERANCE}")
        need(dropped > 0, "no example dropped")
        if rows:
            need(sel.get("spent_units") == units_of(rows), "policy spent units differ from the batch log")
            need(sel.get("scheduled_units") == 3 * sched_tokens, "policy scheduled units differ from the batch log")
            need(sel.get("scheduled_examples") == sched_examples, "policy scheduled examples differ from the batch log")
        need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
             "kept + pruned differ from the scheduled examples")
        mw = sel.get("max_weight")
        need(isinstance(mw, (int, float)) and mw <= 10.0 + 1e-9, f"max_weight={mw}")
        facts["realized_fraction"] = rf
    elif arm == "infobatch":
        need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
        need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
        need(sel.get("stop_prune_step") == int(math.floor(0.875 * T + 1e-9)), "stop_prune_step differs")
        need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
        need(len(sel.get("thresholds") or []) == math.ceil(T / bpe), "one threshold per epoch expected")
        need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
        need(dropped > 0, "no example dropped in a run longer than one epoch")


def check_run(p, end, out, rev, lr, parameters, source):
    name, model, task, arm, seed = p["name"], p["model"], p["task"], p["arm"], p["seed"]
    label = p.get("label", arm)
    T = p["total_steps"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "model": model, "task": task, "arm": arm, "label": label, "seed": seed, "total_steps": T,
            "learning_rate": lr, "source": source}
    need(T == HORIZON.get(task), f"total_steps {T} for {task}")
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, T)
    eff = exp["effective_total"]
    mid = MODELS[model]
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", T),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_id", mid), ("tokenizer_id", mid),
                 ("model_revision", rev), ("tokenizer_revision", rev), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False), ("train_batch_size", BATCH_SIZE),
                 ("learning_rate", lr), ("weight_decay", 0.01), ("grad_clip", 1.0), ("probe_exclusions_hash", None),
                 ("max_length", 512), ("target_skip_rate", RATE)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    need(r.get("learning_rate") == lr, f"result learning_rate={r.get('learning_rate')}, expected {lr}")
    need(p["min_step"] == int(math.floor(0.06 * T + 1e-9)), f"min_step {p['min_step']} is not the warmup of {T}")
    if arm in LERNA2:
        for k, v in LERNA2_OPTIONS.items():
            need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        need((c.get("infobatch_prune_ratio"), c.get("infobatch_anneal_fraction")) == (0.5, 0.875),
             f"InfoBatch options {c.get('infobatch_prune_ratio')}, {c.get('infobatch_anneal_fraction')}")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == eff - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == eff, f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm not in SELECTION_ARMS:
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    if task == "mrpc":
        need(isinstance(r.get("final_eval_f1"), (int, float)), "MRPC F1 missing")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    need(rt.get("model_dtype") == "torch.float32", f"model_dtype {rt.get('model_dtype')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(rt.get("parameters") == parameters, f"parameters={rt.get('parameters')}, the model check recorded {parameters}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    need(rt.get("gradient_checkpointing") is True, f"gradient_checkpointing={rt.get('gradient_checkpointing')}")
    need(rt.get("model_class") == "CausalLMForSequenceClassification", f"model_class={rt.get('model_class')}")
    need(rt.get("model_type") == MODEL_TYPE[model], f"model_type={rt.get('model_type')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("class") == "AdamW", f"optimizer {opt.get('class')}")
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    need(opt.get("initial_lr") == lr, f"optimizer initial_lr={opt.get('initial_lr')}, expected {lr}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if not ok_shape:
            rows = []
        if rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            need(all(int(x[6]) == 1 for x in rows), "a row without a forward pass")
            need(all(math.isfinite(float(x[5])) for x in rows), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) <= int(x[8]) for x in rows),
                 "real tokens must be positive and at most the padded, and those at most the scheduled")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm not in SELECTION_ARMS:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            if arm in LERNA2:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows[:exp["warmup"]]), "an example dropped during the warmup")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    if arm in SELECTION_ARMS:
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts)
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    units = units_of(rows) if rows else None
    facts.update(accuracy=acc, loss=loss, f1=r.get("final_eval_f1"), wall_seconds=r.get("wall_seconds"),
                 examples_dropped=dropped, units=units)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True, help="the launcher's folder")
    ap.add_argument("--model-pins", nargs=3, required=True)
    ap.add_argument("--model-check", required=True)
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECT[k] = v if v != "" else None
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    meta = json.loads((out / "plan.json").read_text())
    mc = json.loads(Path(a.model_check).read_text())
    integrity_fails, notes = [], []
    pins, revs, parameters = {}, {}, {}
    by_id = {v: k for k, v in MODELS.items()}
    for pf in a.model_pins:
        pin = json.loads(Path(pf).read_text())
        key = by_id.get(pin.get("repo_id"))
        if key is None or key in pins:
            integrity_fails.append(f"{pf} names {pin.get('repo_id')}")
            continue
        pins[key], revs[key] = pin, pin.get("revision")
        rec = (mc.get("models") or {}).get(MODELS[key]) or {}
        if rec.get("revision") != revs[key] or (meta.get("model_revisions") or {}).get(key) != revs[key]:
            integrity_fails.append(f"{MODELS[key]}: revisions differ: pin {revs[key]}, check {rec.get('revision')}, "
                                   f"plan {(meta.get('model_revisions') or {}).get(key)}")
        if rec.get("pin_sha256") != sha256_file(pf):
            integrity_fails.append(f"{MODELS[key]}: MODEL_CHECK.json read another pin")
        if (meta.get("model_pins") or {}).get(key) != pin:
            integrity_fails.append(f"{MODELS[key]}: the plan's copy of the pin differs from --model-pins")
        parameters[key] = (rec.get("parameters") or {}).get("total")
        if (meta.get("parameters") or {}).get(key) != parameters[key]:
            integrity_fails.append(f"{MODELS[key]}: parameter counts differ between the plan and the model check")
        if key == "llama":
            st = (pin.get("reference") or {}).get("status")
            if st != "identical":
                notes.append(f"the Llama copy's comparison with Meta's listing: {st}")
    if set(pins) != set(MODELS):
        integrity_fails.append(f"pins for {sorted(pins)}, expected {sorted(MODELS)}")
        return_early = True
    else:
        return_early = False
    if mc.get("pass") is not True:
        integrity_fails.append("MODEL_CHECK.json did not pass")
    if EXPECT["implementation_sha256"] and mc.get("implementation_sha256") != EXPECT["implementation_sha256"]:
        integrity_fails.append("MODEL_CHECK.json checked another lerna/utils/causal_lm_classifier.py")
    if meta.get("model_check_sha256") != sha256_file(a.model_check):
        integrity_fails.append("MODEL_CHECK.json differs from the one the launch read")
    if return_early:
        print("; ".join(integrity_fails), file=sys.stderr)
        return 2
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    # the plan itself: every model, task, method and seed once, and the pilot
    want = {(m, t, lab, s) for m in MODELS for t in TASKS for lab in LABELS for s in SEEDS}
    have = [(p["model"], p["task"], p.get("label", p["arm"]), p["seed"]) for p in meta["plan"]]
    if len(have) != len(set(have)) or set(have) != want:
        integrity_fails.append(f"the plan differs from the fixed plan ({len(set(have) ^ want)} entries differ)")
    for p in meta["plan"]:
        spec = ARM_SPEC.get(p["arm"])
        if spec is None or (p["score_source"], p["controller"], p["n_phases"]) != spec or p.get("extra"):
            integrity_fails.append(f"{p['name']}: the plan's arm settings differ")
    want_pilot = {(m, t, s, lr) for m in MODELS for t in TASKS for s in PILOT_SEEDS for lr in PILOT_LRS}
    have_pilot = {(x["model"], x["task"], x["seed"], x["learning_rate"]) for x in meta.get("pilot", [])}
    if have_pilot != want_pilot or len(meta.get("pilot", [])) != len(want_pilot):
        integrity_fails.append("the pilot differs from the fixed pilot")
    # the pilot and each model's rule
    pilot_runs = []
    accs = {m: {lr: [] for lr in PILOT_LRS} for m in MODELS}
    for x in meta.get("pilot", []):
        t = x["task"]
        p = {"name": x["name"], "model": x["model"], "task": t, "arm": "full_finetune", "label": "full_finetune",
             "seed": x["seed"], "total_steps": HORIZON[t], "min_step": int(math.floor(0.06 * HORIZON[t] + 1e-9)),
             "controller": "legacy_v4", "n_phases": 1, "score_source": "uniform"}
        run = check_run(p, ends.get(x["name"]), out, revs[x["model"]], x["learning_rate"], parameters[x["model"]],
                        "pilot")
        pilot_runs.append(run)
        if run["ok"]:
            accs[x["model"]][x["learning_rate"]].append(100.0 * run["facts"]["accuracy"])
        else:
            integrity_fails.append(f"pilot {x['name']}: " + "; ".join(run["fails"][:3]))
    rule_file = json.loads((out / "LR_RULE.json").read_text()) if (out / "LR_RULE.json").is_file() else {}
    rules, lrs = {}, {}
    for m in MODELS:
        launcher = ((rule_file.get("models") or {}).get(m) or {}).get("choice")
        rules[m] = {"launcher": launcher, "recomputed": None}
        lrs[m] = launcher
        if all(len(v) == len(TASKS) * len(PILOT_SEEDS) for v in accs[m].values()):
            choice, means, best = lr_rule(accs[m])
            per_task = {repr(lr): {TASK_NAME[t]: mean_sd([100.0 * r_["facts"]["accuracy"] for r_ in pilot_runs
                                                          if r_["ok"] and r_["model"] == m and r_["task"] == t
                                                          and r_["learning_rate"] == lr])[0] for t in TASKS}
                        for lr in PILOT_LRS}
            rules[m].update(recomputed=choice, means={repr(k): v for k, v in means.items()}, best=best,
                            per_task=per_task)
            if choice != launcher:
                integrity_fails.append(f"LR_RULE.json chose {launcher} for {m}, the rule gives {choice}")
        else:
            integrity_fails.append(f"the pilot of {m} is incomplete; the rule cannot be recomputed")
    gate = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
    if gate is None or not gate.get("pass"):
        integrity_fails.append("the smoke gate did not pass" if gate else "SMOKE_GATE.json missing")
    runs = [check_run(p, ends.get(p["name"]), out, revs[p["model"]], lrs[p["model"]], parameters[p["model"]],
                      "round 18") for p in meta["plan"]]
    for x in runs:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    table = {(x["model"], x["task"], x["label"], x["seed"]): x for x in runs}
    # every run with full fine-tuning's step count trained on full fine-tuning's scheduled batches,
    # and the shorter plain runs on its first batches
    same_batches = {}
    for x in runs:
        if x["arm"] == "full_finetune" or not x.get("log_rows"):
            continue
        full = table.get((x["model"], x["task"], "full_finetune", x["seed"]))
        frows = [(int(r_[3]), int(r_[2])) for r_ in (full or {}).get("log_rows") or []]
        mine = [(int(r_[7]), int(r_[8])) for r_ in x["log_rows"]]
        same = bool(frows) and len(mine) <= len(frows) and frows[:len(mine)] == mine
        same_batches[x["name"]] = same
        if not same:
            integrity_fails.append(f"{x['name']}: scheduled batches differ from full fine-tuning's")
    # measured compute, relative to full fine-tuning of the same model, task and seed
    for key, x in table.items():
        full = table.get((key[0], key[1], "full_finetune", key[3]))
        u, fu = x["facts"].get("units"), (full or {}).get("facts", {}).get("units")
        x["facts"]["compute"] = (u / fu) if (u and fu and full.get("ok")) else None

    def acc(m, t, lab, s):
        x = table.get((m, t, lab, s))
        return 100.0 * x["facts"]["accuracy"] if x and x["ok"] else None

    cells = {}
    for m in MODELS:
        for t in TASKS:
            full_wall = mean_sd([(table.get((m, t, "full_finetune", s)) or {}).get("facts", {}).get("wall_seconds")
                                 for s in SEEDS])[0]
            methods = {}
            for lab in LABELS:
                xs = [table.get((m, t, lab, s)) for s in SEEDS]
                ok = [x for x in xs if x and x["ok"]]
                accs_l = [100.0 * x["facts"]["accuracy"] for x in ok]
                f1s = [100.0 * x["facts"]["f1"] for x in ok if isinstance(x["facts"].get("f1"), (int, float))]
                cs = [x["facts"].get("compute") for x in ok]
                walls = [x["facts"].get("wall_seconds") for x in ok]
                mw = mean_sd(walls)[0]
                rfs = [x["facts"].get("realized_fraction") for x in ok if x["facts"].get("realized_fraction") is not None]
                methods[lab] = {"n_runs": len(ok), "mean_accuracy": mean_sd(accs_l)[0], "sd_accuracy": mean_sd(accs_l)[1],
                                "accuracy_by_seed": {s: acc(m, t, lab, s) for s in SEEDS},
                                "mean_f1": mean_sd(f1s)[0], "mean_compute": mean_sd(cs)[0],
                                "min_compute": min([c_ for c_ in cs if isinstance(c_, (int, float))], default=None),
                                "max_compute": max([c_ for c_ in cs if isinstance(c_, (int, float))], default=None),
                                "mean_wall_seconds": mw,
                                "wall_fraction": (mw / full_wall) if (full_wall and mw) else None,
                                "max_budget_deviation": max([abs(v_ - LERNA2[lab][0]) for v_ in rfs], default=None)
                                if lab in LERNA2 else None}
            cells[(m, t)] = methods

    def resolve(m, t, la, lb):
        if la != "auto":
            return la, None
        cmp_c = cells[(m, t)][lb]["mean_compute"]
        fits = [k for k, b in BUDGETS if isinstance(cmp_c, (int, float)) and b <= cmp_c + 0.01]
        return (fits[-1] if fits else BUDGETS[0][0]), cmp_c

    def contrast(units_keys, la, lb):
        vals, used = {}, {}
        for (m, t, s) in units_keys:
            arm_a, cmp_c = resolve(m, t, la, lb)
            used[f"{m}/{t}"] = {"lerna_v2": arm_a, "compared_compute": cmp_c}
            va, vb = acc(m, t, arm_a, s), acc(m, t, lb, s)
            if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                vals[f"{m}/{t}/{s}"] = va - vb
        d = summarize(vals)
        d["lerna_v2_used"] = used
        return d

    all_units = [(m, t, s) for m in MODELS for t in TASKS for s in SEEDS]
    main_rows = []
    for key, la, lb in MAIN:
        d = contrast(all_units, la, lb)
        d.update(key=key, compared=lb, lerna_v2=la)
        main_rows.append(d)
    for r_, pa in zip(main_rows, holm([r_.get("p") for r_ in main_rows])):
        r_["p_holm"] = pa
        r_["reading"] = read_out(r_, pa)
    per_model = {}
    for m in MODELS:
        rows_m = []
        for key, la, lb in MAIN:
            d = contrast([(m, t, s) for t in TASKS for s in SEEDS], la, lb)
            d.update(key=key, compared=lb, lerna_v2=la, reading_unadjusted=(
                "EDGE" if d.get("p", 1) < 0.05 and d["mean"] > 0 else
                "LOSS" if d.get("p", 1) < 0.05 and d["mean"] < 0 else "no significant difference"))
            rows_m.append(d)
        per_model[m] = rows_m
    per_cell = {}
    for m in MODELS:
        for t in TASKS:
            per_cell[f"{m}/{t}"] = [dict(contrast([(m, t, s) for s in SEEDS], la, lb), key=key, compared=lb)
                                    for key, la, lb in MAIN]
    # THE FINAL TABLE
    final_table = []
    for lab in FINAL_ROWS:
        row = {"row": lab, "name": LABEL[lab], "ours": lab.startswith("lerna2"), "models": {}}
        comps, overall = [], []
        for m in MODELS:
            row["models"][m] = {}
            means = []
            for t in TASKS:
                d = cells[(m, t)][lab]
                row["models"][m][t] = {"mean": d["mean_accuracy"], "sd": d["sd_accuracy"], "n": d["n_runs"],
                                       "f1": d["mean_f1"], "compute": d["mean_compute"]}
                means.append(d["mean_accuracy"])
                comps.append(d["mean_compute"])
            ok_means = [v_ for v_ in means if isinstance(v_, (int, float))]
            row["models"][m]["mean"] = sum(ok_means) / len(ok_means) if len(ok_means) == len(TASKS) else None
            overall.append(row["models"][m]["mean"])
        row["mean_over_models"] = (sum(overall) / len(overall)) if all(isinstance(v_, (int, float)) for v_ in overall) else None
        row["mean_compute"] = mean_sd(comps)[0]
        final_table.append(row)
    final_table.sort(key=lambda r_: (-(r_["mean_compute"] or 0.0), r_["ours"]))
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails, "notes": notes,
              "models": {m: {"id": MODELS[m], "revision": revs[m], "parameters": parameters[m],
                             "check": {k: ((mc.get("models") or {}).get(MODELS[m]) or {}).get(k)
                                       for k in ("parameters", "capital_top5", "paragraph_perplexity", "lengths",
                                                 "worst_batch", "typical_batch", "tokenizer")},
                             "reference": pins[m].get("reference"), "pin_files": pins[m].get("files")}
                         for m in MODELS},
              "model_check_pass": mc.get("pass"), "lr_rules": rules, "learning_rates": lrs, "smoke_gate": gate,
              "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "pilot_ok": sum(1 for x in pilot_runs if x["ok"]), "pilot_planned": len(pilot_runs),
              "same_scheduled_batches": same_batches, "final_table": final_table, "main_table": main_rows,
              "per_model": per_model, "per_model_task": per_cell,
              "cells": {f"{m}/{t}": v_ for (m, t), v_ in cells.items()},
              "pilot_runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in pilot_runs],
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    def ci_text(d):
        ci = d.get("ci95")
        return f"[{num(ci[0] if ci else None, '+.2f')}, {num(ci[1] if ci else None, '+.2f')}]"

    with open(out / "FINAL_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        head = ["method", "arm", "compute"]
        for m in MODELS:
            head += [f"{MODEL_NAME[m]} {TASK_NAME[t]}" for t in TASKS] + [f"{MODEL_NAME[m]} sd {TASK_NAME[t]}" for t in TASKS]
            head += [f"{MODEL_NAME[m]} mean"]
        w.writerow(head + ["mean over models"])
        for r_ in final_table:
            row = [r_["name"], r_["row"], num(r_["mean_compute"], ".3f")]
            for m in MODELS:
                row += [num(r_["models"][m][t]["mean"], ".2f") for t in TASKS]
                row += [num(r_["models"][m][t]["sd"], ".2f") for t in TASKS]
                row += [num(r_["models"][m]["mean"], ".2f")]
            w.writerow(row + [num(r_["mean_over_models"], ".2f")])
    with open(out / "MAIN_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["scope", "contrast", "LERNA v2", "compared", "n", "mean difference", "sd", "ci95 low", "ci95 high",
                    "p", "p (Holm)", "reading"])
        for r_ in main_rows:
            ci = r_.get("ci95") or [None, None]
            w.writerow(["pooled", r_["key"], r_["lerna_v2"], r_["compared"], r_["n"], num(r_["mean"], ".3f"),
                        num(r_["sd"], ".3f"), num(ci[0], ".3f"), num(ci[1], ".3f"), num(r_.get("p"), ".4f"),
                        num(r_.get("p_holm"), ".4f"), r_["reading"]])
        for m, rows_m in per_model.items():
            for r_ in rows_m:
                ci = r_.get("ci95") or [None, None]
                w.writerow([MODEL_NAME[m], r_["key"], r_["lerna_v2"], r_["compared"], r_["n"], num(r_["mean"], ".3f"),
                            num(r_["sd"], ".3f"), num(ci[0], ".3f"), num(ci[1], ".3f"), num(r_.get("p"), ".4f"), "",
                            r_["reading_unadjusted"] + " (unadjusted)"])
    lines = ["=" * 100, "LERNA ROUND-18 CHECK: CAUSAL LLMs (Llama-3.2-1B, Qwen3-0.6B-Base, Granite-3.1-1B-A400M)", "=" * 100,
             f"integrity: {verdict}" + (f" ({len(integrity_fails)} problems)" if integrity_fails else "")]
    lines += [f"  - {x}" for x in integrity_fails[:40]]
    lines += [f"note: {x}" for x in notes]
    lines.append(f"pilot runs passing their checks: {report['pilot_ok']} of {report['pilot_planned']}; "
                 f"comparison runs: {report['runs_ok']} of {report['runs_planned']}; "
                 f"smoke gate: {(gate or {}).get('pass')}")
    for m in MODELS:
        ck = report["models"][m]["check"]
        pr = ck.get("parameters") or {}
        lines.append(f"{MODEL_NAME[m]}: {MODELS[m]}@{revs[m]}, {num(pr.get('total'), ',')} parameters"
                     + (f" ({num(pr.get('active_per_token'), ',')} used per token)" if pr.get('active_per_token') else "")
                     + f"; learning rate {lrs[m]} (pilot means {rules[m].get('means')})")
        if m == "llama":
            lines.append(f"  the copy against Meta's listing: {(pins[m].get('reference') or {}).get('status')}")
    lines.append("")
    lines.append("THE FINAL TABLE: accuracy (%), mean (sd) over seeds 11, 13, 17; compute relative to full fine-tuning")
    head = f"{'method':34s} {'compute':>7s}"
    for m in MODELS:
        head += f" | {MODEL_NAME[m][:14]:>14s}: {'MRPC':>12s} {'RTE':>12s} {'mean':>6s}"
    lines.append(head + f" | {'all':>6s}")
    for r_ in final_table:
        s_ = f"{r_['name'][:34]:34s} {num(r_['mean_compute'], '.3f'):>7s}"
        for m in MODELS:
            cellv = r_["models"][m]
            s_ += (f" | {'':14s}  {num(cellv['mrpc']['mean'], '.2f'):>6s} ({num(cellv['mrpc']['sd'], '.2f'):>4s})"
                   f" {num(cellv['rte']['mean'], '.2f'):>6s} ({num(cellv['rte']['sd'], '.2f'):>4s}) {num(cellv['mean'], '.2f'):>6s}")
        lines.append(s_ + f" | {num(r_['mean_over_models'], '.2f'):>6s}")
    lines.append("")
    lines.append("THE MAIN TABLE (primary): LERNA v2 minus the compared method, 18 pairs (3 models x 2 tasks x 3 seeds),"
                 " two-sided t-test, Holm over the 7 rows")
    for r_ in main_rows:
        used = sorted({v_["lerna_v2"] for v_ in r_["lerna_v2_used"].values()})
        lines.append(f"  {r_['key']:18s} v2 {'/'.join(u.replace('lerna2_nolr_', '') for u in used):9s} "
                     f"vs {r_['compared']:16s} n={r_['n']:2d} diff {num(r_['mean'], '+.2f'):>6s} "
                     f"CI {ci_text(r_)} p={num(r_.get('p'), '.4f')} Holm={num(r_.get('p_holm'), '.4f')} "
                     f"+{r_['positive']}/-{r_['negative']}  {r_['reading']}")
    lines.append("")
    lines.append("PER MODEL (exploratory, 6 pairs each, unadjusted)")
    for m, rows_m in per_model.items():
        lines.append(f"  {MODEL_NAME[m]}")
        for r_ in rows_m:
            lines.append(f"    {r_['key']:18s} diff {num(r_['mean'], '+.2f'):>6s} CI {ci_text(r_)} "
                         f"p={num(r_.get('p'), '.4f')}  {r_['reading_unadjusted']}")
    lines.append("")
    lines.append("PER MODEL AND TASK (descriptive, 3 pairs each): mean difference (sd)")
    for k_, rows_c in per_cell.items():
        lines.append(f"  {k_:14s} " + "  ".join(f"{r_['key'].replace('vs_', '')}: {num(r_['mean'], '+.2f')} "
                                                f"({num(r_['sd'], '.2f')})" for r_ in rows_c))
    lines.append("")
    lines.append("BUDGET EXACTNESS, COMPUTE AND WALL-CLOCK (per model and task)")
    for (m, t), methods in cells.items():
        lines.append(f"  {MODEL_NAME[m]} {TASK_NAME[t]}: "
                     + "; ".join(f"{lab}: compute {num(d['mean_compute'], '.3f')}"
                                 + (f" (max dev {num(d['max_budget_deviation'], '.4f')})" if d['max_budget_deviation'] is not None else "")
                                 + f", wall {num(d['wall_fraction'], '.2f')}" for lab, d in methods.items()))
    (out / "CHECK_SUMMARY.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())

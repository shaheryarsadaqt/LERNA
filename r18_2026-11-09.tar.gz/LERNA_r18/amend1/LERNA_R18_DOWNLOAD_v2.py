#!/usr/bin/env python3
"""LERNA round 18: fetch one of the three causal LLMs into the private Hub cache and pin it
(9 November 2026; amendment 1, 22:10: resumable).

Amendment 1. The first Llama download broke at 2.21 of 2.47 GB (IncompleteRead, exit 1), leaving the
commit's snapshot folder with config.json and a partial weight file. This version is the original
with two changes, and nothing else:
  - --resume: continue a download whose snapshot folder for the same commit already exists (and
    has no pin). huggingface_hub resumes each partial file from its .incomplete bytes; every file
    is then checked exactly as before (sizes, git blob ids, LFS SHA-256, Meta's listing, the known
    Llama SHA-256) before the pin is written.
  - a broken transfer (ChunkedEncodingError, ConnectionError, a timeout) is resumed in place, at
    most 6 attempts per file, 15 s apart; then it stops with exit 6. Nothing is ever deleted.

  python -s -B LERNA_R18_DOWNLOAD.py --repo <model id> --cache <dir> --pin <MODEL_PIN file>
      [--endpoint https://huggingface.co]

The models (the plan, claude/LERNA_R18_LLM_PLAN_2026-11-09.md):
  alpindale/Llama-3.2-1B                  Meta's Llama-3.2-1B. Meta's repository (meta-llama/Llama-3.2-1B)
                                          is gated and refuses many requests from China; this public copy
                                          is compared file by file with Meta's listing (below).
  Qwen/Qwen3-0.6B-Base                    from Alibaba's own repository
  ibm-granite/granite-3.1-1b-a400m-base   from IBM's own repository

It reads the repository's current commit and its file listing (sizes, git blob ids, LFS SHA-256),
downloads only what a model needs (config.json, the tokenizer files, the safetensors weights and
their index; never a code file), and checks every file: its size, its git blob id (small files)
or its SHA-256 (weights) against the listing.

For the Llama copy it also:
  - requires model.safetensors to have the SHA-256 that two independent public copies of
    Llama-3.2-1B share (68a2e4be...), and
  - reads Meta's own listing of meta-llama/Llama-3.2-1B (public metadata; the files themselves are
    gated) and compares every downloaded file with Meta's: same git blob id or same SHA-256.
    Every file identical: "identical". Meta's listing unreachable: "unavailable" (recorded; the
    download stands on the SHA-256 check). Any file different or absent: exit 5, nothing pinned.

Writes only into --cache (which must not already hold this commit) and --pin (which must not
exist). Nothing is executed from the downloaded files.
Exit codes: 0 done; 2 a check failed; 4 the endpoint is not reachable; 5 the Llama copy differs
from Meta's listing; 6 a file's transfer broke 6 times.

The fallback, when the server cannot reach any endpoint (the user copies the files in):
  python -s -B LERNA_R18_DOWNLOAD.py --repo <model id> --cache <dir> --pin <file> \\
      --from-folder <folder> --revision <40-hex commit>
"""
import argparse
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

VERSION = "LERNA_R18_DOWNLOAD 2026-11-09b (amendment 1, resumable)"
MAX_ATTEMPTS = 6
RETRY_SECONDS = 15
MODELS = ("alpindale/Llama-3.2-1B", "Qwen/Qwen3-0.6B-Base", "ibm-granite/granite-3.1-1b-a400m-base")
REFERENCE = {"alpindale/Llama-3.2-1B": "meta-llama/Llama-3.2-1B"}
KNOWN_SHA256 = {"alpindale/Llama-3.2-1B": {
    "model.safetensors": "68a2e4be76fa709455a60272fba8e512c02d81c46e6c671cc9449e374fd6809a"}}
WANTED_EXACT = ("config.json", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
                "vocab.json", "merges.txt", "model.safetensors", "model.safetensors.index.json")
REQUIRED = ("config.json", "tokenizer.json", "tokenizer_config.json")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha1(p):
    """The id git (and the Hub) gives a file's content: sha1(b"blob <size>\\0" + content)."""
    size = Path(p).stat().st_size
    h = hashlib.sha1(b"blob %d\x00" % size)
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def is_commit(s):
    return isinstance(s, str) and len(s) == 40 and all(c in "0123456789abcdef" for c in s)


def wanted(name):
    if "/" in name:
        return False
    return name in WANTED_EXACT or (name.startswith("model-") and name.endswith(".safetensors"))


def snapshot(cache, repo, rev):
    return Path(cache) / ("models--" + repo.replace("/", "--")) / "snapshots" / rev


def listing(api, repo, revision=None):
    """{'sha', 'last_modified', 'license', 'gated', 'files': {name: {size, blob_id, lfs_sha256}}}"""
    info = api.model_info(repo, revision=revision, files_metadata=True)
    files = {}
    for s in info.siblings or []:
        lfs = getattr(s, "lfs", None)
        lfs_sha = None
        if lfs is not None:
            lfs_sha = lfs.get("sha256") if isinstance(lfs, dict) else getattr(lfs, "sha256", None)
        files[s.rfilename] = {"size": getattr(s, "size", None), "blob_id": getattr(s, "blob_id", None),
                              "lfs_sha256": lfs_sha}
    card = getattr(info, "card_data", None) or getattr(info, "cardData", None) or {}
    lic = card.get("license") if hasattr(card, "get") else getattr(card, "license", None)
    if not lic:
        lic = [t for t in (info.tags or []) if t.startswith("license:")]
    lm = getattr(info, "last_modified", None) or getattr(info, "lastModified", None)
    return {"sha": info.sha, "last_modified": str(lm) if lm is not None else None, "license": lic,
            "gated": getattr(info, "gated", None), "files": files}


def verify_against(listed, path):
    """[] if the local file matches the listing's entry: size, then SHA-256 (LFS) or git blob id."""
    fails = []
    if listed is None:
        return ["not in the listing"]
    size = path.stat().st_size
    if listed.get("size") is not None and int(listed["size"]) != size:
        fails.append(f"size {size}, listing {listed['size']}")
    if listed.get("lfs_sha256"):
        if sha256_file(path) != listed["lfs_sha256"]:
            fails.append("SHA-256 differs from the listing's LFS hash")
    elif listed.get("blob_id"):
        if git_blob_sha1(path) != listed["blob_id"]:
            fails.append("git blob id differs from the listing's")
    else:
        fails.append("the listing gives no hash")
    return fails


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True, choices=MODELS)
    ap.add_argument("--cache", required=True)
    ap.add_argument("--pin", required=True)
    ap.add_argument("--endpoint", default="https://huggingface.co")
    ap.add_argument("--from-folder", default=None)
    ap.add_argument("--revision", default=None, help="with --from-folder: the commit the files came from")
    ap.add_argument("--resume", action="store_true",
                    help="continue a download whose snapshot folder for the listed commit already exists")
    a = ap.parse_args()
    pin_path = Path(a.pin)
    if pin_path.exists():
        print(f"STOP: {pin_path} already exists", file=sys.stderr)
        return 2
    pin = {"version": VERSION, "repo_id": a.repo, "time": time.strftime("%Y-%m-%d %H:%M:%S %z")}
    if a.from_folder:
        if not is_commit(a.revision):
            print("STOP: --from-folder needs --revision, the 40-character commit the files came from", file=sys.stderr)
            return 2
        src = Path(a.from_folder)
        names = sorted(p.name for p in src.iterdir() if p.is_file() and wanted(p.name))
        missing = [n for n in REQUIRED if n not in names]
        if missing or not any(n.endswith(".safetensors") for n in names):
            print(f"STOP: the folder lacks {missing or ['the safetensors weights']}", file=sys.stderr)
            return 2
        dst = snapshot(a.cache, a.repo, a.revision)
        if dst.exists():
            print(f"STOP: {dst} already exists", file=sys.stderr)
            return 2
        dst.mkdir(parents=True)
        for n in names:
            shutil.copy2(src / n, dst / n)
        pin.update(source="folder", folder=str(src.resolve()), revision=a.revision, endpoint=None, listing=None,
                   reference={"status": "not checked (copied from a folder)"})
    else:
        from huggingface_hub import HfApi, hf_hub_download

        base = a.endpoint.rstrip("/")
        api = HfApi(endpoint=base)
        try:
            head = listing(api, a.repo)
        except Exception as e:
            print(f"STOP: {base} not reachable for {a.repo} ({type(e).__name__}: {e})", file=sys.stderr)
            return 4
        rev = head["sha"]
        if not is_commit(rev):
            print(f"STOP: the endpoint gave no commit for {a.repo}: {rev!r}", file=sys.stderr)
            return 2
        try:
            lst = listing(api, a.repo, revision=rev)
        except Exception as e:
            print(f"STOP: the file listing failed ({type(e).__name__}: {e})", file=sys.stderr)
            return 4
        names = sorted(n for n in lst["files"] if wanted(n))
        missing = [n for n in REQUIRED if n not in names]
        if missing or not any(n.endswith(".safetensors") for n in names):
            print(f"STOP: the repository lacks {missing or ['the safetensors weights']}; files: "
                  f"{sorted(lst['files'])}", file=sys.stderr)
            return 2
        dst = snapshot(a.cache, a.repo, rev)
        if dst.exists() and not a.resume:
            print(f"STOP: {dst} already exists (add --resume to continue that download)", file=sys.stderr)
            return 2
        if a.resume and not dst.exists():
            print(f"note: no earlier snapshot for {rev}; downloading from the start", flush=True)
        import requests
        transfer_errors = (requests.exceptions.ChunkedEncodingError, requests.exceptions.ConnectionError,
                           requests.exceptions.Timeout)
        attempts = {}
        for n in names:
            for k in range(1, MAX_ATTEMPTS + 1):
                try:
                    hf_hub_download(repo_id=a.repo, filename=n, revision=rev, cache_dir=a.cache, endpoint=base)
                    attempts[n] = k
                    break
                except transfer_errors as e:
                    print(f"transfer of {n} broke (attempt {k} of {MAX_ATTEMPTS}): {type(e).__name__}: "
                          f"{str(e)[:200]}", flush=True)
                    if k == MAX_ATTEMPTS:
                        print(f"STOP: the transfer of {n} broke {MAX_ATTEMPTS} times; nothing pinned", file=sys.stderr)
                        return 6
                    time.sleep(RETRY_SECONDS)
        bad = {n: f for n in names if (f := verify_against(lst["files"].get(n), dst / n))}
        if bad:
            print(f"STOP: downloaded files differ from the listing: {bad}", file=sys.stderr)
            return 2
        pin.update(source="endpoint", endpoint=base, revision=rev, last_modified=lst["last_modified"],
                   license=lst["license"], listing={n: lst["files"][n] for n in names},
                   all_files=sorted(lst["files"]), resumed=bool(a.resume), attempts=attempts)
        ref_repo = REFERENCE.get(a.repo)
        if ref_repo:
            try:
                ref = listing(api, ref_repo)
            except Exception as e:
                ref = None
                pin["reference"] = {"repo_id": ref_repo, "status": "unavailable",
                                    "error": f"{type(e).__name__}: {e}"[:500]}
            if ref is not None:
                cmp = {n: verify_against(ref["files"].get(n), dst / n) for n in names}
                differ = {n: f for n, f in cmp.items() if f}
                pin["reference"] = {"repo_id": ref_repo, "revision": ref["sha"], "gated": ref["gated"],
                                    "last_modified": ref["last_modified"], "license": ref["license"],
                                    "status": "identical" if not differ else "differs",
                                    "files": {n: ("identical" if not f else f) for n, f in cmp.items()},
                                    "listing": {n: ref["files"].get(n) for n in names}}
                if differ:
                    print(json.dumps({"reference": pin["reference"]}, indent=1, default=str))
                    print(f"STOP: {a.repo} differs from {ref_repo} in {sorted(differ)}; nothing pinned",
                          file=sys.stderr)
                    return 5
    files = {}
    for p in sorted(snapshot(a.cache, a.repo, pin["revision"]).iterdir()):
        files[p.name] = {"size": p.stat().st_size, "sha256": sha256_file(p), "git_blob_sha1": git_blob_sha1(p)}
    for n, want in KNOWN_SHA256.get(a.repo, {}).items():
        if (files.get(n) or {}).get("sha256") != want:
            print(f"STOP: {n} has SHA-256 {(files.get(n) or {}).get('sha256')}, expected {want}", file=sys.stderr)
            return 2
    pin["files"] = files
    pin_path.write_text(json.dumps(pin, indent=1, default=str))
    print(json.dumps({"repo_id": a.repo, "revision": pin["revision"],
                      "reference": (pin.get("reference") or {}).get("status"),
                      "files": {k: {"size": v["size"], "sha256": v["sha256"]} for k, v in files.items()}}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

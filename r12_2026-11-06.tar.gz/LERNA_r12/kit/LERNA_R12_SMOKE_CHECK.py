#!/usr/bin/env python3
"""LERNA round 12: checks of the GPU smoke test (6 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, runs/, logs/) and writes only
check_report.json and CHECK_SUMMARY.txt into that folder. Exit 0 means the report was
written; the verdict is inside it. Exit 2 means the folder isn't a finished launcher folder.

Per run, it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, revisions, device;
  - the exact counts: forwards (plus skips decided before any forward pass), backwards,
    skips, scheduler steps and updates; the warmup steps, and that the final LR is 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases,
    attention, AdamW betas and eps, the pinned GPU;
  - the batch log (9 fields per row): row count, hash, skip count, forward-free skips,
    dropped examples and the sanity of its tokens;
  - the stored-score counters of M1 (stale_s1_p4) and InfoBatch.
Across runs, it checks:
  - that the equal-compute run reproduces the Step 5 main study's seed-11 run bit for bit
    (--reference: accuracy, loss and the first six fields of every batch-log row);
  - that M1 skipped batches without a forward pass, and that InfoBatch dropped examples,
    in every run longer than one epoch.
It reports, without judging them: accuracies, measured compute (within each arm, and against
full fine-tuning of the same task and seed where one exists) and timings.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R12_SMOKE_CHECK 2026-11-06"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
RATE = 0.60
PLAIN_FRACTIONS = {"plain_030": 0.30, "plain_050": 0.50, "plain_070": 0.70}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349, "mrpc": 3668}
BATCH_SIZE = 32


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm == "full_finetune" or arm == "infobatch":
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm in PLAIN_FRACTIONS:
        eff, skips = int(round(PLAIN_FRACTIONS[arm] * T)), 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    """Compute units from batch-log rows of either format (6 or 9 fields)."""
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def check_run(p, end, out):
    name, task, arm = p["name"], p["task"], p["arm"]
    gpu = end.get("gpu") if end else None
    fails, notes, facts = [], [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    need(end is not None, "no end record in the ledger")
    if end is None:
        return {"name": name, "ok": False, "fails": fails}
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return {"name": name, "ok": False, "fails": fails}
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, p["total_steps"])
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", 11), ("total_steps", p["total_steps"]),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"] if task == "qnli" else None)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        need(c.get("infobatch_prune_ratio") == 0.5 and c.get("infobatch_anneal_fraction") == 0.875,
             "InfoBatch options are not 0.5 and 0.875")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == exp["effective_total"] - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == exp["effective_total"], f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    if arm != "stale_s1_p4":
        need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm != "infobatch":
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss, f1 = r.get("final_eval_accuracy"), r.get("final_eval_loss"), r.get("final_eval_f1")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    if task == "mrpc":
        need(isinstance(f1, (int, float)) and 0.0 <= f1 <= 1.0, f"final_eval_f1={f1}")
    # runtime block
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    # batch log
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    eff = exp["effective_total"]
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if ok_shape and rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            free = [x for x in rows if int(x[6]) == 0]
            need(len(free) == fskip, f"batch log has {len(free)} forward-free skips, result {fskip}")
            need(all(int(x[4]) == 1 and x[5] == "nan" for x in free), "a forward-free row isn't a skip with a NaN loss")
            need(all(math.isfinite(float(x[5])) for x in rows if int(x[6]) == 1), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) for x in rows), "real tokens must be positive and at most the padded tokens")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm != "infobatch":
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
            facts["compute_units_padded"] = units_of(rows)
            facts["compute_fraction_within_arm"] = s.get("compute_fraction_within_arm")
    # stored-score counters
    sel = r.get("selection")
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    multi_epoch = bool(bpe) and eff > bpe
    if arm == "stale_s1_p4":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need((sel.get("stale_decisions") or 0) + (sel.get("fresh_decisions") or 0) == eff,
                 "stale + fresh decisions don't add up to the scheduled batches")
            need(sel.get("forward_skips") == fskip, "policy forward_skips differ from the result")
            if multi_epoch:
                need(fskip > 0, "no skip without a forward pass in a run longer than one epoch")
                need((sel.get("fresh_decisions") or 0) >= bpe, "fewer fresh decisions than one epoch of batches")
            facts.update(stale_decisions=sel.get("stale_decisions"), fresh_decisions=sel.get("fresh_decisions"))
    elif arm == "infobatch":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
            need(sel.get("stop_prune_step") == int(math.floor(0.875 * eff + 1e-9)), "stop_prune_step differs")
            need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
            need(len(sel.get("thresholds") or []) == math.ceil(eff / bpe), "one threshold per epoch expected")
            need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
            if multi_epoch:
                need(dropped > 0, "no example dropped in a run longer than one epoch")
            facts.update(pruned_examples=sel.get("pruned_examples"), thresholds=sel.get("thresholds"))
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    facts.update(accuracy=acc, loss=loss, f1=f1, wall_seconds=r.get("wall_seconds"), forward_skipped=fskip,
                 examples_dropped=dropped, run_seconds=end.get("seconds"),
                 seconds_per_step=(r.get("wall_seconds") / eff) if r.get("wall_seconds") else None)
    return {"name": name, "gpu": gpu, "task": task, "arm": arm, "total_steps": p["total_steps"],
            "ok": not fails, "fails": fails, "notes": notes, "facts": facts,
            "manifest": str(mpath.relative_to(out)), "log_rows": rows}


def reference_run(ref, name):
    found = sorted((ref / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return None
    m = json.loads(found[0].read_text())
    log = found[0].parent / "batch_log.csv"
    rows = read_log(log)[1] if log.is_file() else None
    return {"manifest": m, "rows": rows}


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True)
    ap.add_argument("--reference", default=None, help="the Step 5 main study's folder (.../LERNA_step5_main/main)")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    plan = json.loads((out / "plan.json").read_text())
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    runs = [check_run(p, ends.get(p["name"]), out) for p in plan["plan"]]
    by = {x["name"]: x for x in runs}
    cross = {"fails": []}
    # compute against full fine-tuning of the same task and seed
    full_units = {}
    if "sst2_full_full_finetune" in by and by["sst2_full_full_finetune"].get("log_rows"):
        full_units["sst-2"] = units_of(by["sst2_full_full_finetune"]["log_rows"])
    ref = Path(a.reference).resolve() if a.reference else None
    repro = None
    if ref is not None:
        rf = reference_run(ref, "full_finetune_seed11")
        if rf and rf["rows"]:
            full_units["qnli"] = units_of(rf["rows"])
        else:
            cross["fails"].append("reference full_finetune_seed11 not found")
        re_ = reference_run(ref, "equal_compute_seed11")
        mine = by.get("qnli_full_equal_compute")
        if re_ is None or mine is None or not mine.get("log_rows"):
            cross["fails"].append("equal-compute reproduction not comparable")
            repro = {"comparable": False}
        else:
            rr = re_["manifest"].get("result", {})
            mf = mine["facts"]
            same_acc = rr.get("final_eval_accuracy") == mf.get("accuracy")
            same_loss = rr.get("final_eval_loss") == mf.get("loss")
            old_rows = re_["rows"] or []
            same_log = len(old_rows) == len(mine["log_rows"]) and all(
                o[:6] == n[:6] for o, n in zip(old_rows, mine["log_rows"]))
            repro = {"comparable": True, "same_accuracy": same_acc, "same_loss": same_loss,
                     "same_batch_log_first_six_fields": same_log,
                     "accuracy": [rr.get("final_eval_accuracy"), mf.get("accuracy")]}
            if not (same_acc and same_loss and same_log):
                cross["fails"].append("the equal-compute run does not reproduce Step 5 bit for bit")
    for x in runs:
        f = x.get("facts", {})
        if x.get("task") in full_units and x.get("total_steps") in (6548, 4210) and f.get("compute_units_padded"):
            f["compute_fraction_vs_full"] = f["compute_units_padded"] / full_units[x["task"]]
    all_ok = all(x["ok"] for x in runs) and not cross["fails"] and (ref is None or repro is not None)
    verdict = "PASS" if all_ok else "FAIL"
    report = {"version": VERSION, "verdict": verdict, "runs_ok": sum(1 for x in runs if x["ok"]),
              "runs_planned": len(runs), "cross_checks": cross, "reproduction": repro,
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    lines = [f"SMOKE CHECK ({VERSION}): {verdict}, {report['runs_ok']} of {len(runs)} runs pass every check"]
    lines.append("  run                          steps  acc     fwd-free  dropped  compute(arm)  compute(vs full)  s/step")
    for x in runs:
        f = x.get("facts", {})
        lines.append(f"  {x['name']:<28} {x.get('total_steps', '-'):>5}  {num(f.get('accuracy'), '.4f'):>6}  "
                     f"{num(f.get('forward_skipped'), 'd'):>8}  {num(f.get('examples_dropped'), 'd'):>7}  "
                     f"{num(f.get('compute_fraction_within_arm'), '.4f'):>12}  {num(f.get('compute_fraction_vs_full'), '.4f'):>16}  "
                     f"{num(f.get('seconds_per_step'), '.3f'):>6}")
        for msg in x.get("fails", []):
            lines.append(f"      FAIL: {msg}")
        for msg in x.get("notes", []):
            lines.append(f"      note: {msg}")
    if repro is not None:
        lines.append(f"  Step 5 reproduction (equal_compute, seed 11): {json.dumps(repro)}")
    for msg in cross["fails"]:
        lines.append(f"  FAIL: {msg}")
    lines.append("  Accuracies and compute are descriptive only; the development round (round 13) tests them.")
    text = "\n".join(lines)
    (out / "CHECK_SUMMARY.txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

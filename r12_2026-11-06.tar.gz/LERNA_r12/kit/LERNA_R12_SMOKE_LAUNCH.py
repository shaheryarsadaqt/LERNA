#!/usr/bin/env python3
"""LERNA round 12: GPU smoke test of the round-12 arms (6 November 2026).

It runs a fixed plan of runner calls in qwen-v100, with one GPU per run. Each GPU works
through its own queue, and the GPUs run in parallel. There are no retries and no seed
changes. All runs use seed 11 and the Step 5 recipe (linear decay, warmup 6% of each arm's
length, eager attention, FP32).

The plan:
  - MRPC at 3 epochs (T=345): M1 (stale_s1_p4), InfoBatch and the S1 gate, so that the
    stored-score mechanics (decisions before the forward pass, dropped examples) run on a GPU
    within minutes;
  - QNLI at T=512: the three plain-fraction arms;
  - QNLI at the full horizon (T=6548): M1, InfoBatch, and the equal-compute arm again, which
    must reproduce the Step 5 main study's run bit for bit (the patch leaves old arms alone);
  - SST-2 at the full horizon (T=4210): full fine-tuning, M1 and InfoBatch.

It writes only into --out, which must not exist:
  ds_cache/   one private copy of the prepared GLUE cache of its task per run, each checked
              byte for byte, so that parallel runs never write map caches into the same folder
  runs/       one output folder per run
  logs/       one log per run
  ledger.jsonl and DONE.json

Usage:
  python -s -B LERNA_R12_SMOKE_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R12_SMOKE_LAUNCH 2026-11-06"
# The round-12 commit sits directly on the Step 5 commit; the files are checked by content.
EXPECT = {
    "parent": "45dc79183ede882a7fa0f1ed1a8c200e33c00a69",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
FILES = {
    "scripts/run_controller_ablation.py": "45eff33375018482c11ff2c99ac1ad0899eabe3a0ae757869f1602eb49b9fb37",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
MODEL_REV = "45d08642849e5c5701b162671ac811b7654bfd9f"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"qnli": "qnli", "sst-2": "sst2", "mrpc": "mrpc"}
MRPC3 = {"total_steps": 345, "min_step": 20}
QNLI_SHORT = {"total_steps": 512, "min_step": 30}
QNLI_FULL = {"total_steps": 6548, "min_step": 392}
SST2_FULL = {"total_steps": 4210, "min_step": 252}
# name, gpu, task, arm, score source, controller, phases, horizon
PLAN = [
    ("mrpc_stale_s1_p4", 0, "mrpc", "stale_s1_p4", "s1_stale", "phase_exact_v1", 4, MRPC3),
    ("mrpc_infobatch", 0, "mrpc", "infobatch", "uniform", "legacy_v4", 1, MRPC3),
    ("mrpc_gate_s1_p4", 0, "mrpc", "gate_s1_p4", "s1", "phase_exact_v1", 4, MRPC3),
    ("qnli_short_plain_030", 1, "qnli", "plain_030", "uniform", "legacy_v4", 1, QNLI_SHORT),
    ("qnli_short_plain_050", 1, "qnli", "plain_050", "uniform", "legacy_v4", 1, QNLI_SHORT),
    ("qnli_short_plain_070", 1, "qnli", "plain_070", "uniform", "legacy_v4", 1, QNLI_SHORT),
    ("qnli_full_stale_s1_p4", 2, "qnli", "stale_s1_p4", "s1_stale", "phase_exact_v1", 4, QNLI_FULL),
    ("qnli_full_infobatch", 3, "qnli", "infobatch", "uniform", "legacy_v4", 1, QNLI_FULL),
    ("qnli_full_equal_compute", 4, "qnli", "equal_compute", "uniform", "legacy_v4", 1, QNLI_FULL),
    ("sst2_full_full_finetune", 5, "sst-2", "full_finetune", "uniform", "legacy_v4", 1, SST2_FULL),
    ("sst2_full_stale_s1_p4", 6, "sst-2", "stale_s1_p4", "s1_stale", "phase_exact_v1", 4, SST2_FULL),
    ("sst2_full_infobatch", 7, "sst-2", "infobatch", "uniform", "legacy_v4", 1, SST2_FULL),
]
SEED = 11
RUN_TIMEOUT = 3 * 3600
MIN_FREE_GB = 10


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def command(a, name, task, arm, source, controller, phases, horizon):
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(SEED), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--device", "cuda",
           "--model-revision", MODEL_REV, "--tokenizer-revision", MODEL_REV, "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    if task == "qnli":
        cmd += ["--probe-exclusions-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
                "--probe-exclusions-hash", EXPECT["probe_file_sha256"]]
    return cmd


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--plan-names", nargs="*", default=None, help="run only these plan entries (tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    parent = git(repo, "rev-parse", "HEAD^")
    if parent != EXPECT["parent"] or head == EXPECT["parent"]:
        problems.append(f"HEAD {head} is not one commit on top of {EXPECT['parent']} (HEAD^ is {parent})")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the round-12 version")
    probe = repo / "experiments" / "probe_indices_v4.json"
    if not probe.is_file() or sha256_file(probe) != EXPECT["probe_file_sha256"]:
        problems.append("the probe file is missing or differs")
    plan = [p for p in PLAN if a.plan_names is None or p[0] in a.plan_names]
    gpus = sorted({p[1] for p in plan})
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    for task in sorted({p[2] for p in plan}):
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    try:
        free_gb = shutil.disk_usage(out.parent if out.parent.exists() else Path("/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free next to --out; need {a.min_free_gb}")
    except Exception as e:
        problems.append(f"free-space check failed: {type(e).__name__}: {e}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    out.mkdir(parents=True)
    (out / "runs").mkdir()
    (out / "logs").mkdir()
    source_sha = {}
    for task in sorted({p[2] for p in plan}):
        src = cache_dir(a.source_cache, task)
        source_sha[task] = {f: sha256_file(src / f) for f in CACHE_FILES}
    copies = {"source_sha256": source_sha, "runs": {}}
    for p in plan:
        name, task = p[0], p[2]
        src = cache_dir(a.source_cache, task)
        dst = cache_dir(out / "ds_cache" / name, task)
        dst.mkdir(parents=True)
        for f in CACHE_FILES:
            shutil.copy2(src / f, dst / f)
        same = all(sha256_file(dst / f) == source_sha[task][f] for f in CACHE_FILES)
        copies["runs"][name] = same
        if not same:
            print(f"STOP: the private cache copy for {name} differs from its source", file=sys.stderr)
            return 2
    meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "repo_parent": parent,
            "files": FILES, "python": a.python, "seed": SEED, "cache_copy": copies,
            "plan": [{"name": p[0], "gpu": p[1], "task": p[2], "arm": p[3], "score_source": p[4],
                      "controller": p[5], "n_phases": p[6], **p[7]} for p in plan]}
    (out / "plan.json").write_text(json.dumps(meta, indent=1))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false"})
    lock = threading.Lock()
    ledger = out / "ledger.jsonl"

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def worker(gpu):
        for p in [p for p in plan if p[1] == gpu]:
            name = p[0]
            cmd = command(a, name, *p[2:])
            env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu), HF_DATASETS_CACHE=str(out / "ds_cache" / name))
            t0 = time.time()
            record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
            with open(out / "logs" / f"{name}.log", "wb") as log:
                try:
                    rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                        timeout=RUN_TIMEOUT).returncode
                except subprocess.TimeoutExpired:
                    rc = "timeout"
            manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
            record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                    "seconds": round(time.time() - t0, 1), "manifests": manifests})

    threads = [threading.Thread(target=worker, args=(g,)) for g in gpus]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    ends = [json.loads(l) for l in ledger.read_text().splitlines() if '"event": "end"' in l]
    done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends if e["exit"] == 0),
            "failed": [e["name"] for e in ends if e["exit"] != 0]}
    (out / "DONE.json").write_text(json.dumps(done, indent=1))
    print(json.dumps(done, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA round 16: the final comparison's launcher (7 November 2026).

It runs the round fixed in claude/LERNA_R16_FINAL_PLAN_2026-11-07.md, in qwen-v100, one GPU per
run, with the Step 5 recipe (linear decay, warmup 6% of T, eager attention, FP32), seeds 11, 13,
17, 19, 23, 29, 31, 37, 41 and 43:
  - MRPC (T = 1150, 10 epochs) and RTE (T = 780, 10 epochs), untouched by LERNA v2's design: every
    method of the final comparison, 38 arms x 10 seeds x 2 tasks = 760 runs;
  - QNLI (T = 6548) and SST-2 (T = 4210), the development tasks, where rounds 13-15 ran every other
    arm: the round-16 compared methods (eps-greedy, UCB, OrderDP, fresh-score importance sampling at
    60 and 83%, Selective Backprop at 60 and 83%, KAKURENBO, DropBP at p 0.5 and 0.875; IES needs
    three earlier epochs, so it runs on the 10-epoch tasks only), 10 arms x 10 seeds x 2 tasks = 200
    runs; with --final-variant nolr also LERNA v2 without the learning-rate factor at 40, 60 and 83%
    (60 runs);
  - three reproductions of round 15 on SST-2 (el2n_topk_b035 and randkeep_b060 at seed 11,
    lerna2_b083 at seed 29), which must match round 15 bit for bit.
963 runs with --final-variant lr, 1023 with nolr. --final-variant is the setting round 15's
ten-seed rule chose (the plan, section 1); it changes only which runs are made.

The smoke gate. Fourteen MRPC runs at seed 11 go first: the eleven compared methods, LERNA v2
without the learning-rate factor at 60%, full fine-tuning and LERNA v1 (the batch gate on the new
horizon). When all have ended the launcher checks each one (status OK, the exact counts, a final LR
of 0, and the method's own accounting: budget, warmup, scoring passes, hidden or mastered examples,
dropped blocks). Only if all pass does it start the other runs, longest first, on every GPU. If the
gate fails it stops and writes SMOKE_GATE.json and DONE.json. There are no retries and no seed
changes.

Each GPU has one private copy of each task's prepared cache, used by its runs one after another.

With --resume on an existing --out it continues an interrupted launch. It skips the runs that
started, never reruns a failed run, and holds back any run that started but has no end record,
listing it for a decision. A smoke gate that already passed is not run again. It refuses to resume
while the earlier launcher's process (launcher.pid) is still alive, or with another --final-variant.

It writes only into --out, which must not exist:
  ds_cache/   per GPU, one private copy of each task's prepared cache, checked byte for byte
  runs/       one output folder per run
  logs/       one log per run
  plan.json, ledger.jsonl, SMOKE_GATE.json and DONE.json

Usage:
  python -s -B LERNA_R16_FINAL_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder> \\
      --final-variant {lr,nolr} [--min-free-gb 15]
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R16_FINAL_LAUNCH 2026-11-07"
EXPECT = {
    "grandparent": "c3a62960d72aa27ad67a938a9dbb1a3c41531848",
    "parent_subject": "Round 15 runner: hard top-k selection (dynamic EL2N pruning) and random keep at 60% and 83%",
    "subject": "Round 16 runner: the compared methods of the final comparison",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
    "dropbp_layers": "22",
}
FILES = {
    "scripts/run_controller_ablation.py": "779bba65e46be4bf9f3053c1488ee358ef0162e44bcc9ce1ef569e663c79080b",
    "lerna/utils/budget_selection.py": "df970102a7684df4d7f054b51867b5a08077efdfa2b8e69919a0894f16b62bea",
    "lerna/utils/compared_methods.py": "08588c07cadbc504b09176683d62daecbaf85589930264a95f24a15507735297",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
MODEL_REV = "45d08642849e5c5701b162671ac811b7654bfd9f"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"qnli": "qnli", "sst-2": "sst2", "mrpc": "mrpc", "rte": "rte"}
SHORT = {"qnli": "qnli", "sst-2": "sst2", "mrpc": "mrpc", "rte": "rte"}
# T and the warmup W = floor(0.06 T): QNLI and SST-2 as in rounds 13-15 (2 epochs); MRPC 115 and
# RTE 78 batches per epoch, 10 epochs
HORIZON = {"qnli": {"total_steps": 6548, "min_step": 392}, "sst-2": {"total_steps": 4210, "min_step": 252},
           "mrpc": {"total_steps": 1150, "min_step": 69}, "rte": {"total_steps": 780, "min_step": 46}}
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349, "mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
SEEDS = (11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
# controller-budgeted arms: arm -> budget
BUDGET = {"lerna2_b035": 0.35, "lerna2_nolr_b035": 0.35, "randkeep_lr_b035": 0.35, "randkeep_b035": 0.35,
          "lerna2_b040": 0.40, "randkeep_b040": 0.40, "lerna2_b060": 0.60, "lerna2_b083": 0.83,
          "randkeep_b060": 0.60, "randkeep_b083": 0.83, "el2n_topk_b035": 0.35, "el2n_topk_b060": 0.60,
          "lerna2_nolr_b040": 0.40, "lerna2_nolr_b060": 0.60, "lerna2_nolr_b083": 0.83}
TOPK = ("el2n_topk_b035", "el2n_topk_b060")
RANKED = {"egreedy_b035": (0.35, "egreedy"), "ucb_b035": (0.35, "ucb"), "orderdp_b035": (0.35, "orderdp")}
FRESH_IS = {"isfresh_b060": 0.60, "isfresh_b083": 0.83}
SB = {"sb_b060": 0.60, "sb_b083": 0.83}
DROPBP = {"dropbp_p050": 0.5, "dropbp_p0875": 0.875}
GATE_TOLERANCE = 0.005
GATES = ("gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4")
# arm: score source, controller, phases
ARM_SPEC = {a: ("uniform", "legacy_v4", 1) for a in
            list(BUDGET) + list(RANKED) + list(FRESH_IS) + list(SB) + list(DROPBP)
            + ["kakurenbo", "ies", "full_finetune", "reduced_steps", "equal_compute", "plain_030", "plain_050",
               "plain_070", "infobatch"]}
ARM_SPEC.update({"gate_s1_p4": ("s1", "phase_exact_v1", 4), "control_uniform_p4": ("uniform", "phase_exact_v1", 4),
                 "gate_loss_p4": ("loss", "phase_exact_v1", 4), "stale_s1_p4": ("s1_stale", "phase_exact_v1", 4)})
# launcher names that run a runner arm with extra options
VARIANTS = {"infobatch_max": ("infobatch", ["--infobatch-prune-ratio", "0.9", "--infobatch-anneal-fraction", "1.0"])}
EXISTING = ("full_finetune", "plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070",
            "gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4", "infobatch", "infobatch_max",
            "el2n_topk_b035", "el2n_topk_b060", "randkeep_b035", "randkeep_b040", "randkeep_b060", "randkeep_b083",
            "randkeep_lr_b035", "lerna2_b035", "lerna2_b040", "lerna2_b060", "lerna2_b083", "lerna2_nolr_b035")
NOLR_EXTRA = ("lerna2_nolr_b040", "lerna2_nolr_b060", "lerna2_nolr_b083")
COMPARED = ("egreedy_b035", "ucb_b035", "orderdp_b035", "isfresh_b060", "isfresh_b083", "sb_b060", "sb_b083",
            "kakurenbo", "ies", "dropbp_p050", "dropbp_p0875")
SMALL_TASK_LABELS = EXISTING + NOLR_EXTRA + COMPARED
SMOKE_LABELS = COMPARED + ("lerna2_nolr_b060", "full_finetune", "gate_s1_p4")
SMOKE = tuple(f"mrpc_{lab}_seed11" for lab in SMOKE_LABELS)
REPRO = {"repro_sst2_el2n_topk_b035_seed11": ("sst-2", 11, "el2n_topk_b035", "sst2_el2n_topk_b035_seed11"),
         "repro_sst2_randkeep_b060_seed11": ("sst-2", 11, "randkeep_b060", "sst2_randkeep_b060_seed11"),
         "repro_sst2_lerna2_b083_seed29": ("sst-2", 29, "lerna2_b083", "sst2_lerna2_b083_seed29")}
# rough cost of a run relative to full fine-tuning, only to order the queue longest first
STEP_SECONDS = {"qnli": 0.26, "sst-2": 0.125, "mrpc": 0.25, "rte": 0.5}


def dev_labels(final):
    return tuple(x for x in COMPARED if x != "ies") + (NOLR_EXTRA if final == "nolr" else ())


def relative_cost(label):
    if label == "full_finetune":
        return 1.0
    fixed = {"plain_030": 0.30, "reduced_steps": 0.40, "plain_050": 0.50, "equal_compute": 0.60, "plain_070": 0.70,
             "gate_s1_p4": 0.62, "control_uniform_p4": 0.62, "gate_loss_p4": 0.62, "stale_s1_p4": 0.52,
             "infobatch": 0.88, "infobatch_max": 0.70, "kakurenbo": 0.95, "ies": 0.90}
    if label in fixed:
        return fixed[label]
    if label in DROPBP:
        return (1.0 + 2.0 * (1.0 - DROPBP[label])) / 3.0 + 0.1
    if label in FRESH_IS or label in SB:
        return (FRESH_IS.get(label) or SB.get(label)) + 0.25
    b = BUDGET.get(label) or RANKED[label][0]
    return b + 0.18


def _entry(name, task, seed, arm_or_variant):
    arm, extra = VARIANTS.get(arm_or_variant, (arm_or_variant, []))
    return (name, task, seed, arm) + ARM_SPEC[arm] + (HORIZON[task], list(extra), arm_or_variant)


def build_plan(final):
    entries = []
    for task in ("mrpc", "rte"):
        for lab in SMALL_TASK_LABELS:
            for s in SEEDS:
                entries.append(_entry(f"{SHORT[task]}_{lab}_seed{s}", task, s, lab))
    for task in ("qnli", "sst-2"):
        for lab in dev_labels(final):
            for s in SEEDS:
                entries.append(_entry(f"{SHORT[task]}_{lab}_seed{s}", task, s, lab))
    reps = [_entry(n, t, s, a) for n, (t, s, a, _) in REPRO.items()]

    def cost(p):
        return HORIZON[p[1]]["total_steps"] * STEP_SECONDS[p[1]] * relative_cost(p[9])

    smoke = [next(p for p in entries if p[0] == n) for n in SMOKE]
    rest = sorted([p for p in entries if p[0] not in SMOKE] + reps, key=lambda p: (-cost(p), p[0]))
    return smoke + rest


MIN_FREE_GB = 15
RUN_TIMEOUT = 3 * 3600


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def command(a, name, task, seed, arm, source, controller, phases, horizon, extra, label):
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--device", "cuda",
           "--model-revision", MODEL_REV, "--tokenizer-revision", MODEL_REV, "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    if task == "qnli":
        cmd += ["--probe-exclusions-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
                "--probe-exclusions-hash", EXPECT["probe_file_sha256"]]
    return cmd + list(extra)


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def gate_check(out, entry, end):
    """The smoke gate's checks of one smoke run. Returns a list of failures (empty = pass)."""
    name, task, seed, arm, label = entry[0], entry[1], entry[2], entry[3], entry[9]
    T = HORIZON[task]["total_steps"]
    W = int(math.floor(0.06 * T + 1e-9))
    bpe = math.ceil(TRAIN_ROWS[task] / BATCH_SIZE)
    fails = []
    if end is None:
        return ["no end record (interrupted)"]
    if end.get("exit") != 0:
        fails.append(f"exit code {end.get('exit')}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return fails + [f"{len(found)} execution manifests found"]
    m = json.loads(found[0].read_text())
    if m.get("status") != "OK":
        return fails + [f"status {m.get('status')}: {str(m.get('reason'))[:300]}"]
    r = m.get("result", {})
    sel = r.get("selection") or {}
    q = int(round(0.60 * T)) if arm in GATES else 0
    for k, v in (("skipped", q), ("backwards", T - q), ("forwards", T), ("forward_skipped", 0),
                 ("scheduler_advances", T), ("optimizer_updates", T - q)):
        if r.get(k) != v:
            fails.append(f"{k}={r.get(k)}, expected {v}")
    acc = r.get("final_eval_accuracy")
    if not isinstance(acc, (int, float)) or not 0.0 <= acc <= 1.0:
        fails.append(f"final_eval_accuracy={acc}")
    flr = r.get("final_learning_rate")
    if not isinstance(flr, (int, float)) or abs(flr) > 1e-12:
        fails.append(f"final_learning_rate={flr}")
    if arm in ("full_finetune",) + GATES:
        return fails
    dropped = r.get("examples_dropped_before_forward")
    if not isinstance(dropped, int) or dropped != sel.get("pruned_examples"):
        fails.append(f"examples_dropped={dropped}, policy pruned={sel.get('pruned_examples')}")
    if sel.get("steps_seen") != T:
        fails.append(f"steps_seen={sel.get('steps_seen')}, expected {T}")
    ca = r.get("compute_accounting") or {}
    frac = ca.get("compute_fraction_within_arm")
    if arm in BUDGET or arm in RANKED or arm in FRESH_IS:
        budget = BUDGET.get(arm) or (RANKED.get(arm) or (None,))[0] or FRESH_IS.get(arm)
        want_policy = ("ranked_subset" if arm in RANKED else "fresh_importance_sampling" if arm in FRESH_IS
                       else "lerna_budget")
        if sel.get("policy") != want_policy:
            fails.append(f"selection policy {sel.get('policy')!r}, expected {want_policy!r}")
        want_mode = (RANKED[arm][1] if arm in RANKED else "topk" if arm in TOPK else "sample")
        if sel.get("selection") != want_mode:
            fails.append(f"selection mode {sel.get('selection')!r}, expected {want_mode!r}")
        if sel.get("budget") != budget:
            fails.append(f"budget {sel.get('budget')}, expected {budget}")
        rf = sel.get("realized_fraction")
        if not isinstance(rf, (int, float)) or abs(rf - budget) > GATE_TOLERANCE:
            fails.append(f"spent {rf} of the scheduled compute, budget {budget} +/- {GATE_TOLERANCE}")
        if sel.get("pruned_during_warmup") != 0:
            fails.append(f"pruned_during_warmup={sel.get('pruned_during_warmup')}")
        if sel.get("warmup_steps") != W:
            fails.append(f"warmup_steps={sel.get('warmup_steps')}, expected {W}")
        if not isinstance(dropped, int) or dropped <= 0:
            fails.append("no example dropped")
        if arm in FRESH_IS and sel.get("scoring_passes") != T - W:
            fails.append(f"scoring_passes={sel.get('scoring_passes')}, expected {T - W}")
        if arm in (tuple(RANKED) + tuple(FRESH_IS)) and (not isinstance(frac, (int, float)) or abs(frac - rf) > 1e-9):
            fails.append(f"compute accounting {frac} differs from the policy's {rf}")
    elif arm in SB:
        want_beta = 1.0 / (SB[arm] - 1.0 / 3.0) - 1.0
        if sel.get("policy") != "selective_backprop" or not isinstance(sel.get("beta"), (int, float)) \
                or abs(sel["beta"] - want_beta) > 1e-12:
            fails.append(f"Selective Backprop policy {sel.get('policy')!r}, beta {sel.get('beta')}")
        if sel.get("scoring_passes") != T:
            fails.append(f"scoring_passes={sel.get('scoring_passes')}, expected {T}")
        if not isinstance(frac, (int, float)) or not 1.0 / 3.0 < frac < 1.0:
            fails.append(f"measured compute {frac}")
    elif arm == "kakurenbo":
        ep = sel.get("epochs") or []
        if sel.get("policy") != "kakurenbo_fixed_steps" or len(ep) != math.ceil(T / bpe):
            fails.append(f"KAKURENBO policy {sel.get('policy')!r} with {len(ep)} epochs, expected {math.ceil(T / bpe)}")
        elif ep[0].get("hidden") != 0 or not any((e.get("hidden") or 0) > 0 for e in ep[1:]):
            fails.append("KAKURENBO hid nothing after the first epoch, or something in it")
        if not isinstance(dropped, int) or dropped <= 0:
            fails.append("no example hidden")
    elif arm == "ies":
        if sel.get("policy") != "ies_fixed_steps" or sel.get("batches_per_epoch") != bpe:
            fails.append(f"IES policy {sel.get('policy')!r}, batches per epoch {sel.get('batches_per_epoch')}")
        early = [v.get("mastered") for k, v in (sel.get("epochs") or {}).items() if int(k) < 3]
        if any(x != 0 for x in early):
            fails.append("IES excluded examples before the fourth epoch")
    elif arm in DROPBP:
        dc = sel.get("drop_counts") or []
        frac_blocks = sel.get("dropped_block_fraction")
        if sel.get("policy") != "dropbp_uniform" or len(dc) != T:
            fails.append(f"DropBP policy {sel.get('policy')!r} with {len(dc)} steps recorded")
        if not isinstance(frac_blocks, (int, float)) or abs(frac_blocks - DROPBP[arm]) > 0.05:
            fails.append(f"dropped block fraction {frac_blocks}, drop rate {DROPBP[arm]}")
        if dropped != 0:
            fails.append(f"DropBP dropped {dropped} examples")
        fpt = sel.get("flops_per_token") or {}
        if str(fpt.get("layers")) != EXPECT["dropbp_layers"]:
            fails.append(f"DropBP found {fpt.get('layers')} encoder layers, expected {EXPECT['dropbp_layers']}")
    else:
        fails.append(f"no smoke check for {arm}")
    return fails


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--final-variant", required=True, choices=("lr", "nolr"))
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--resume", action="store_true", help="continue an interrupted launch in --out")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    PLAN = build_plan(a.final_variant)
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists() and not a.resume:
        print(f"--out {out} already exists; choose a new folder, or add --resume", file=sys.stderr)
        return 2
    if a.resume and not (out / "plan.json").is_file():
        print(f"--resume needs an earlier launch in {out}", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    parent = git(repo, "rev-parse", "HEAD^")
    grandparent = git(repo, "rev-parse", "HEAD^^")
    subject = git(repo, "log", "-1", "--format=%s")
    parent_subject = git(repo, "log", "-1", "--format=%s", "HEAD^")
    if grandparent != EXPECT["grandparent"]:
        problems.append(f"HEAD^^ is {grandparent}, expected {EXPECT['grandparent']} (round 14's commit)")
    if parent_subject != EXPECT["parent_subject"]:
        problems.append(f"HEAD^'s subject is {parent_subject!r}, expected the round-15 commit")
    if subject != EXPECT["subject"]:
        problems.append(f"HEAD's subject is {subject!r}, expected the round-16 commit")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the committed round-16 version")
    probe = repo / "experiments" / "probe_indices_v4.json"
    if not probe.is_file() or sha256_file(probe) != EXPECT["probe_file_sha256"]:
        problems.append("the probe file is missing or differs")
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out if out.exists() else (out.parent if out.parent.exists() else "/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    tasks = sorted({p[1] for p in PLAN})
    for task in tasks:
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    plan = list(PLAN)
    held_back = []
    ledger = out / "ledger.jsonl"
    pid_file = out / "launcher.pid"
    if a.resume and pid_file.is_file():
        try:
            other = int(pid_file.read_text().strip())
            os.kill(other, 0)
            print(f"STOP: another launcher (pid {other}) is still running on {out}", file=sys.stderr)
            return 2
        except (ValueError, ProcessLookupError):
            pass
        except PermissionError:
            print(f"STOP: a process with the launcher's pid is still running on {out}", file=sys.stderr)
            return 2
    if a.resume:
        meta = json.loads((out / "plan.json").read_text())
        if meta.get("final_variant") != a.final_variant:
            print(f"STOP: the earlier launch used --final-variant {meta.get('final_variant')}", file=sys.stderr)
            return 2
        if [x["name"] for x in meta["plan"]] != [p[0] for p in PLAN]:
            print("STOP: the plan in plan.json differs from this launcher's plan", file=sys.stderr)
            return 2
        gate_prev = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
        if gate_prev is not None and not gate_prev.get("pass"):
            print("STOP: the smoke gate failed in the earlier launch; nothing more is run", file=sys.stderr)
            return 3
        starts, ends = set(), {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e["event"] == "start":
                    starts.add(e["name"])
                elif e["event"] == "end":
                    ends[e["name"]] = e
        held_back = sorted(n for n in starts if n not in ends)
        plan = [p for p in PLAN if p[0] not in starts]
        meta.setdefault("resumes", []).append({"time": now(), "argv": sys.argv, "finished": len(ends),
                                               "held_back_interrupted": held_back, "to_run": len(plan)})
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
        print(json.dumps({"resume": True, "already_finished": len(ends), "interrupted_held_back": held_back,
                          "to_run": len(plan)}, indent=1))
    else:
        out.mkdir(parents=True)
        (out / "runs").mkdir()
        (out / "logs").mkdir()
        source_sha = {t: {f: sha256_file(cache_dir(a.source_cache, t) / f) for f in CACHE_FILES} for t in tasks}
        copies = {"source_sha256": source_sha, "gpus": {}}
        for g in gpus:
            for t in tasks:
                dst = cache_dir(out / "ds_cache" / f"gpu{g}", t)
                dst.mkdir(parents=True)
                for f in CACHE_FILES:
                    shutil.copy2(cache_dir(a.source_cache, t) / f, dst / f)
                same = all(sha256_file(dst / f) == source_sha[t][f] for f in CACHE_FILES)
                copies["gpus"][f"{g}/{t}"] = same
                if not same:
                    print(f"STOP: the private {t} cache copy for GPU {g} differs from its source", file=sys.stderr)
                    return 2
        meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "repo_parent": parent,
                "repo_grandparent": grandparent, "final_variant": a.final_variant,
                "files": FILES, "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
                "smoke": list(SMOKE), "gate_tolerance": GATE_TOLERANCE, "reproductions": REPRO,
                "plan": [{"name": p[0], "task": p[1], "seed": p[2], "arm": p[3], "score_source": p[4],
                          "controller": p[5], "n_phases": p[6], **p[7], "extra": p[8], "label": p[9]}
                         for p in PLAN]}
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
    pid_file.write_text(str(os.getpid()))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false"})
    lock = threading.Lock()

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def run_queue(queue, gpu_list):
        def worker(gpu):
            while True:
                with lock:
                    if not queue:
                        return
                    p = queue.pop(0)
                name = p[0]
                cmd = command(a, *p)
                env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu),
                           HF_DATASETS_CACHE=str(out / "ds_cache" / f"gpu{gpu}"))
                t0 = time.time()
                record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
                with open(out / "logs" / f"{name}.log", "wb") as log:
                    try:
                        rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=RUN_TIMEOUT).returncode
                    except subprocess.TimeoutExpired:
                        rc = "timeout"
                manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
                record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                        "seconds": round(time.time() - t0, 1), "manifests": manifests})

        threads = [threading.Thread(target=worker, args=(g,)) for g in gpu_list]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    def all_ends():
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e.get("event") == "end":
                    ends[e["name"]] = e
        return ends

    def finish(extra):
        ends = all_ends()
        done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends.values() if e["exit"] == 0),
                "failed": sorted(n for n, e in ends.items() if e["exit"] != 0), "held_back_interrupted": held_back}
        done.update(extra)
        (out / "DONE.json").write_text(json.dumps(done, indent=1))
        print(json.dumps(done, indent=1))
        try:
            pid_file.unlink()
        except FileNotFoundError:
            pass

    # --- the smoke gate ---
    gate_file = out / "SMOKE_GATE.json"
    if not gate_file.is_file():
        smoke_queue = [p for p in plan if p[0] in SMOKE]
        if smoke_queue:
            run_queue(smoke_queue, gpus)
        ends = all_ends()
        results = {p[0]: gate_check(out, p, ends.get(p[0])) for p in PLAN if p[0] in SMOKE}
        gate = {"time": now(), "pass": all(not f for f in results.values()), "tolerance": GATE_TOLERANCE,
                "runs": {n: {"pass": not f, "fails": f} for n, f in results.items()}}
        gate_file.write_text(json.dumps(gate, indent=1))
        print(json.dumps({"smoke_gate": gate}, indent=1))
        if not gate["pass"]:
            finish({"stopped_at": "smoke gate", "smoke_gate_pass": False})
            return 3
    # --- the other runs ---
    queue = [p for p in plan if p[0] not in SMOKE]
    run_queue(queue, gpus)
    finish({"smoke_gate_pass": True})
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA round 16: the final setting of LERNA v2's learning-rate factor, from round 15. Read-only.

The rule (claude/LERNA_R16_FINAL_PLAN_2026-11-07.md, section 1, fixed on 6 November 2026 before any
round-15 result was seen): after round 15's ten seeds, the setting with the higher mean accuracy at
35%, averaged over QNLI and SST-2, is the final one; a tie goes to the simpler setting, without the
factor. "lr" is LERNA v2 with the factor (lerna2_b035), "nolr" without it (lerna2_nolr_b035).

It reads round 15's check_report.json, which carries every development-task run of rounds 13-15 with
its own check's verdict, and writes the setting ("lr" or "nolr") to --write. It refuses (exit 2,
nothing written) unless round 15's check passed integrity and both settings have all ten seeds on
both tasks.

Usage:
  python -s -B LERNA_R16_RULE.py --r15 /home/nanhangproj/LERNA_r15/dev --write <file>
"""
import argparse
import json
import sys
from pathlib import Path

VERSION = "LERNA_R16_RULE 2026-11-07"
SEEDS = (11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
TASKS = ("qnli", "sst-2")
ARMS = {"lr": "lerna2_b035", "nolr": "lerna2_nolr_b035"}


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--r15", required=True)
    ap.add_argument("--write", required=True)
    a = ap.parse_args()
    out = Path(a.write)
    if out.exists():
        print(f"STOP: {out} already exists", file=sys.stderr)
        return 2
    rp = Path(a.r15) / "check_report.json"
    if not rp.is_file():
        print(f"STOP: {rp} is missing; round 15's check must have run", file=sys.stderr)
        return 2
    rep = json.loads(rp.read_text())
    problems = []
    if rep.get("integrity") != "PASS":
        problems.append(f"round 15's check reported integrity {rep.get('integrity')!r}")
    if not (rep.get("smoke_gate") or {}).get("pass"):
        problems.append("round 15's smoke gate did not pass")
    table = {}
    for x in rep.get("comparators", []) + rep.get("runs", []):
        if str(x.get("name", "")).split(":")[-1].startswith("repro_"):
            continue
        table[(x.get("task"), x.get("label", x.get("arm")), x.get("seed"))] = x
    means = {}
    for task in TASKS:
        for key, arm in ARMS.items():
            accs = []
            for s in SEEDS:
                x = table.get((task, arm, s))
                if x is None or not x.get("ok") or not isinstance((x.get("facts") or {}).get("accuracy"), (int, float)):
                    problems.append(f"{task} {arm} seed {s}: missing or failed its check")
                    continue
                accs.append(100.0 * x["facts"]["accuracy"])
            means[(task, key)] = sum(accs) / len(accs) if accs else None
            print(f"{task:<6} {arm:<17} seeds {len(accs):>2}  mean accuracy {means[(task, key)]}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2
    lr = sum(means[(t, "lr")] for t in TASKS) / len(TASKS)
    nolr = sum(means[(t, "nolr")] for t in TASKS) / len(TASKS)
    choice = "lr" if lr > nolr else "nolr"
    print(f"with the learning-rate factor {lr:.4f}, without {nolr:.4f} (mean of QNLI and SST-2 at 35%) -> {choice}")
    out.write_text(choice + "\n")
    print(f"final setting: {choice} (written to {out})")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA round 16: checks and the final comparison's pre-specified tables. Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, SMOKE_GATE.json, runs/), round 15's folder
(--r15: its check_report.json, which carries every development-task run of rounds 13-15 and Step 5
with its own check's verdict, and its run folders), round 13's folder (--r13) and the Step 5 main
study's folder (--step5), and writes only check_report.json, CHECK_SUMMARY.txt, FINAL_TABLE.csv
and MAIN_TABLE.csv into the launcher's folder. Exit 0 means the report was written; the verdict is
inside it. Exit 2 means the folder isn't a finished launcher folder.

Per new run, it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, revisions, device, and
    each method's own options;
  - the exact counts (forward and backward passes, skips, updates, scheduler steps, warmup) and a
    final LR of 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases, attention,
    AdamW betas and eps, the pinned GPU;
  - the batch log (9 fields per row) and each method's own accounting against it: the budget
    (within 0.005) and the warmup for the methods on LERNA v2's controller; the scoring passes of
    Selective Backprop and fresh-score importance sampling, token for token; KAKURENBO's epochs and
    IES's mastered examples; DropBP's dropped blocks, step by step; the compute units, recomputed;
  - that every run with full fine-tuning's step count trained on full fine-tuning's scheduled
    batches, row for row (MRPC and RTE: this round's full fine-tuning; QNLI: Step 5's; SST-2:
    round 13's and round 15's);
  - the three reproductions of round 15, bit for bit.

Then the reading fixed in claude/LERNA_R16_FINAL_PLAN_2026-11-07.md, over the ten seeds 11-43:
  - the final setting: the one round 15's ten-seed rule chose (recomputed here from round 15's
    runs), which must be the --final-variant the launch used;
  - measured compute = units / full fine-tuning's units for the same task and seed, units = forward
    padded tokens + extra forward passes + 2 x updated padded tokens x the backward share that ran;
  - THE FINAL TABLE: every method's mean accuracy (SD) on SST-2, QNLI, MRPC and RTE, its mean over
    the tasks and its mean compute, by compute group;
  - THE MAIN TABLE, per task: LERNA v2 minus each compared method, paired by seed (mean, 95%
    t-interval, paired-t p-value, Holm's adjustment over the task's rows, seeds favouring LERNA v2).
    EDGE if the adjusted p is below 0.05 and the mean above 0, LOSS if below 0.05 and the mean below
    0, otherwise no significant difference. Across the tasks: each row's four readings, and a pooled
    test (per seed, the mean of the four tasks' paired differences; Holm over the rows run on all
    four tasks), read the same way;
  - THE ABLATIONS: the 2 x 2 at 35% (scores x learning-rate factor), the learning-rate factor at
    each budget, LERNA v2 against random keep at each budget, soft sampling against hard top-k,
    stored against fresh scores, budget exactness against the uncontrolled methods' compute, and
    wall-clock time.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R16_FINAL_CHECK 2026-11-07"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
SEEDS = (11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
OLD_SEEDS = (11, 13, 17, 19, 23)
TASKS = ("sst-2", "qnli", "mrpc", "rte")
DEV = ("qnli", "sst-2")
SMALL = ("mrpc", "rte")
SHORT = {"qnli": "qnli", "sst-2": "sst2", "mrpc": "mrpc", "rte": "rte"}
TASK_NAME = {"qnli": "QNLI", "sst-2": "SST-2", "mrpc": "MRPC", "rte": "RTE"}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349, "mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
HORIZON = {"qnli": 6548, "sst-2": 4210, "mrpc": 1150, "rte": 780}
RATE = 0.60
PLAIN_FRACTIONS = {"plain_030": 0.30, "plain_050": 0.50, "plain_070": 0.70}
# arm: (budget, scores, learning-rate factor)
LERNA2 = {"lerna2_b035": (0.35, True, True), "lerna2_nolr_b035": (0.35, True, False),
          "randkeep_lr_b035": (0.35, False, True), "randkeep_b035": (0.35, False, False),
          "lerna2_b040": (0.40, True, True), "randkeep_b040": (0.40, False, False),
          "lerna2_b060": (0.60, True, True), "lerna2_b083": (0.83, True, True),
          "randkeep_b060": (0.60, False, False), "randkeep_b083": (0.83, False, False),
          "el2n_topk_b035": (0.35, True, False), "el2n_topk_b060": (0.60, True, False),
          "lerna2_nolr_b040": (0.40, True, False), "lerna2_nolr_b060": (0.60, True, False),
          "lerna2_nolr_b083": (0.83, True, False)}
TOPK = ("el2n_topk_b035", "el2n_topk_b060")
LERNA2_OPTIONS = {"lerna2_pi_min": 0.1, "lerna2_window": 64, "lerna2_chunks": 16}
RANKED = {"egreedy_b035": (0.35, "egreedy"), "ucb_b035": (0.35, "ucb"), "orderdp_b035": (0.35, "orderdp")}
FRESH_IS = {"isfresh_b060": 0.60, "isfresh_b083": 0.83}
SB = {"sb_b060": 0.60, "sb_b083": 0.83}
DROPBP = {"dropbp_p050": 0.5, "dropbp_p0875": 0.875}
COMPARED = tuple(RANKED) + tuple(FRESH_IS) + tuple(SB) + ("kakurenbo", "ies") + tuple(DROPBP)
NOLR_EXTRA = ("lerna2_nolr_b040", "lerna2_nolr_b060", "lerna2_nolr_b083")
CONTROLLED = tuple(LERNA2) + tuple(RANKED) + tuple(FRESH_IS)
SELECTION_ARMS = ("infobatch",) + tuple(LERNA2) + COMPARED
INFOBATCH_OPTIONS = {"infobatch": (0.5, 0.875), "infobatch_max": (0.9, 1.0)}
GATES = ("gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4")
BUDGET_TOLERANCE = 0.005
CURVE_ARMS = ("plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070", "full_finetune")
DROPBP_FLOPS = {"layers": 22, "attn_linear": 4 * 768 * 768, "attn_scores_per_position": 2 * 768, "mlp": 3 * 768 * 1152}
# 44 blocks x T steps of Bernoulli(p) draws: the realized fraction is within 0.02 of p
DROPBP_TOLERANCE = 0.02
REPRO = {"repro_sst2_el2n_topk_b035_seed11": "sst2_el2n_topk_b035_seed11",
         "repro_sst2_randkeep_b060_seed11": "sst2_randkeep_b060_seed11",
         "repro_sst2_lerna2_b083_seed29": "sst2_lerna2_b083_seed29"}
LABEL = {
    "full_finetune": "Full fine-tuning", "plain_030": "Plain training, 30% of steps",
    "reduced_steps": "Plain training, 40% of steps", "plain_050": "Plain training, 50% of steps",
    "equal_compute": "Plain training, 60% of steps", "plain_070": "Plain training, 70% of steps",
    "gate_s1_p4": "LERNA v1 (batch skipping)", "control_uniform_p4": "Random batch skipping",
    "gate_loss_p4": "Max-loss batch skipping", "stale_s1_p4": "M1, stale-score batch skipping",
    "infobatch": "InfoBatch (ICLR 2024)", "infobatch_max": "InfoBatch, r 0.9, no annealing",
    "el2n_topk_b035": "Dynamic EL2N top-k (2023), 35%", "el2n_topk_b060": "Dynamic EL2N top-k (2023), 60%",
    "randkeep_b035": "Random keep, 35%", "randkeep_b040": "Random keep, 40%", "randkeep_b060": "Random keep, 60%",
    "randkeep_b083": "Random keep, 83%", "randkeep_lr_b035": "Random keep + LR factor, 35%",
    "lerna2_b035": "LERNA v2 with LR factor, 35%", "lerna2_b040": "LERNA v2 with LR factor, 40%",
    "lerna2_b060": "LERNA v2 with LR factor, 60%", "lerna2_b083": "LERNA v2 with LR factor, 83%",
    "lerna2_nolr_b035": "LERNA v2 without LR factor, 35%", "lerna2_nolr_b040": "LERNA v2 without LR factor, 40%",
    "lerna2_nolr_b060": "LERNA v2 without LR factor, 60%", "lerna2_nolr_b083": "LERNA v2 without LR factor, 83%",
    "egreedy_b035": "eps-greedy (2021), 35%", "ucb_b035": "UCB (2021), 35%", "orderdp_b035": "OrderDP (ICLR 2026), 35%",
    "isfresh_b060": "Importance sampling, fresh scores (ICML 2018), 60%",
    "isfresh_b083": "Importance sampling, fresh scores (ICML 2018), 83%",
    "sb_b060": "Selective Backprop (2019), 60%", "sb_b083": "Selective Backprop (2019), 83%",
    "kakurenbo": "KAKURENBO (NeurIPS 2023)", "ies": "IES (ICLR 2025)",
    "dropbp_p050": "DropBP (NeurIPS 2024), p 0.5", "dropbp_p0875": "DropBP (NeurIPS 2024), p 0.875",
}
# THE FINAL TABLE: one row per method; LERNA v2 ("F35" etc.) in the final setting. Its compute group is
# set by the method's mean measured compute over the tasks it ran on (never by accuracy).
FINAL_ROWS = ["full_finetune", "infobatch", "kakurenbo", "ies", "sb_b083", "isfresh_b083", "randkeep_b083",
              "plain_070", "dropbp_p050", "infobatch_max", "sb_b060", "isfresh_b060", "el2n_topk_b060",
              "randkeep_b060", "gate_loss_p4", "control_uniform_p4", "gate_s1_p4", "equal_compute", "plain_050",
              "stale_s1_p4", "dropbp_p0875", "reduced_steps", "randkeep_b040", "orderdp_b035", "ucb_b035",
              "egreedy_b035", "el2n_topk_b035", "randkeep_b035", "plain_030", "F83", "F60", "F40", "F35"]
GROUPS = [("100%", 0.995, 9.0), ("75-95%", 0.75, 0.995), ("55-75%", 0.55, 0.75), ("35-55%", 0.33, 0.55),
          ("about 30%", 0.0, 0.33)]
# THE MAIN TABLE: (key, LERNA v2's budget, compared method). "auto": the compared method's compute is
# not controlled, so LERNA v2 runs at the largest budget not above that method's mean measured compute
# on the task (+0.01), so that LERNA v2 never uses more compute than the method it is compared with.
BUDGETS = (("F35", 0.35), ("F40", 0.40), ("F60", 0.60), ("F83", 0.83))
MAIN = [("vs_el2n_topk_35", "F35", "el2n_topk_b035"), ("vs_egreedy_35", "F35", "egreedy_b035"),
        ("vs_ucb_35", "F35", "ucb_b035"), ("vs_orderdp_35", "F35", "orderdp_b035"),
        ("vs_random_keep_35", "F35", "randkeep_b035"), ("vs_plain_40", "F40", "reduced_steps"),
        ("vs_dropbp_0875", "auto", "dropbp_p0875"), ("vs_m1", "auto", "stale_s1_p4"),
        ("vs_plain_60", "F60", "equal_compute"), ("vs_lerna_v1", "auto", "gate_s1_p4"),
        ("vs_random_skipping", "auto", "control_uniform_p4"), ("vs_maxloss_skipping", "auto", "gate_loss_p4"),
        ("vs_el2n_topk_60", "F60", "el2n_topk_b060"), ("vs_isfresh_60", "F60", "isfresh_b060"),
        ("vs_sb_60", "auto", "sb_b060"), ("vs_dropbp_050", "auto", "dropbp_p050"),
        ("vs_infobatch_max", "auto", "infobatch_max"), ("vs_infobatch", "auto", "infobatch"),
        ("vs_kakurenbo", "auto", "kakurenbo"), ("vs_ies", "auto", "ies"), ("vs_isfresh_83", "F83", "isfresh_b083"),
        ("vs_sb_83", "auto", "sb_b083"), ("vs_full", "F83", "full_finetune")]
T975 = {1: 12.706204736432095, 2: 4.302652729696142, 3: 3.182446305284263, 4: 2.7764451051977987,
        5: 2.570581835636314, 6: 2.4469118511449692, 7: 2.3646242515927844, 8: 2.306004135204166,
        9: 2.2621571628540993}


def final_arms(variant):
    lr = variant == "lr"
    return {f"F{b}": (f"lerna2_b0{b}" if lr else f"lerna2_nolr_b0{b}") for b in ("35", "40", "60", "83")}


def other_arms(variant):
    return final_arms("nolr" if variant == "lr" else "lr")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    """Compute units from batch-log rows of either format (6 or 9 fields)."""
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def dropbp_share(counts, width):
    f = DROPBP_FLOPS
    attn = f["attn_linear"] + f["attn_scores_per_position"] * int(width)
    full = f["layers"] * (attn + f["mlp"])
    a, m = counts
    return 1.0 - (a * attn + m * f["mlp"]) / float(full)


def compared_units(arm, rows, sel):
    """Units of a round-16 compared method: its extra forward passes and DropBP's backward share."""
    fwd = sum(int(x[2]) for x in rows if int(x[6]) == 1)
    extra = int((sel or {}).get("extra_forward_padded_tokens") or 0)
    if arm in DROPBP:
        counts = (sel or {}).get("drop_counts") or []
        upd = 0.0
        for x in rows:
            if int(x[4]) == 0:
                k = int(x[0])
                upd += int(x[2]) * dropbp_share(counts[k], int(x[2]) // max(int(x[3]), 1))
    else:
        upd = float(sum(int(x[2]) for x in rows if int(x[4]) == 0))
    return fwd + extra + 2.0 * upd


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm in ("full_finetune", "infobatch") or arm in LERNA2 or arm in COMPARED:
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm in PLAIN_FRACTIONS:
        eff, skips = int(round(PLAIN_FRACTIONS[arm] * T)), 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def _betacf(a, b, x):
    """Continued fraction for the regularized incomplete beta function (Lentz's method)."""
    tiny, eps = 1e-300, 1e-15
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def betainc(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x)
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbeta) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbeta) * _betacf(b, a, 1.0 - x) / b


def t_two_sided_p(t, df):
    return betainc(df / 2.0, 0.5, df / (df + t * t))


def holm(pvals):
    """Holm's step-down adjustment; None entries stay None."""
    idx = [i for i, p in enumerate(pvals) if isinstance(p, (int, float))]
    order = sorted(idx, key=lambda i: pvals[i])
    m = len(order)
    adj = [None] * len(pvals)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * pvals[i]))
        adj[i] = running
    return adj


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def summarize(values):
    """values: {seed: number or note}. Mean, SD, t-interval, paired-t p-value, positives."""
    vals = [g for g in values.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0), "by_seed": values}
    if n >= 2 and sd is not None and (n - 1) in T975:
        half = T975[n - 1] * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
        if sd > 0:
            out["p"] = t_two_sided_p(m / (sd / math.sqrt(n)), n - 1)
        else:
            out["p"] = 1.0 if m == 0 else 0.0  # every seed gave the same difference
    return out


def curve_at(points, c):
    pts = sorted(points)
    if len(pts) < 2 or c < pts[0][0] - 1e-12 or c > pts[-1][0] + 1e-12:
        return None
    for (c0, a0), (c1, a1) in zip(pts, pts[1:]):
        if c0 - 1e-12 <= c <= c1 + 1e-12:
            return a0 if c1 == c0 else a0 + (a1 - a0) * (c - c0) / (c1 - c0)
    return None


def check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts):
    """Each method's own accounting against its batch log."""
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    W = exp["warmup"]
    sched_tokens = sum(int(x[8]) for x in rows) if rows else None
    sched_examples = sum(int(x[7]) for x in rows) if rows else None
    if arm in CONTROLLED:
        if arm in LERNA2:
            budget, scores, lr = LERNA2[arm]
            mode, policy = ("topk" if arm in TOPK else "sample"), "lerna_budget"
        elif arm in RANKED:
            budget, mode = RANKED[arm]
            scores, lr, policy = False, False, "ranked_subset"
        else:
            budget, scores, lr, mode, policy = FRESH_IS[arm], True, False, "sample", "fresh_importance_sampling"
        for k, want in (("policy", policy), ("selection", mode), ("budget", budget),
                        ("use_scores", scores), ("use_lr_weight", lr), ("pi_min", 0.1), ("window", 64),
                        ("chunks", 16), ("warmup_steps", W), ("total_steps", T), ("steps_seen", T),
                        ("batches_per_epoch", bpe), ("num_examples", n_train), ("pruned_examples", dropped),
                        ("pruned_during_warmup", 0)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        rf = sel.get("realized_fraction")
        need(isinstance(rf, (int, float)) and abs(rf - budget) <= BUDGET_TOLERANCE,
             f"spent {rf} of the scheduled compute, budget {budget} +/- {BUDGET_TOLERANCE}")
        need(dropped > 0, "no example dropped")
        extra = 0
        if arm in FRESH_IS:
            extra = sum(int(x[8]) for x in rows[W:]) if rows else None
            need(sel.get("scoring_passes") == T - W, f"scoring_passes={sel.get('scoring_passes')}, expected {T - W}")
            need(sel.get("extra_forward_padded_tokens") == extra and sel.get("overhead_units") == extra,
                 "the scoring passes' tokens differ from the scheduled batches after the warmup")
        elif arm in RANKED:
            need(sel.get("extra_forward_padded_tokens") == 0, "eps-greedy / UCB / OrderDP ran an extra pass")
            for k, want in (("epsilon", 0.1), ("ema_alpha", 0.8), ("ucb_c", 1.0), ("orderdp_ratio", 0.6),
                            ("method", mode)):
                need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        if rows:
            need(sel.get("spent_units") == units_of(rows) + (extra or 0), "policy spent units differ from the batch log")
            need(sel.get("scheduled_units") == 3 * sched_tokens, "policy scheduled units differ from the batch log")
            need(sel.get("scheduled_examples") == sched_examples, "policy scheduled examples differ from the batch log")
        need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
             "kept + pruned differ from the scheduled examples")
        mw = sel.get("max_weight")
        cap = float(BATCH_SIZE) if (mode != "sample") else 10.0
        need(isinstance(mw, (int, float)) and mw <= cap + 1e-9, f"max_weight={mw}")
        if mode == "topk":
            need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
        facts["realized_fraction"] = rf
    elif arm in SB:
        want_beta = 1.0 / (SB[arm] - 1.0 / 3.0) - 1.0
        need(sel.get("policy") == "selective_backprop", f"policy {sel.get('policy')!r}")
        need(isinstance(sel.get("beta"), (int, float)) and abs(sel["beta"] - want_beta) < 1e-12, f"beta={sel.get('beta')}")
        for k, want in (("history", 1024), ("steps_seen", T), ("scoring_passes", T), ("pruned_examples", dropped),
                        ("budget", SB[arm]), ("num_examples", n_train), ("batches_per_epoch", bpe)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        if rows:
            need(sel.get("extra_forward_padded_tokens") == sched_tokens,
                 "the scoring passes' tokens differ from the scheduled batches")
            need(sel.get("scheduled_examples") == sched_examples, "policy scheduled examples differ from the batch log")
        need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
             "kept + pruned differ from the scheduled examples")
        facts["empty_batch_fallbacks"] = sel.get("empty_batch_fallbacks")
    elif arm == "kakurenbo":
        for k, want in (("policy", "kakurenbo_fixed_steps"), ("max_fraction", 0.3), ("tau", 0.7), ("steps_seen", T),
                        ("pruned_examples", dropped), ("num_examples", n_train), ("batches_per_epoch", bpe),
                        ("last_epoch", (T - 1) // bpe if bpe else None)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        ep = sel.get("epochs") or []
        need(len(ep) == (math.ceil(T / bpe) if bpe else -1), f"{len(ep)} epochs recorded")
        need(bool(ep) and ep[0].get("hidden") == 0, "KAKURENBO hid examples in the first epoch")
        need(sum(e.get("hidden") or 0 for e in ep) > 0 or dropped == 0, "KAKURENBO's epochs and its dropped count disagree")
        facts["hidden_examples"] = dropped  # a method outcome, not an integrity condition
        refresh_epochs = [e for e in ep if e.get("refresh") and (e.get("hidden") or 0) > 0]
        need((sel.get("extra_forward_passes") or 0) > 0 if refresh_epochs else sel.get("extra_forward_passes") == 0,
             "refresh passes don't match the epochs with hidden examples")
        facts["hidden_fractions"] = [e.get("hidden_fraction") for e in ep]
    elif arm == "ies":
        for k, want in (("policy", "ies_fixed_steps"), ("delta", 0.001), ("steps_seen", T), ("pruned_examples", dropped),
                        ("num_examples", n_train), ("batches_per_epoch", bpe), ("extra_forward_examples", dropped)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        ep = sel.get("epochs") or {}
        need(all(v.get("mastered") == 0 for k, v in ep.items() if int(k) < 3), "IES excluded examples before epoch 4")
        need(sum(v.get("mastered") or 0 for v in ep.values()) == dropped, "IES's mastered counts differ from the log")
        facts["mastered_fractions"] = {k: v.get("mastered_fraction") for k, v in ep.items()}
    elif arm in DROPBP:
        dc = sel.get("drop_counts") or []
        need(sel.get("policy") == "dropbp_uniform" and sel.get("drop_rate") == DROPBP[arm] and sel.get("allocation") == "uniform",
             f"DropBP policy {sel.get('policy')!r}, rate {sel.get('drop_rate')}")
        need(len(dc) == T and sel.get("steps_seen") == T, f"DropBP recorded {len(dc)} steps")
        need(sel.get("flops_per_token") == DROPBP_FLOPS, f"DropBP flops {sel.get('flops_per_token')}")
        need(dropped == 0 and sel.get("pruned_examples") == 0, "DropBP dropped examples")
        layers = DROPBP_FLOPS["layers"]
        need(all(isinstance(x, list) and len(x) == 2 and 0 <= x[0] <= layers and 0 <= x[1] <= layers for x in dc),
             "DropBP's per-step counts are malformed")
        frac = sel.get("dropped_block_fraction")
        if dc and len(dc) == T:
            mine = sum(a + m for a, m in dc) / float(2 * layers * T)
            need(isinstance(frac, (int, float)) and abs(frac - mine) < 1e-12, "dropped block fraction differs from the counts")
            need(abs(mine - DROPBP[arm]) <= DROPBP_TOLERANCE, f"dropped block fraction {mine:.4f}, rate {DROPBP[arm]}")
        facts["dropped_block_fraction"] = frac
    elif arm == "infobatch":
        anneal = (INFOBATCH_OPTIONS.get(label) or (None, None))[1]
        if anneal is not None:
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
            need(sel.get("stop_prune_step") == int(math.floor(anneal * T + 1e-9)), "stop_prune_step differs")
            need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
            need(len(sel.get("thresholds") or []) == math.ceil(T / bpe), "one threshold per epoch expected")
            fb = sel.get("empty_batch_fallbacks")
            if label == "infobatch":
                need(fb == 0, f"empty_batch_fallbacks={fb}")
            else:
                need(isinstance(fb, int) and fb >= 0, f"empty_batch_fallbacks={fb}")
                facts["empty_batch_fallbacks"] = fb
            need(dropped > 0, "no example dropped in a run longer than one epoch")


def check_run(p, end, out):
    name, task, arm, seed = p["name"], p["task"], p["arm"], p["seed"]
    label = p.get("label", arm)
    T = p["total_steps"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "task": task, "arm": arm, "label": label, "seed": seed, "total_steps": T, "source": "round 16"}
    need(T == HORIZON.get(task), f"total_steps {T} for {task}")
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, T)
    eff = exp["effective_total"]
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", T),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False), ("train_batch_size", BATCH_SIZE),
                 ("learning_rate", 2e-5), ("weight_decay", 0.01), ("grad_clip", 1.0),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"] if task == "qnli" else None)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    need(p["min_step"] == int(math.floor(0.06 * T + 1e-9)), f"min_step {p['min_step']} is not the warmup of {T}")
    if arm in LERNA2 or arm in RANKED or arm in FRESH_IS:
        for k, v in LERNA2_OPTIONS.items():
            need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        want = INFOBATCH_OPTIONS.get(label)
        need(want is not None and (c.get("infobatch_prune_ratio"), c.get("infobatch_anneal_fraction")) == want,
             f"InfoBatch options {c.get('infobatch_prune_ratio')}, {c.get('infobatch_anneal_fraction')} for {label}")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == eff - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == eff, f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    if arm != "stale_s1_p4":
        need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm not in SELECTION_ARMS:
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    if task == "mrpc":
        need(isinstance(r.get("final_eval_f1"), (int, float)), "MRPC F1 missing")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if not ok_shape:
            rows = []
        if rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            free = [x for x in rows if int(x[6]) == 0]
            need(len(free) == fskip, f"batch log has {len(free)} forward-free skips, result {fskip}")
            need(all(int(x[4]) == 1 and x[5] == "nan" for x in free), "a forward-free row isn't a skip with a NaN loss")
            need(all(math.isfinite(float(x[5])) for x in rows if int(x[6]) == 1), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) <= int(x[8]) for x in rows),
                 "real tokens must be positive and at most the padded, and those at most the scheduled")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm not in SELECTION_ARMS or arm in DROPBP:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            if arm in CONTROLLED:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows[:exp["warmup"]]), "an example dropped during the warmup")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    if arm in SELECTION_ARMS:
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts)
    elif arm == "stale_s1_p4":
        n_train = TRAIN_ROWS.get(task)
        bpe = math.ceil(n_train / BATCH_SIZE)
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need((sel.get("stale_decisions") or 0) + (sel.get("fresh_decisions") or 0) == eff,
                 "stale + fresh decisions don't add up to the scheduled batches")
            need(sel.get("forward_skips") == fskip, "policy forward_skips differ from the result")
            if eff > bpe:
                need(fskip > 0, "no skip without a forward pass in a run longer than one epoch")
                need((sel.get("fresh_decisions") or 0) >= bpe, "fewer fresh decisions than one epoch of batches")
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    units = None
    if rows:
        if arm in COMPARED:
            units = compared_units(arm, rows, sel if isinstance(sel, dict) else {})
            ca = r.get("compute_accounting") or {}
            cu = ca.get("compute_units")
            need(isinstance(cu, (int, float)) and abs(cu - units) <= 1e-6 * max(1.0, units),
                 f"compute accounting {cu} differs from the recomputed {units}")
        else:
            units = units_of(rows)
    facts.update(accuracy=acc, loss=loss, f1=r.get("final_eval_f1"), wall_seconds=r.get("wall_seconds"),
                 forward_skipped=fskip, examples_dropped=dropped, units=units)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def load_rows(folder, run_dir_name):
    """The batch-log rows of a run in an earlier round's folder (None if missing or inconsistent)."""
    found = sorted((folder / "runs" / run_dir_name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return None, None
    m = json.loads(found[0].read_text())
    blf = m.get("batch_log_file") or {}
    lpath = found[0].parent / str(blf.get("file", "batch_log.csv"))
    if not lpath.is_file() or sha256_file(lpath) != blf.get("sha256"):
        return m, None
    return m, read_log(lpath)[1]


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True)
    ap.add_argument("--r15", required=True, help="round 15's folder (.../LERNA_r15/dev), with its check_report.json")
    ap.add_argument("--r13", required=True, help="round 13's development folder (.../LERNA_r13/dev)")
    ap.add_argument("--step5", required=True, help="the Step 5 main study's folder (.../LERNA_step5_main/main)")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    r15, r13, step5 = Path(a.r15).resolve(), Path(a.r13).resolve(), Path(a.step5).resolve()
    meta = json.loads((out / "plan.json").read_text())
    variant = meta.get("final_variant")
    gate = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    integrity_fails, comparator_issues = [], []
    if variant not in ("lr", "nolr"):
        integrity_fails.append(f"plan.json's final_variant is {variant!r}")
        variant = "lr"
    if gate is None or not gate.get("pass"):
        integrity_fails.append("the smoke gate did not pass" if gate else "SMOKE_GATE.json missing")
    # the plan itself: every task, label and seed the plan fixes, once
    want = set()
    for task in SMALL:
        for lab in ("full_finetune", "plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070") + GATES + \
                ("infobatch", "infobatch_max") + tuple(LERNA2) + COMPARED:
            want |= {(task, lab, s) for s in SEEDS}
    for task in DEV:
        for lab in tuple(x for x in COMPARED if x != "ies") + (NOLR_EXTRA if variant == "nolr" else ()):
            want |= {(task, lab, s) for s in SEEDS}
    have = [(p["task"], p.get("label", p["arm"]), p["seed"]) for p in meta["plan"] if not p["name"].startswith("repro_")]
    if len(have) != len(set(have)) or set(have) != want:
        integrity_fails.append(f"the plan differs from the fixed plan ({len(set(have) ^ want)} entries differ)")
    if sorted(p["name"] for p in meta["plan"] if p["name"].startswith("repro_")) != sorted(REPRO):
        integrity_fails.append("the plan's reproductions differ from the fixed three")
    runs = [check_run(p, ends.get(p["name"]), out) for p in meta["plan"]]
    # round 15's report: every development-task run of rounds 13-15 and Step 5, with its own verdict
    rep15_path = r15 / "check_report.json"
    table = {}
    rep15 = None
    if rep15_path.is_file():
        rep15 = json.loads(rep15_path.read_text())
        if rep15.get("integrity") != "PASS":
            comparator_issues.append(f"round 15's own check reported integrity {rep15.get('integrity')}")
        for x in rep15.get("comparators", []) + rep15.get("runs", []):
            if str(x.get("name", "")).split(":")[-1].startswith("repro_"):
                continue
            rec = {"name": "r15report:" + str(x["name"]), "task": x["task"], "arm": x["arm"],
                   "label": x.get("label", x["arm"]), "seed": x["seed"], "ok": bool(x.get("ok")),
                   "fails": list(x.get("fails") or []), "facts": dict(x.get("facts") or {}), "source": "round 15 report"}
            if not rec["ok"]:
                comparator_issues.append(f"{rec['name']} left out: its own check failed")
            table[(rec["task"], rec["label"], rec["seed"])] = rec
    else:
        comparator_issues.append("round 15's check_report.json is missing: the development tasks have no comparators")
    for x in runs:
        if not x["name"].startswith("repro_"):
            key = (x["task"], x["label"], x["seed"])
            if key in table:
                integrity_fails.append(f"{x['name']} duplicates a round-15 run")
            table[key] = x
    # the final setting: round 15's ten-seed rule, recomputed
    rule = {}
    for task in DEV:
        for arm in ("lerna2_b035", "lerna2_nolr_b035"):
            accs = [100.0 * table[(task, arm, s)]["facts"]["accuracy"] for s in SEEDS
                    if (task, arm, s) in table and table[(task, arm, s)]["ok"]]
            rule[f"{task}/{arm}"] = {"n": len(accs), "mean": mean_sd(accs)[0]}
    lr_mean = mean_sd([rule[f"{t}/lerna2_b035"]["mean"] for t in DEV])[0]
    nolr_mean = mean_sd([rule[f"{t}/lerna2_nolr_b035"]["mean"] for t in DEV])[0]
    complete = all(rule[k]["n"] == len(SEEDS) for k in rule)
    rule_choice = None
    if isinstance(lr_mean, (int, float)) and isinstance(nolr_mean, (int, float)) and complete:
        rule_choice = "lr" if lr_mean > nolr_mean else "nolr"
    rule.update(with_lr_mean=lr_mean, without_lr_mean=nolr_mean, complete=complete, choice=rule_choice,
                launched=variant)
    if rule_choice != variant:
        integrity_fails.append(f"the launch used --final-variant {variant}, round 15's rule gives {rule_choice}")
    F, O = final_arms(variant), other_arms(variant)
    # full fine-tuning's batch logs, for the same-batches check of the development-task runs
    full_logs = {}
    for task in SMALL:
        for s in SEEDS:
            x = table.get((task, "full_finetune", s))
            full_logs[(task, s)] = (x.get("log_rows") or None) if x and x["ok"] else None
    for s in SEEDS:
        _, rows = load_rows(step5, f"full_finetune_seed{s}")
        full_logs[("qnli", s)] = [(int(x[3]), int(x[2])) for x in rows] if rows else None
        src = r13 if s in OLD_SEEDS else r15
        _, rows = load_rows(src, f"sst2_full_finetune_seed{s}")
        full_logs[("sst-2", s)] = [(int(x[3]), int(x[2])) for x in rows] if rows else None
    for k, v in list(full_logs.items()):
        if v and k[0] in SMALL:
            full_logs[k] = [(int(x[3]), int(x[2])) for x in v]
    same_batches = {}
    for x in runs:
        if x["arm"] in ("full_finetune",) or x["name"].startswith("repro_") or not x.get("log_rows"):
            continue
        if expected_counts(x["arm"], x["total_steps"])["effective_total"] != x["total_steps"]:
            continue  # the plain runs have their own, shorter schedule
        frows = full_logs.get((x["task"], x["seed"]))
        same = bool(frows) and len(frows) == len(x["log_rows"]) and all(
            fr == (int(r_[7]), int(r_[8])) for fr, r_ in zip(frows, x["log_rows"]))
        same_batches[x["name"]] = same
        if not same:
            integrity_fails.append(f"{x['name']}: scheduled batches differ from full fine-tuning's"
                                   + ("" if frows else " (full fine-tuning's batch log is missing)"))
    # reproductions of round 15, bit for bit
    by_name = {x["name"]: x for x in runs}
    repro = {}
    for mine, theirs in REPRO.items():
        x = by_name.get(mine)
        m15, rows15 = load_rows(r15, theirs)
        if x is None or not x.get("log_rows") or not rows15 or m15 is None:
            repro[mine] = {"comparable": False}
            integrity_fails.append(f"reproduction of round 15's {theirs} not comparable")
            continue
        res15 = m15.get("result", {})
        same = {"same_accuracy": res15.get("final_eval_accuracy") == x["facts"].get("accuracy"),
                "same_loss": res15.get("final_eval_loss") == x["facts"].get("loss"),
                "same_batch_log": rows15 == x["log_rows"]}
        repro[mine] = dict(comparable=True, **same)
        if not all(same.values()):
            integrity_fails.append(f"{mine} does not reproduce round 15's {theirs} bit for bit")
    for x in runs:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    # measured compute, relative to full fine-tuning of the same task and seed
    for key, x in table.items():
        full = table.get((key[0], "full_finetune", key[2]))
        u, fu = x["facts"].get("units"), (full or {}).get("facts", {}).get("units")
        x["facts"]["compute"] = (u / fu) if (u and fu and full.get("ok")) else None
    analysis = {}
    for task in TASKS:
        curves = {}
        for s in SEEDS:
            pts = []
            for arm in CURVE_ARMS:
                x = table.get((task, arm, s))
                if x and x["ok"] and isinstance(x["facts"].get("compute"), (int, float)):
                    pts.append((x["facts"]["compute"], 100.0 * x["facts"]["accuracy"]))
            curves[s] = pts
        full_wall = mean_sd([table[(task, "full_finetune", s)]["facts"].get("wall_seconds") for s in SEEDS
                             if (task, "full_finetune", s) in table and table[(task, "full_finetune", s)]["ok"]])[0]

        def resolve(lab):
            return F.get(lab, lab)

        def acc(lab, s):
            x = table.get((task, resolve(lab), s))
            return 100.0 * x["facts"]["accuracy"] if x and x["ok"] else None

        labels = sorted({k[1] for k in table if k[0] == task})
        methods = {}
        for lab in labels:
            gaps, cs, walls, notes, accs, f1s = {}, [], [], {}, [], []
            for s in SEEDS:
                x = table.get((task, lab, s))
                if not x or not x["ok"]:
                    notes[s] = "run missing or failed its checks"
                    continue
                c = x["facts"].get("compute")
                cs.append(c)
                walls.append(x["facts"].get("wall_seconds"))
                accs.append(100.0 * x["facts"]["accuracy"])
                if isinstance(x["facts"].get("f1"), (int, float)):
                    f1s.append(100.0 * x["facts"]["f1"])
                if len(curves[s]) < len(CURVE_ARMS):
                    notes[s] = f"curve has {len(curves[s])} of {len(CURVE_ARMS)} points"
                    continue
                cv = curve_at(curves[s], c) if isinstance(c, (int, float)) else None
                gaps[s] = "outside the curve" if cv is None else 100.0 * x["facts"]["accuracy"] - cv
            sm = summarize(gaps)
            mw = mean_sd(walls)[0]
            sm.update(n_runs=len(accs), mean_accuracy=mean_sd(accs)[0], sd_accuracy=mean_sd(accs)[1],
                      mean_f1=mean_sd(f1s)[0], mean_compute=mean_sd(cs)[0],
                      min_compute=min([v for v in cs if isinstance(v, (int, float))], default=None),
                      max_compute=max([v for v in cs if isinstance(v, (int, float))], default=None),
                      mean_wall_seconds=mw, wall_fraction=(mw / full_wall) if (full_wall and mw) else None,
                      notes=notes)
            methods[lab] = sm

        def paired(la, lb):
            vals = {}
            for s in SEEDS:
                va, vb = acc(la, s), acc(lb, s)
                if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                    vals[s] = va - vb
            return summarize(vals)

        main_rows = []
        for key, la, lb in MAIN:
            if not any((task, lb, s) in table for s in SEEDS):
                continue  # not run on this task (IES on the 2-epoch tasks)
            cmp_c = (methods.get(lb) or {}).get("mean_compute")
            rule_note = None
            if la == "auto":
                fits = [f for f, b in BUDGETS if isinstance(cmp_c, (int, float)) and b <= cmp_c + 0.01]
                la = fits[-1] if fits else "F35"
                rule_note = (f"LERNA v2 at the largest budget not above the compared method's compute "
                             f"{cmp_c:.3f}" if fits else "the compared method's compute is below every budget")
            d = paired(la, lb)
            d.update(key=key, method=resolve(la), budget_key=la, budget_rule=rule_note, compared=lb,
                     compute_method=(methods.get(resolve(la)) or {}).get("mean_compute"),
                     compute_compared=cmp_c)
            main_rows.append(d)
        adj = holm([r_.get("p") for r_ in main_rows])
        for r_, pa in zip(main_rows, adj):
            r_["p_holm"] = pa
            if r_["n"] < 3 or pa is None:
                r_["reading"] = "too few seeds"
            elif pa < 0.05 and r_["mean"] > 0:
                r_["reading"] = "EDGE"
            elif pa < 0.05 and r_["mean"] < 0:
                r_["reading"] = "LOSS"
            else:
                r_["reading"] = "no significant difference"
        abl = {}

        def contrast(fn):
            vals = {}
            for s in SEEDS:
                try:
                    v_ = fn(s)
                except TypeError:
                    v_ = None
                if isinstance(v_, (int, float)):
                    vals[s] = v_
            return summarize(vals)

        abl["score_effect_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("randkeep_lr_b035", s))
                                                           + (acc("lerna2_nolr_b035", s) - acc("randkeep_b035", s))))
        abl["lr_factor_effect_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                               + (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s))))
        abl["interaction_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                          - (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s))))
        for b in ("035", "040", "060", "083"):
            abl[f"lr_factor_{b}"] = paired(f"lerna2_b{b}", f"lerna2_nolr_b{b}")
        for b, rk in (("35", "randkeep_b035"), ("40", "randkeep_b040"), ("60", "randkeep_b060"), ("83", "randkeep_b083")):
            abl[f"final_minus_random_keep_{b}"] = paired(f"F{b}", rk)
        abl["soft_minus_hard_35"] = paired("lerna2_nolr_b035", "el2n_topk_b035")
        abl["stored_minus_fresh_60"] = paired("lerna2_nolr_b060", "isfresh_b060")
        abl["stored_minus_fresh_83"] = paired("lerna2_nolr_b083", "isfresh_b083")
        budget_dev = {}
        for arm in CONTROLLED:
            budget = (LERNA2.get(arm) or (None,))[0] or (RANKED.get(arm) or (None,))[0] or FRESH_IS.get(arm)
            devs = [abs(table[(task, arm, s)]["facts"]["realized_fraction"] - budget) for s in SEEDS
                    if (task, arm, s) in table and table[(task, arm, s)]["ok"]
                    and isinstance(table[(task, arm, s)]["facts"].get("realized_fraction"), (int, float))]
            if devs:
                budget_dev[arm] = {"n": len(devs), "max_abs_deviation": max(devs)}
        uncontrolled = {lab: {"min_compute": methods[lab]["min_compute"], "max_compute": methods[lab]["max_compute"],
                              "mean_compute": methods[lab]["mean_compute"]}
                        for lab in ("infobatch", "infobatch_max", "kakurenbo", "ies", "sb_b060", "sb_b083",
                                    "dropbp_p050", "dropbp_p0875", "stale_s1_p4") if lab in methods}
        analysis[task] = {"methods": methods, "main": main_rows, "ablations": abl, "budget_exactness": budget_dev,
                          "uncontrolled_compute": uncontrolled, "curves": {str(s): sorted(v) for s, v in curves.items()}}
    # THE FINAL TABLE
    final_table = []
    for lab in FINAL_ROWS:
        arm = F.get(lab, lab)
        row = {"row": lab, "arm": arm, "ours": lab in F,
               "name": (LABEL[arm].replace("with LR factor", "").replace("without LR factor", "").replace("  ", " ")
                        .replace("LERNA v2 ,", "LERNA v2,") + " (ours)") if lab in F else LABEL[arm],
               "tasks": {}}
        means, comps = [], []
        for task in TASKS:
            d = analysis[task]["methods"].get(arm)
            if d and d["n_runs"]:
                row["tasks"][task] = {"mean": d["mean_accuracy"], "sd": d["sd_accuracy"], "n": d["n_runs"],
                                      "compute": d["mean_compute"], "f1": d.get("mean_f1")}
                means.append(d["mean_accuracy"])
                comps.append(d["mean_compute"])
        row["mean_over_tasks"] = mean_sd(means)[0] if len(means) == len(TASKS) else None
        row["mean_over_tasks_note"] = None if len(means) == len(TASKS) else f"{len(means)} of {len(TASKS)} tasks"
        row["mean_compute"] = mean_sd(comps)[0]
        c = row["mean_compute"]
        row["group"] = next((g for g, lo, hi in GROUPS if isinstance(c, (int, float)) and lo <= c < hi), "no compute")
        if row["tasks"]:
            final_table.append(row)
    order = {g: i for i, (g, _, _) in enumerate(GROUPS)}
    final_table.sort(key=lambda r_: (order.get(r_["group"], 99), r_["ours"], -(r_["mean_compute"] or 0.0)))
    for group in {r_["group"] for r_ in final_table}:
        rows_g = [r_ for r_ in final_table if r_["group"] == group]
        for task in TASKS:
            vals = [(r_["tasks"][task]["mean"], r_["row"]) for r_ in rows_g if task in r_["tasks"]]
            if vals:
                best = max(vals)[1]
                for r_ in rows_g:
                    if r_["row"] == best:
                        r_.setdefault("best_in_group", []).append(task)
    # ACROSS THE TASKS: each row's readings per task, and the pooled test: per seed, the mean of the
    # four tasks' paired differences; t-interval and p over the seeds, Holm over the rows run on all
    # four tasks
    pooled = []
    for key, la, lb in MAIN:
        rows_t = {t: next((r_ for r_ in analysis[t]["main"] if r_["key"] == key), None) for t in TASKS}
        readings = {t: (r_ or {}).get("reading") for t, r_ in rows_t.items()}
        per_seed = {}
        for s in SEEDS:
            ds = [((r_ or {}).get("by_seed") or {}).get(s) for r_ in rows_t.values()]
            if all(isinstance(v_, (int, float)) for v_ in ds):
                per_seed[s] = sum(ds) / len(ds)
        used = sorted({(r_ or {}).get("method") for r_ in rows_t.values() if r_})
        pooled.append({"key": key, "method": " / ".join(used) if used else F.get(la, la), "compared": lb,
                       "readings": readings,
                       "edges": sum(1 for v_ in readings.values() if v_ == "EDGE"),
                       "losses": sum(1 for v_ in readings.values() if v_ == "LOSS"),
                       "all_tasks": all(r_ is not None for r_ in rows_t.values()),
                       "pooled": summarize(per_seed)})
    adj = holm([pr["pooled"].get("p") if pr["all_tasks"] else None for pr in pooled])
    for pr, pa in zip(pooled, adj):
        d = pr["pooled"]
        d["p_holm"] = pa
        if not pr["all_tasks"]:
            d["reading"] = "not run on every task"
        elif d["n"] < 3 or pa is None:
            d["reading"] = "too few seeds"
        elif pa < 0.05 and d["mean"] > 0:
            d["reading"] = "EDGE"
        elif pa < 0.05 and d["mean"] < 0:
            d["reading"] = "LOSS"
        else:
            d["reading"] = "no significant difference"
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails,
              "comparator_issues": comparator_issues, "smoke_gate": gate, "final_variant": variant,
              "final_arms": F, "other_setting_arms": O, "rule": rule,
              "round15_report_integrity": (rep15 or {}).get("integrity"),
              "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "reproduction": repro, "same_scheduled_batches": same_batches, "final_table": final_table,
              "pooled_readings": pooled, "analysis": analysis,
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    def ci_text(d):
        ci = d.get("ci95")
        return f"[{num(ci[0] if ci else None, '+.3f')}, {num(ci[1] if ci else None, '+.3f')}]"

    # the CSV tables
    with open(out / "FINAL_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["group", "method", "arm", "compute"] + [f"{TASK_NAME[t]} mean" for t in TASKS]
                   + [f"{TASK_NAME[t]} sd" for t in TASKS] + [f"{TASK_NAME[t]} n" for t in TASKS]
                   + ["mean over tasks", "MRPC F1", "best in group"])
        for r_ in final_table:
            w.writerow([r_["group"], r_["name"], r_["arm"], num(r_["mean_compute"], ".3f")]
                       + [num((r_["tasks"].get(t) or {}).get("mean"), ".2f") for t in TASKS]
                       + [num((r_["tasks"].get(t) or {}).get("sd"), ".2f") for t in TASKS]
                       + [(r_["tasks"].get(t) or {}).get("n", 0) for t in TASKS]
                       + [num(r_["mean_over_tasks"], ".2f"), num((r_["tasks"].get("mrpc") or {}).get("f1"), ".2f"),
                          " ".join(TASK_NAME[t] for t in r_.get("best_in_group", []))])
    with open(out / "MAIN_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["task", "row", "LERNA v2 arm", "compared", "n", "mean", "ci low", "ci high", "p", "p Holm",
                    "seeds favouring LERNA v2", "compute LERNA v2", "compute compared", "reading"])
        for task in TASKS:
            for r_ in analysis[task]["main"]:
                ci = r_.get("ci95") or [None, None]
                w.writerow([TASK_NAME[task], r_["key"], r_["method"], r_["compared"], r_["n"], num(r_["mean"], "+.3f"),
                            num(ci[0], "+.3f"), num(ci[1], "+.3f"), num(r_.get("p"), ".4f"), num(r_.get("p_holm"), ".4f"),
                            r_["positive"], num(r_["compute_method"], ".3f"), num(r_["compute_compared"], ".3f"),
                            r_["reading"]])
        for pr in pooled:
            d = pr["pooled"]
            ci = d.get("ci95") or [None, None]
            w.writerow(["pooled", pr["key"], pr["method"], pr["compared"], d["n"], num(d["mean"], "+.3f"),
                        num(ci[0], "+.3f"), num(ci[1], "+.3f"), num(d.get("p"), ".4f"), num(d.get("p_holm"), ".4f"),
                        d["positive"], "", "", d["reading"]])
    lines = [f"LERNA FINAL COMPARISON CHECK ({VERSION}): integrity {verdict}; "
             f"{report['runs_ok']} of {len(runs)} new runs pass; smoke gate "
             f"{'passed' if gate and gate.get('pass') else 'NOT passed'}; round 15's own check: "
             f"{report['round15_report_integrity']}",
             f"  final setting: {variant} ('lr' = with the learning-rate factor); round 15's rule: with "
             f"{num(lr_mean, '.3f')}, without {num(nolr_mean, '.3f')} (mean of QNLI and SST-2 at 35%, ten seeds) "
             f"-> {rule_choice}",
             "  reproduction of round 15: " +
             ", ".join(f"{k}: {'identical' if all(v.get(z) for z in ('same_accuracy', 'same_loss', 'same_batch_log')) else 'DIFFERS'}"
                       if v.get("comparable") else f"{k}: not comparable" for k, v in repro.items()),
             f"  runs on full fine-tuning's scheduled batches: {sum(1 for v in same_batches.values() if v)} of "
             f"{len(same_batches)}",
             "  THE FINAL TABLE (accuracy %, mean and SD over the seeds; compute = mean measured fraction of full "
             "fine-tuning; * best in its compute group)"]
    lines.append(f"    {'method':<52} {'compute':>7}  " + "  ".join(f"{TASK_NAME[t]:>14}" for t in TASKS) + "     mean")
    group = None
    for r_ in final_table:
        if r_["group"] != group:
            group = r_["group"]
            lines.append(f"    -- {group} --")
        cells = []
        for t in TASKS:
            d = r_["tasks"].get(t)
            if not d:
                cells.append(f"{'-':>14}")
                continue
            star = "*" if t in r_.get("best_in_group", []) else " "
            nn = "" if d["n"] == len(SEEDS) else f" n{d['n']}"
            cells.append(f"{num(d['mean'], '.2f'):>6}{star}({num(d['sd'], '.2f')}){nn}".rjust(14))
        lines.append(f"    {r_['name']:<52} {num(r_['mean_compute'], '.3f'):>7}  " + "  ".join(cells)
                     + f"  {num(r_['mean_over_tasks'], '.2f'):>7}")
    for task in TASKS:
        an = analysis[task]
        lines.append(f"  {TASK_NAME[task]}: THE MAIN TABLE (LERNA v2 in the final setting minus the compared method, "
                     f"paired by seed; accuracy points)")
        for r_ in an["main"]:
            lines.append(f"    {r_['method']:<17} vs {LABEL.get(r_['compared'], r_['compared']):<52} "
                         f"n {r_['n']:>2}  mean {num(r_['mean'], '+.3f'):>7}  {ci_text(r_)}  "
                         f"p {num(r_.get('p'), '.4f')}  Holm {num(r_.get('p_holm'), '.4f')}  "
                         f"ahead {r_['positive']} of {r_['n']}  compute {num(r_['compute_method'], '.3f')} vs "
                         f"{num(r_['compute_compared'], '.3f')}  -> {r_['reading']}"
                         + ("  [v2's budget set by the compared method's compute]" if r_.get("budget_rule") else ""))
    lines.append("  ACROSS THE TASKS (readings per task: SST-2, QNLI, MRPC, RTE; then the pooled test: per seed, the")
    lines.append("  mean of the four tasks' paired differences, Holm over the rows run on all four tasks)")
    for pr in pooled:
        d = pr["pooled"]
        lines.append(f"    {pr['method']:<17} vs {LABEL.get(pr['compared'], pr['compared']):<52} "
                     + ", ".join(f"{TASK_NAME[t]} {pr['readings'][t] or '-'}" for t in TASKS)
                     + f"  -> EDGE on {pr['edges']}, LOSS on {pr['losses']}; pooled n {d['n']} "
                     f"mean {num(d['mean'], '+.3f')} {ci_text(d)} Holm {num(d.get('p_holm'), '.4f')} -> {d['reading']}")
    for task in TASKS:
        an = analysis[task]
        lines.append(f"  {TASK_NAME[task]}: ABLATIONS (paired by seed; accuracy points)")
        for k, d in an["ablations"].items():
            lines.append(f"    {k:<28} n {d['n']:>2}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  "
                         f"p {num(d.get('p'), '.4f')}  positive {d['positive']} of {d['n']}")
        lines.append(f"  {TASK_NAME[task]}: gap to the plain-run curve (mean, 95% t-interval, positive seeds), compute "
                     f"(range), wall/full")
        for lab, d in sorted(an["methods"].items(), key=lambda kv: -(kv[1]["mean_compute"] or 0)):
            lines.append(f"    {LABEL.get(lab, lab):<52} n {d['n']:>2}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  "
                         f"positive {d['positive']:>2} of {d['n']:>2}  compute {num(d['mean_compute'], '.3f')} "
                         f"({num(d['min_compute'], '.3f')}-{num(d['max_compute'], '.3f')})  "
                         f"wall {num(d['wall_fraction'], '.2f')}")
            for s, why in d["notes"].items():
                lines.append(f"      seed {s}: {why}")
        worst = max([v["max_abs_deviation"] for v in an["budget_exactness"].values()], default=None)
        lines.append(f"  {TASK_NAME[task]}: budget exactness: largest |spent - budget| over every run on LERNA v2's "
                     f"controller: {num(worst, '.5f')}; uncontrolled compute: "
                     + "; ".join(f"{LABEL.get(k, k)} {num(v['min_compute'], '.3f')}-{num(v['max_compute'], '.3f')}"
                                 for k, v in an["uncontrolled_compute"].items()))
    for msg in integrity_fails:
        lines.append(f"  FAIL: {msg}")
    for msg in comparator_issues:
        lines.append(f"  COMPARATOR: {msg}")
    lines.append("  The readings EDGE / LOSS / no significant difference use Holm's adjustment over each task's main")
    lines.append("  table rows, at 0.05. MRPC and RTE are untouched by LERNA v2's design; QNLI and SST-2 are not.")
    text = "\n".join(lines)
    (out / "CHECK_SUMMARY.txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

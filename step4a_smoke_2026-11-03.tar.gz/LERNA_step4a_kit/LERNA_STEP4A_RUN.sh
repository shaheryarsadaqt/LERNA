#!/usr/bin/env bash
# LERNA Step 4a: bounded real-model smoke on CPU (QNLI), 3 November 2026.
#
# Runs exactly four short real-model runs of the accepted runner, in this order, and stops at
# the first failure. There are no retries.
#   1. s4a-1-reduced   reduced_steps                        160 steps
#   2. s4a-2-gate      gate_s1_p1, phase_exact_v1, S1       400 steps, 240 skipped
#   3. s4a-3-uniform   control_uniform_p1, phase_exact_v1   400 steps, 240 skipped
#   4. s4a-4-full      full_finetune                        400 steps
# All runs use QNLI, the pinned model and GLUE revisions, the probe exclusion file, seed 0,
# skip rate 0.6, at most 4 consecutive skips, min_step 50, and the runner's default recipe.
#
# Before any run it checks:
#   - the work folder doesn't exist yet;
#   - git HEAD, a clean tree, and the runner and probe-file hashes;
#   - that round 3 reproduced the probe file's ids_sha256.
# It then validates the four configurations with --dry-run.
#
# After run 1 it stops if that run took longer than GUARD_SECONDS (default 1800), so the smoke
# stays bounded. At the end it writes a summary with LERNA_STEP4A_SUMMARY.py.
# Exit 0: all four runs exited 0 and the summary was written (read its verdict).
# Exit 1: stopped. Exit 2: the work folder already exists.
set -u -o pipefail

REPO=${REPO:-/home/nanhangproj/LERNA}
WORK=${WORK:-/home/nanhangproj/LERNA_step4a}
PY=${PY:-/home/nanhangproj/miniconda3/bin/python}
PROV_SUMMARY=${PROV_SUMMARY:-/home/nanhangproj/LERNA_step4_prov/report/SUMMARY.txt}
HF_CACHE_DIR=${HF_CACHE_DIR:-/raid/hf_cache}
GUARD_SECONDS=${GUARD_SECONDS:-1800}
export EXPECT_HEAD=${EXPECT_HEAD:-3af68e85302a4975ef1eb2079e41066db1366520}
export EXPECT_RUNNER=${EXPECT_RUNNER:-50a967ba1de3b9c0ad8e705497709e64ea852990ea2490775f5b938c79a62df8}
export EXPECT_PROBE=${EXPECT_PROBE:-234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408}
MREV=45d08642849e5c5701b162671ac811b7654bfd9f
DREV=bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c
PROBE="$REPO/experiments/probe_indices_v4.json"
RUNNER="$REPO/scripts/run_controller_ablation.py"
KIT=$(cd "$(dirname "$0")" && pwd)

echo "LERNA Step 4a smoke, started $(date -Is)"
if [ -e "$WORK" ]; then
    echo "STOP: $WORK already exists; nothing was run."
    exit 2
fi
mkdir -p "$WORK/logs" "$WORK/runs" "$WORK/dryrun" || { echo "STOP: cannot create $WORK"; exit 1; }
STARTED_RUNS=0

summarize() {
    "$PY" -B "$KIT/LERNA_STEP4A_SUMMARY.py" --runs "$WORK/runs" --logs "$WORK/logs" --out "$WORK/summary" \
        > "$WORK/logs/summary_stdout.txt" 2>&1
    local rc=$?
    cat "$WORK/logs/summary_stdout.txt"
    echo "summary exit $rc"
    return $rc
}

stop() {
    echo "STOP: $*" | tee "$WORK/logs/STOPPED.txt"
    if [ "$STARTED_RUNS" -gt 0 ]; then
        summarize
    fi
    echo "LERNA Step 4a smoke stopped $(date -Is)"
    exit 1
}

export HF_HOME="$HF_CACHE_DIR" HF_HUB_CACHE="$HF_CACHE_DIR" TRANSFORMERS_CACHE="$HF_CACHE_DIR"
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
export CUDA_VISIBLE_DEVICES="" TOKENIZERS_PARALLELISM=false

# ---------------------------------------------------------------- pre-flight (read-only)
head=$(git -C "$REPO" rev-parse HEAD 2>&1)
[ "$head" = "$EXPECT_HEAD" ] || stop "git HEAD is $head, expected $EXPECT_HEAD"
porcelain=$(git -C "$REPO" status --porcelain 2>&1)
[ -z "$porcelain" ] || stop "the tree is not clean: $(echo "$porcelain" | head -5 | tr '\n' ';')"
runner_sha=$(sha256sum "$RUNNER" 2>/dev/null | cut -d' ' -f1)
[ "$runner_sha" = "$EXPECT_RUNNER" ] || stop "runner hash is ${runner_sha:-missing}, expected $EXPECT_RUNNER"
probe_sha=$(sha256sum "$PROBE" 2>/dev/null | cut -d' ' -f1)
[ "$probe_sha" = "$EXPECT_PROBE" ] || stop "probe file hash is ${probe_sha:-missing}, expected $EXPECT_PROBE"
[ -f "$PROV_SUMMARY" ] || stop "round-3 summary $PROV_SUMMARY not found"
ids_line=$(grep -E "89a8c4a7.*\]: (matches|NO MATCH)" "$PROV_SUMMARY" | head -1)
echo "round-3 line for the in-file ids_sha256: $ids_line"
echo "$ids_line" | grep -q "\]: matches" || stop "round 3 did not reproduce the in-file ids_sha256 89a8c4a7… from the IDs"
{
    echo "head $head"
    echo "runner $runner_sha"
    echo "probe $probe_sha"
    echo "ids line: $ids_line"
    "$PY" -c "import sys, torch, transformers, datasets; print('python', sys.version.split()[0], 'torch', torch.__version__, 'cuda build', torch.version.cuda, 'transformers', transformers.__version__, 'datasets', datasets.__version__, 'torch threads', torch.get_num_threads())" 2>&1 \
        || echo "version print failed"
    echo "nproc $(nproc)"
    free -g 2>/dev/null | head -2
    for v in HF_HOME HF_HUB_CACHE TRANSFORMERS_CACHE HF_HUB_OFFLINE HF_DATASETS_OFFLINE TRANSFORMERS_OFFLINE \
             HF_HUB_DISABLE_TELEMETRY CUDA_VISIBLE_DEVICES TOKENIZERS_PARALLELISM OMP_NUM_THREADS MKL_NUM_THREADS; do
        echo "$v=${!v-<unset>}"
    done
} > "$WORK/logs/preflight.txt"
cat "$WORK/logs/preflight.txt"

COMMON=(--task qnli --total-steps 400 --min-step 50 --skip-rate 0.6 --max-consecutive-skips 4 --policy-seed 0
        --model-revision "$MREV" --tokenizer-revision "$MREV" --dataset-id glue --dataset-revision "$DREV"
        --probe-exclusions-file "$PROBE" --probe-exclusions-hash "$EXPECT_PROBE")
IDS=(s4a-1-reduced s4a-2-gate s4a-3-uniform s4a-4-full)
arm_args() {
    case "$1" in
        s4a-1-reduced) echo "--arm reduced_steps" ;;
        s4a-2-gate) echo "--arm gate_s1_p1 --controller-version phase_exact_v1 --score-source s1 --n-phases 1" ;;
        s4a-3-uniform) echo "--arm control_uniform_p1 --controller-version phase_exact_v1 --score-source uniform --n-phases 1" ;;
        s4a-4-full) echo "--arm full_finetune" ;;
    esac
}
cd "$WORK" || stop "cannot enter $WORK"

# ---------------------------------------------------------------- dry runs (validation only)
for id in "${IDS[@]}"; do
    # shellcheck disable=SC2046
    "$PY" -B "$RUNNER" "${COMMON[@]}" $(arm_args "$id") --dry-run --output-dir "$WORK/dryrun" --attempt-id "$id" \
        > "$WORK/logs/dryrun_$id.json" 2> "$WORK/logs/dryrun_$id.stderr"
    rc=$?
    echo "dry run $id exit $rc"
    [ $rc -eq 0 ] || stop "dry run $id exited $rc (see logs/dryrun_$id.json)"
done

# ---------------------------------------------------------------- the four real runs
for id in "${IDS[@]}"; do
    echo "run $id started $(date -Is)"
    STARTED_RUNS=$((STARTED_RUNS + 1))
    t0=$(date +%s)
    # shellcheck disable=SC2046
    "$PY" -B "$RUNNER" "${COMMON[@]}" $(arm_args "$id") --output-dir "$WORK/runs" --attempt-id "$id" \
        > "$WORK/logs/run_$id.json" 2> "$WORK/logs/run_$id.stderr"
    rc=$?
    elapsed=$(( $(date +%s) - t0 ))
    echo "$id exit $rc elapsed $elapsed s" | tee -a "$WORK/logs/timings.txt"
    [ $rc -eq 0 ] || stop "run $id exited $rc (see logs/run_$id.json and logs/run_$id.stderr); later runs not started"
    if [ "$id" = "s4a-1-reduced" ] && [ "$elapsed" -gt "$GUARD_SECONDS" ]; then
        stop "run $id took $elapsed s, more than $GUARD_SECONDS s; the other runs were not started"
    fi
done

summarize
src=$?
echo "LERNA Step 4a smoke finished $(date -Is): 4 of 4 runs exited 0; summary exit $src"
[ $src -eq 0 ] || exit 1
exit 0

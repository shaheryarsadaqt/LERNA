#!/usr/bin/env python3
"""LERNA Step 4a: summary and checks of the bounded real-model smoke (3 November 2026). Read-only.

Reads every execution_manifest.json under --runs, checks each planned run against the
Step 4a plan, and estimates the cost of a retained and of a skipped step on this machine.

For each run it checks:
  - status, execution mode, git HEAD, clean tree and runner hash;
  - the configuration against the plan: task, pins, probe file hash, schedule and recipe;
  - the step accounting for its arm (F = forwards, B = backwards, O = optimizer updates,
    S = scheduler advances; Q = round(rate x T) skips);
  - the final learning rate, a finite evaluation, and the trainer's own invariants.

The accuracy of these short runs is not a result, and this script doesn't interpret it.
Writes summary.json and SUMMARY.txt into --out, which must not exist, and prints the AT A
GLANCE block. Exit 0 means the summary was written, whatever it found; exit 2 means bad
arguments or an existing --out.
"""
import argparse
import json
import math
import os
import re
import sys
from pathlib import Path

VERSION = "LERNA_STEP4A_SUMMARY v1 (2026-11-03)"
EXPECT = {
    "head": os.environ.get("EXPECT_HEAD", "3af68e85302a4975ef1eb2079e41066db1366520"),
    "runner": os.environ.get("EXPECT_RUNNER", "50a967ba1de3b9c0ad8e705497709e64ea852990ea2490775f5b938c79a62df8"),
}
MREV = "45d08642849e5c5701b162671ac811b7654bfd9f"
DREV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
PROBE_SHA = os.environ.get("EXPECT_PROBE", "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408")
PLAN = {
    "task": "qnli", "total_steps": 400, "min_step": 50, "target_skip_rate": 0.6, "max_consecutive_skips": 4,
    "policy_seed": 0, "model_id": "jhu-clsp/ettin-encoder-150m", "tokenizer_id": "jhu-clsp/ettin-encoder-150m",
    "model_revision": MREV, "tokenizer_revision": MREV, "dataset_id": "glue", "dataset_revision": DREV,
    "probe_exclusions_hash": PROBE_SHA, "learning_rate": 2e-05, "lr_warmup_steps": 12,
    "lr_schedule_shape": "constant_with_warmup", "train_batch_size": 32, "gradient_accumulation": 1,
    "max_length": 512, "precision": "fp32", "attention": "eager", "weight_decay": 0.01, "grad_clip": 1.0,
    "freeze_on_skips": True, "dry_run": False,
}
# attempt id, arm, recorded controller, recorded score source, phases. The config forces
# legacy_v4/uniform on the two reference arms, which use no gate.
RUNS = [
    ("s4a-1-reduced", "reduced_steps", "legacy_v4", "uniform", 1),
    ("s4a-2-gate", "gate_s1_p1", "phase_exact_v1", "s1", 1),
    ("s4a-3-uniform", "control_uniform_p1", "phase_exact_v1", "uniform", 1),
    ("s4a-4-full", "full_finetune", "legacy_v4", "uniform", 1),
]
PREREG_T, PREREG_Q = 6548, 3929


def load_manifests(runs_dir):
    found = {}
    errors = []
    for p in sorted(Path(runs_dir).rglob("execution_manifest.json")):
        try:
            m = json.loads(p.read_text())
        except Exception as e:
            errors.append(f"{p}: {type(e).__name__}: {e}")
            continue
        aid = (m.get("config") or {}).get("attempt_id")
        found.setdefault(aid, []).append((str(p), m))
    return found, errors


def close(a, b, tol=1e-12):
    try:
        return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(b)))
    except (TypeError, ValueError):
        return False


def check_run(m, arm, controller, source, phases):
    cfg, res, diag, prov = (m.get("config") or {}), (m.get("result") or {}), (m.get("diagnostics") or {}), \
        (m.get("provenance") or {})
    T = PLAN["total_steps"]
    Q = int(round(PLAN["target_skip_rate"] * T))
    K = PLAN["max_consecutive_skips"]
    C = []

    def chk(name, ok, got=None):
        C.append({"check": name, "ok": bool(ok), "got": got})

    chk("status OK", m.get("status") == "OK", m.get("status"))
    chk("production loaders, not a dry run", prov.get("execution_mode") == "production_loaders"
        and prov.get("dry_run") is False and cfg.get("dry_run") is False, [prov.get("execution_mode"), prov.get("dry_run")])
    chk("git HEAD", prov.get("resolved_code_sha") == EXPECT["head"], prov.get("resolved_code_sha"))
    chk("clean tree", prov.get("tree_status") == "clean", prov.get("tree_status"))
    chk("runner hash", prov.get("source_hash_runner") == EXPECT["runner"], prov.get("source_hash_runner"))
    for k, v in PLAN.items():
        got = cfg.get(k)
        ok = close(got, v) if isinstance(v, float) else got == v
        chk(f"config {k}", ok, got)
    chk("probe file path", str(cfg.get("probe_exclusions_file") or "").endswith("experiments/probe_indices_v4.json"),
        cfg.get("probe_exclusions_file"))
    chk("arm", cfg.get("arm") == arm and res.get("arm") == arm, cfg.get("arm"))
    chk("controller and score source as recorded", cfg.get("controller_version") == controller
        and cfg.get("score_source") == source and cfg.get("n_phases") == phases,
        [cfg.get("controller_version"), cfg.get("score_source"), cfg.get("n_phases")])
    F, B, O, S = (res.get(k) for k in ("forwards", "backwards", "optimizer_updates", "scheduler_advances"))
    eff, skipped = res.get("effective_total"), res.get("skipped")
    if arm == "full_finetune":
        chk(f"accounting F=B=O=S={T}, no skips", eff == T and F == B == O == S == T and skipped == 0, [eff, F, B, O, S, skipped])
    elif arm == "reduced_steps":
        chk(f"accounting F=B=O=S={T - Q}, no skips", eff == T - Q and F == B == O == S == T - Q and skipped == 0,
            [eff, F, B, O, S, skipped])
    else:
        chk(f"accounting F=S={T}, B=O={T - Q}, skipped={Q}", eff == T and F == S == T and B == O == T - Q
            and skipped == Q, [eff, F, B, O, S, skipped])
        chk("realized = requested skips", res.get("realized_total") == res.get("requested_total") == Q,
            [res.get("realized_total"), res.get("requested_total")])
        chk(f"longest skip run <= {K}", isinstance(res.get("longest_skip_run"), int) and res["longest_skip_run"] <= K,
            res.get("longest_skip_run"))
    chk("final LR equals the base LR (constant after warmup)", close(res.get("final_learning_rate"), PLAN["learning_rate"]),
        res.get("final_learning_rate"))
    loss, acc = res.get("final_eval_loss"), res.get("final_eval_accuracy")
    chk("evaluation ran: finite loss, accuracy in [0, 1]",
        isinstance(loss, (int, float)) and math.isfinite(loss) and isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0,
        [loss, acc])
    chk("no non-finite training loss", diag.get("nonfinite_forward_loss_count") == 0, diag.get("nonfinite_forward_loss_count"))
    chk("no policy failures, run valid", diag.get("policy_decision_failures") == 0 and diag.get("run_invalidated") is False,
        [diag.get("policy_decision_failures"), diag.get("run_invalidated")])
    inv = {k: v for k, v in diag.items() if k.startswith("invariant_")}
    chk("trainer invariants hold", bool(inv) and all(v is True for v in inv.values()), inv)
    cost = {"wall_seconds": res.get("wall_seconds"), "train_loop_seconds": diag.get("train_loop_seconds"),
            "setup_seconds": diag.get("setup_seconds"), "mean_step_time_executed": diag.get("mean_step_time_executed"),
            "mean_step_time_skipped": diag.get("mean_step_time_skipped"),
            "dataloader_wait_seconds": diag.get("dataloader_wait_seconds"), "effective_total": eff}
    if isinstance(cost["train_loop_seconds"], (int, float)) and eff:
        cost["loop_seconds_per_step"] = cost["train_loop_seconds"] / eff
    return C, cost, {"final_eval_loss": loss, "final_eval_accuracy": acc, "final_eval_f1": res.get("final_eval_f1")}


def read_timings(logs):
    out = {}
    p = Path(logs) / "timings.txt" if logs else None
    if p and p.is_file():
        for line in p.read_text().splitlines():
            m = re.match(r"(\S+) exit (\S+) elapsed (\d+) s", line)
            if m:
                out[m.group(1)] = {"exit": m.group(2), "elapsed_seconds": int(m.group(3))}
    return out


def fmt_s(x):
    return "n/a" if not isinstance(x, (int, float)) else f"{x:.3f} s"


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--runs", required=True)
    ap.add_argument("--logs", default=None)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    if out.exists():
        print(f"--out {out} already exists", file=sys.stderr)
        return 2
    if not Path(a.runs).is_dir():
        print(f"--runs {a.runs} is not a folder", file=sys.stderr)
        return 2
    found, errors = load_manifests(a.runs)
    timings = read_timings(a.logs)
    rep = {"version": VERSION, "expect": EXPECT, "plan": PLAN, "manifest_errors": errors, "runs": {},
           "unplanned_manifests": sorted(str(k) for k in found if k not in {r[0] for r in RUNS})}
    for aid, arm, ctl, src, ph in RUNS:
        items = found.get(aid, [])
        entry = {"arm": arm, "manifests": [p for p, _ in items], "timing_log": timings.get(aid)}
        if len(items) != 1:
            entry["state"] = "MISSING" if not items else "DUPLICATE"
        else:
            checks, cost, ev = check_run(items[0][1], arm, ctl, src, ph)
            entry.update({"state": "CHECKED", "checks": checks, "cost": cost, "evaluation_not_a_result": ev,
                          "checks_passed": sum(c["ok"] for c in checks), "checks_total": len(checks)})
        rep["runs"][aid] = entry
    R = rep["runs"]

    def get(aid, k):
        return ((R.get(aid) or {}).get("cost") or {}).get(k)
    ret = {aid: get(aid, "mean_step_time_executed") for aid, *_ in RUNS}
    skp = {aid: get(aid, "mean_step_time_skipped") for aid, *_ in RUNS if aid in ("s4a-2-gate", "s4a-3-uniform")}
    proj = {}
    T = PLAN["total_steps"]
    Q = int(round(PLAN["target_skip_rate"] * T))
    for aid, arm, *_ in RUNS:
        per = get(aid, "loop_seconds_per_step")
        if isinstance(per, (int, float)):
            n = PREREG_T - PREREG_Q if arm == "reduced_steps" else PREREG_T
            proj[aid] = {"steps_at_prereg_length": n, "train_loop_hours": per * n / 3600}
    rep["cost"] = {"retained_step_seconds": ret, "skipped_step_seconds": skp, "projection_prereg_length": proj,
                   "note": ("Projection of the training loop only, at the preregistered length (6548 steps, 3929 "
                            "skips; reduced 2619 steps). The smoke's skip share (240 of 400) equals the "
                            "preregistered one, so the per-step averages carry over. Setup, tokenisation and "
                            "evaluation come on top; the process times are in timing_log.")}
    n_ok = sum(e.get("checks_passed", 0) for e in R.values())
    n_all = sum(e.get("checks_total", 0) for e in R.values())
    states = [e["state"] for e in R.values()]
    rep["verdict"] = ("ALL CHECKS PASSED" if all(s == "CHECKED" for s in states) and n_ok == n_all and not errors
                      else "NOT ALL CHECKS PASSED")
    L = [f"AT A GLANCE ({VERSION})",
         f" Verdict: {rep['verdict']}: {sum(s == 'CHECKED' for s in states)} of {len(RUNS)} planned runs found; "
         f"checks passed {n_ok} of {n_all}"]
    for aid, arm, *_ in RUNS:
        e = R[aid]
        if e["state"] != "CHECKED":
            L.append(f" {aid:15s} {arm:19s} {e['state']}")
            continue
        m = [c for c in e["checks"] if c["check"].startswith("accounting")][0]["got"]
        c = e["cost"]
        tl = e.get("timing_log") or {}
        L.append(f" {aid:15s} {arm:19s} checks {e['checks_passed']}/{e['checks_total']}  eff/F/B/O/S/skipped "
                 f"{'/'.join(str(x) for x in m)}  loop {fmt_s(c.get('train_loop_seconds'))}  "
                 f"process {tl.get('elapsed_seconds', 'n/a')} s")
    L.append(" Retained step (mean, s): " + ", ".join(f"{k} {fmt_s(v)}" for k, v in ret.items()))
    L.append(" Skipped step (mean, s): " + ", ".join(f"{k} {fmt_s(v)}" for k, v in skp.items()))
    L.append(" Projected training loop at the preregistered length (hours): "
             + ", ".join(f"{k} {v['train_loop_hours']:.2f}" for k, v in proj.items()))
    bad = [(aid, c["check"], c["got"]) for aid, e in R.items() for c in e.get("checks", []) if not c["ok"]]
    if bad:
        L.append(" Failed checks:")
        L += [f"   {aid}: {name}: got {str(got)[:160]}" for aid, name, got in bad[:40]]
    if errors:
        L.append(f" Unreadable manifests: {len(errors)}")
    if rep["unplanned_manifests"]:
        L.append(f" Manifests outside the plan: {rep['unplanned_manifests']}")
    L.append(" Accuracy of these short runs is not a result; see summary.json for the values.")
    out.mkdir(parents=True)
    (out / "summary.json").write_text(json.dumps(rep, indent=1, default=str))
    (out / "SUMMARY.txt").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())

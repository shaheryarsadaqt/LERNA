# LERNA round 19: a confirmatory test on the dense LLMs (10 November 2026)

**Fixed before any run.** This plan, the launcher and the checker are fixed on 10 Nov 2026, before round 19 starts. Its results are reported whatever they are, beside round 18's, which stay exactly as reported.

## 1. Why this round

In round 18 (three causal LLMs, three seeds), the per-model results at 35% of full fine-tuning's compute pointed one way. Training every step on a sampled batch was ahead of plain training on 35% of the steps:
- LERNA v2: +2.34 on Llama, +1.08 on Qwen;
- random keep (LERNA v2's controller with uniform choice): +2.35 and +2.30.

On the two dense models together (12 pairs), LERNA v2's mean difference was +1.71 (SD 4.00) and random keep's +2.33 (SD 4.76). With three seeds the round couldn't tell either from noise. That reading was exploratory and isn't a finding.

This round tests it once, on 15 new seeds, with the tests fixed here.

## 2. Design

| Item | Setting |
|---|---|
| Models | Llama-3.2-1B (`alpindale/Llama-3.2-1B` @ `b6fd66fb…`) and Qwen3-0.6B-Base (@ `da87bfb6…`), round 18's pins and files. Granite is left out: in round 18 it learned RTE near chance (full fine-tuning 61.13% against a majority rate of 52.71%), so its comparisons there are noise |
| Tasks | MRPC and RTE (GLUE @ `bcdcba79…`); validation accuracy, as in every round |
| Methods, all at 35% of full fine-tuning's compute | LERNA v2 (`lerna2_nolr_b035`); random keep, LERNA v2's controller with uniform scores (`randkeep_b035`); plain training on 35% of the steps with its own shortened schedule (`plain_035`) |
| Seeds | 19, 23, 29, 31, 37, 41, 43, 59, 61, 67, 71, 73, 79, 83, 89 (15; none used in round 18) |
| Recipe | Round 18's, unchanged: code commit `c68f302e…` with no change; T = 345 (MRPC) and 234 (RTE), batch 32, length 512, AdamW, learning rate 1e-5 (round 18's pilot rule chose it for both models; no new pilot), warmup 6%, FP32, eager attention, gradient checkpointing, one V100 per run |
| Runs | 2 models × 2 tasks × 3 methods × 15 seeds = 180; a smoke gate first (MRPC, seed 19, 6 runs) |
| Expected time | about 1.7 hours on the 8 V100s, from round 18's run times |

## 3. Checks (as in round 18)

Every run is checked: exit status, config, seed, learning rate, model and revision, exact counts, final learning rate 0, runtime and batch log. Budgets must be within 0.005, measured from each run's batch log against its seed's full schedule, and equal to the fraction the run reported. In each seed, random keep must train on LERNA v2's scheduled batches, row for row, and plain training on their first 35%. The 15 seeds must give 15 different batch orders. The reviewer recomputes everything independently from the raw run files.

## 4. The primary test (fixed now)

Two contrasts, each over 60 paired differences (2 models × 2 tasks × 15 seeds, paired by model, task and seed):
- **P1:** LERNA v2 at 35% minus plain training at 35%;
- **P2:** random keep at 35% minus plain training at 35%.

Each is a two-sided t-test of the mean difference against 0, with Holm's adjustment over the two. Reading: **EDGE** if the Holm-adjusted p < 0.05 and the mean > 0; **LOSS** if p < 0.05 and the mean < 0; otherwise no significant difference.

**Secondary, descriptive and unadjusted:**
- LERNA v2 minus random keep;
- each contrast per model (30 pairs) and per model and task (15 pairs);
- MRPC F1, compute, and wall-clock time relative to plain training.

**Not done:** no pooling with round 18's seeds, no further seeds, no other models, budgets or methods, and no change to the tests after the results are seen.

**Power:** with round 18's SD of the differences (4.0 to 4.8 points), 60 pairs detect a true difference of 1.0 point about 36–48% of the time, 1.5 points 66–82%, and 2.0 points 89–97% (two-sided paired t-test, α = 0.05, before Holm's adjustment).

## 5. Predictions (fixed now)

| Contrast | Predicted |
|---|---|
| P2, random keep vs plain 35% | EDGE likely (about 75%) |
| P1, LERNA v2 vs plain 35% | EDGE possible (about 50%) |
| LERNA v2 vs random keep | no significant difference (the scores didn't matter in any round) |
| Budgets | every LERNA v2 and random keep run within 0.005 (round 18: 0.0005) |

## 6. What the thesis may say, by outcome

- **P1 EDGE:** "In a confirmatory round with 15 new seeds on the two dense LLMs, LERNA v2 at 35% of full fine-tuning's compute beat plain training on 35% of the steps by X points (Holm p = …)."
- **P2 EDGE, P1 not:** "LERNA v2's exact-budget sampling, with uniform choice, beat plain shorter training; with its residual scores, LERNA v2 did not reach significance." This agrees with every earlier ablation, where the scores added nothing.
- **Neither:** "With five times as many seeds, neither sampling method beat plain shorter training on the dense LLMs." Round 18's conclusion then stands with stronger evidence.
- **In every case:**
  - round 18's results stay as reported;
  - round 19 is described as a follow-up that round 18's exploratory pattern prompted, with its design fixed before it ran;
  - it says nothing about Granite, InfoBatch, full fine-tuning or other budgets.

## 7. Files

The kit, `LERNA_R19_KIT_2026-11-10.zip`, holds this plan and the two scripts, so the plan's SHA-256 is printed on the server before any run.
- `LERNA_R19_LAUNCH.py`: the launcher. It reuses round 18's code, models, pins and `MODEL_CHECK_v2.json` (read only) and writes only into its own new folder.
- `LERNA_R19_CHECK.py`: the checker and the tables above.
- `LERNA_R19_CLI_PROMPT_2026-11-10.md`: the server steps.

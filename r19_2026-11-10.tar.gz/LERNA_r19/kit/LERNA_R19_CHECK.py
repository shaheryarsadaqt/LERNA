#!/usr/bin/env python3
"""LERNA round 19: checks and the pre-specified tables of the confirmatory follow-up on the dense LLMs
(10 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, SMOKE_GATE.json, DONE.json, runs/), round
18's two MODEL_PIN files and MODEL_CHECK_v2.json. It writes only check_report.json, CHECK_SUMMARY.txt,
FINAL_TABLE.csv and MAIN_TABLE.csv into the launcher's folder. Exit 0 means the report was written;
the verdict is inside it. Exit 2 means the folder isn't a finished launch.

Per run (the 180 runs: Llama-3.2-1B and Qwen3-0.6B-Base x MRPC and RTE x LERNA v2 at 35%, random keep
at 35% and plain training on 35% of the steps x 15 seeds), round 18's checks, unchanged:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, the learning rate (1e-5),
    the model and its pinned revision for weights and tokenizer, the dataset revision, device, and
    each method's own options;
  - the exact counts and a final LR of 0;
  - the runtime block: interpreter, versions, GPU, the parameter count of the model check, no
    LayerNorm biases, eager attention, FP32, gradient checkpointing, the round-18 classifier and the
    model's type, AdamW betas and eps, the pinned GPU;
  - the batch log and each method's own accounting against it (LERNA v2 and random keep: the budget
    spent within 0.005, no example dropped in the warmup).
And for the round: the plan is the fixed one, each run started once, the smoke gate passed on its six
runs, DONE.json reports every run with exit 0; in each seed, random keep trained on LERNA v2's
scheduled batches row for row and plain training on their first rows; the 15 seeds give 15 batch
orders; each LERNA v2 and random-keep run's compute, measured from its batch log against its seed's
full schedule, is its budget within 0.005 and equals the fraction the run reported.

Then the reading fixed in claude/LERNA_R19_CONFIRM_PLAN_2026-11-10.md:
  THE TABLE: each method, MRPC and RTE accuracy on each model (mean and sd over the seeds), the means,
    and the measured compute (relative to full fine-tuning's: 3 units per scheduled padded token);
  THE PRIMARY TEST: P1 LERNA v2 minus plain training and P2 random keep minus plain training, each over
    the 60 paired differences (2 models x 2 tasks x 15 seeds, paired by seed), a two-sided t-test, Holm
    over the two; EDGE / LOSS / no significant difference;
  secondary, unadjusted: LERNA v2 minus random keep; per model (30 pairs) and per model and task (15);
  budget exactness, compute and wall-clock time relative to plain training.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R19_CHECK 2026-11-10"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "attn_implementation": "eager",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "implementation_sha256": "ae722af37ffa5d73053736ee6c14d57802adbad600613ed52e846088a68cbe98",
    "repo_head": "c68f302e11ebca1ab96f368a5618c50d91c48d76",
}
MODELS = {"llama": "alpindale/Llama-3.2-1B", "qwen": "Qwen/Qwen3-0.6B-Base"}
MODEL_NAME = {"llama": "Llama-3.2-1B", "qwen": "Qwen3-0.6B-Base"}
MODEL_TYPE = {"llama": "llama", "qwen": "qwen3"}
SEEDS = (19, 23, 29, 31, 37, 41, 43, 59, 61, 67, 71, 73, 79, 83, 89)
LEARNING_RATE = 1e-5
TASKS = ("mrpc", "rte")
TASK_NAME = {"mrpc": "MRPC", "rte": "RTE"}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"mrpc": 3668, "rte": 2490}
BATCH_SIZE = 32
HORIZON = {"mrpc": 345, "rte": 234}
RATE = 0.60
LABELS = ("plain_035", "lerna2_nolr_b035", "randkeep_b035")
LERNA2 = {"lerna2_nolr_b035": (0.35, True, False), "randkeep_b035": (0.35, False, False)}
LERNA2_OPTIONS = {"lerna2_pi_min": 0.1, "lerna2_window": 64, "lerna2_chunks": 16}
SELECTION_ARMS = tuple(LERNA2)
GATES = ()
ARM_SPEC = {a: ("uniform", "legacy_v4", 1) for a in LABELS}
BUDGET_TOLERANCE = 0.005
LABEL = {"plain_035": "Plain training, 35% of steps", "lerna2_nolr_b035": "LERNA v2, 35%",
         "randkeep_b035": "Random keep, 35% (LERNA v2, uniform)"}
FINAL_ROWS = ["lerna2_nolr_b035", "randkeep_b035", "plain_035"]
REFERENCE = "lerna2_nolr_b035"  # its scheduled batches are its seed's full schedule
PRIMARY = [("P1_lerna2_vs_plain_35", "lerna2_nolr_b035", "plain_035"),
           ("P2_randkeep_vs_plain_35", "randkeep_b035", "plain_035")]
SECONDARY = [("S1_lerna2_vs_randkeep_35", "lerna2_nolr_b035", "randkeep_b035")]


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm == "plain_035":
        eff, skips = int(round(0.35 * T)), 0
    elif arm in GATES:
        eff, skips = T, q
    else:
        eff, skips = T, 0
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def _betacf(a, b, x):
    tiny, eps = 1e-300, 1e-15
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def betainc(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x)
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbeta) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbeta) * _betacf(b, a, 1.0 - x) / b


def t_two_sided_p(t, df):
    return betainc(df / 2.0, 0.5, df / (df + t * t))


def t975(df):
    """The 97.5% quantile of Student's t with df degrees of freedom (bisection on the p-value)."""
    lo, hi = 0.0, 100.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if t_two_sided_p(mid, df) > 0.05:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def holm(pvals):
    idx = [i for i, p in enumerate(pvals) if isinstance(p, (int, float))]
    order = sorted(idx, key=lambda i: pvals[i])
    m = len(order)
    adj = [None] * len(pvals)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * pvals[i]))
        adj[i] = running
    return adj


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def summarize(values):
    """values: {unit: difference}. Mean, sd, the t-test against 0 and its 95% interval."""
    vals = [g for g in values.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0),
           "negative": sum(1 for g in vals if g < 0), "by_unit": values}
    if n >= 2 and sd is not None:
        half = t975(n - 1) * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
        if sd > 0:
            out["p"] = t_two_sided_p(m / (sd / math.sqrt(n)), n - 1)
        else:
            out["p"] = 1.0 if m == 0 else 0.0
    return out


def read_out(d, pa):
    if d["n"] < 3 or pa is None:
        return "too few pairs"
    if pa < 0.05 and d["mean"] > 0:
        return "EDGE"
    if pa < 0.05 and d["mean"] < 0:
        return "LOSS"
    return "no significant difference"


def check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts):
    """LERNA v2, random keep and InfoBatch: each method's own accounting against its batch log."""
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    W = exp["warmup"]
    sched_tokens = sum(int(x[8]) for x in rows) if rows else None
    sched_examples = sum(int(x[7]) for x in rows) if rows else None
    if arm in LERNA2:
        budget, scores, lr = LERNA2[arm]
        for k, want in (("policy", "lerna_budget"), ("selection", "sample"), ("budget", budget),
                        ("use_scores", scores), ("use_lr_weight", lr), ("pi_min", 0.1), ("window", 64),
                        ("chunks", 16), ("warmup_steps", W), ("total_steps", T), ("steps_seen", T),
                        ("batches_per_epoch", bpe), ("num_examples", n_train), ("pruned_examples", dropped),
                        ("pruned_during_warmup", 0)):
            need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
        rf = sel.get("realized_fraction")
        need(isinstance(rf, (int, float)) and abs(rf - budget) <= BUDGET_TOLERANCE,
             f"spent {rf} of the scheduled compute, budget {budget} +/- {BUDGET_TOLERANCE}")
        need(dropped > 0, "no example dropped")
        if rows:
            need(sel.get("spent_units") == units_of(rows), "policy spent units differ from the batch log")
            need(sel.get("scheduled_units") == 3 * sched_tokens, "policy scheduled units differ from the batch log")
            need(sel.get("scheduled_examples") == sched_examples, "policy scheduled examples differ from the batch log")
        need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
             "kept + pruned differ from the scheduled examples")
        mw = sel.get("max_weight")
        need(isinstance(mw, (int, float)) and mw <= 10.0 + 1e-9, f"max_weight={mw}")
        facts["realized_fraction"] = rf
    elif arm == "infobatch":
        need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
        need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
        need(sel.get("stop_prune_step") == int(math.floor(0.875 * T + 1e-9)), "stop_prune_step differs")
        need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
        need(len(sel.get("thresholds") or []) == math.ceil(T / bpe), "one threshold per epoch expected")
        need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
        need(dropped > 0, "no example dropped in a run longer than one epoch")


def check_run(p, end, out, rev, lr, parameters, source):
    name, model, task, arm, seed = p["name"], p["model"], p["task"], p["arm"], p["seed"]
    label = p.get("label", arm)
    T = p["total_steps"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "model": model, "task": task, "arm": arm, "label": label, "seed": seed, "total_steps": T,
            "learning_rate": lr, "source": source}
    need(T == HORIZON.get(task), f"total_steps {T} for {task}")
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, T)
    eff = exp["effective_total"]
    mid = MODELS[model]
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", T),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_id", mid), ("tokenizer_id", mid),
                 ("model_revision", rev), ("tokenizer_revision", rev), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False), ("train_batch_size", BATCH_SIZE),
                 ("learning_rate", lr), ("weight_decay", 0.01), ("grad_clip", 1.0), ("probe_exclusions_hash", None),
                 ("max_length", 512), ("target_skip_rate", RATE)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    need(r.get("learning_rate") == lr, f"result learning_rate={r.get('learning_rate')}, expected {lr}")
    need(p["min_step"] == int(math.floor(0.06 * T + 1e-9)), f"min_step {p['min_step']} is not the warmup of {T}")
    if arm in LERNA2:
        for k, v in LERNA2_OPTIONS.items():
            need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        need((c.get("infobatch_prune_ratio"), c.get("infobatch_anneal_fraction")) == (0.5, 0.875),
             f"InfoBatch options {c.get('infobatch_prune_ratio')}, {c.get('infobatch_anneal_fraction')}")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == eff - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == eff, f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm not in SELECTION_ARMS:
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    if task == "mrpc":
        need(isinstance(r.get("final_eval_f1"), (int, float)), "MRPC F1 missing")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    need(rt.get("model_dtype") == "torch.float32", f"model_dtype {rt.get('model_dtype')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(rt.get("parameters") == parameters, f"parameters={rt.get('parameters')}, the model check recorded {parameters}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    need(rt.get("gradient_checkpointing") is True, f"gradient_checkpointing={rt.get('gradient_checkpointing')}")
    need(rt.get("model_class") == "CausalLMForSequenceClassification", f"model_class={rt.get('model_class')}")
    need(rt.get("model_type") == MODEL_TYPE[model], f"model_type={rt.get('model_type')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("class") == "AdamW", f"optimizer {opt.get('class')}")
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    need(opt.get("initial_lr") == lr, f"optimizer initial_lr={opt.get('initial_lr')}, expected {lr}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if not ok_shape:
            rows = []
        if rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            need(all(int(x[6]) == 1 for x in rows), "a row without a forward pass")
            need(all(math.isfinite(float(x[5])) for x in rows), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) <= int(x[8]) for x in rows),
                 "real tokens must be positive and at most the padded, and those at most the scheduled")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm not in SELECTION_ARMS:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            if arm in LERNA2:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows[:exp["warmup"]]), "an example dropped during the warmup")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    if arm in SELECTION_ARMS:
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            check_selection(arm, label, sel, rows, dropped, T, exp, task, need, facts)
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    units = units_of(rows) if rows else None
    facts.update(accuracy=acc, loss=loss, f1=r.get("final_eval_f1"), wall_seconds=r.get("wall_seconds"),
                 examples_dropped=dropped, units=units)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True, help="the launcher's folder")
    ap.add_argument("--model-pins", nargs=2, required=True, help="round 18's MODEL_PIN.llama.json and MODEL_PIN.qwen.json")
    ap.add_argument("--model-check", required=True, help="round 18's MODEL_CHECK_v2.json")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECT[k] = v if v != "" else None
    out = Path(a.out).resolve()
    if not all((out / f).is_file() for f in ("plan.json", "ledger.jsonl", "DONE.json")):
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    meta = json.loads((out / "plan.json").read_text())
    mc = json.loads(Path(a.model_check).read_text())
    integrity_fails, notes = [], []
    pins, revs, parameters = {}, {}, {}
    by_id = {v: k for k, v in MODELS.items()}
    for pf in a.model_pins:
        pin = json.loads(Path(pf).read_text())
        key = by_id.get(pin.get("repo_id"))
        if key is None or key in pins:
            integrity_fails.append(f"{pf} names {pin.get('repo_id')}")
            continue
        pins[key], revs[key] = pin, pin.get("revision")
        rec = (mc.get("models") or {}).get(MODELS[key]) or {}
        if rec.get("revision") != revs[key] or (meta.get("model_revisions") or {}).get(key) != revs[key]:
            integrity_fails.append(f"{MODELS[key]}: revisions differ: pin {revs[key]}, check {rec.get('revision')}, "
                                   f"plan {(meta.get('model_revisions') or {}).get(key)}")
        if rec.get("pin_sha256") != sha256_file(pf):
            integrity_fails.append(f"{MODELS[key]}: the model check read another pin")
        if (meta.get("model_pins") or {}).get(key) != pin:
            integrity_fails.append(f"{MODELS[key]}: the plan's copy of the pin differs from --model-pins")
        parameters[key] = (rec.get("parameters") or {}).get("total")
        if (meta.get("parameters") or {}).get(key) != parameters[key]:
            integrity_fails.append(f"{MODELS[key]}: parameter counts differ between the plan and the model check")
        if key == "llama":
            st = (pin.get("reference") or {}).get("status")
            if st != "identical":
                notes.append(f"the Llama copy's comparison with Meta's listing: {st}")
    if set(pins) != set(MODELS):
        integrity_fails.append(f"pins for {sorted(pins)}, expected {sorted(MODELS)}")
        print("; ".join(integrity_fails), file=sys.stderr)
        return 2
    if mc.get("pass") is not True:
        integrity_fails.append("the model check did not pass")
    if EXPECT["implementation_sha256"] and mc.get("implementation_sha256") != EXPECT["implementation_sha256"]:
        integrity_fails.append("the model check checked another lerna/utils/causal_lm_classifier.py")
    if meta.get("model_check_sha256") != sha256_file(a.model_check):
        integrity_fails.append("--model-check differs from the model check the launch read")
    # the fixed settings of the round
    if meta.get("learning_rates") != {m: LEARNING_RATE for m in MODELS}:
        integrity_fails.append(f"plan.json learning rates {meta.get('learning_rates')}, expected {LEARNING_RATE} for both models")
    if meta.get("seeds") != list(SEEDS):
        integrity_fails.append(f"plan.json seeds {meta.get('seeds')}, expected {list(SEEDS)}")
    if meta.get("repo_head") != EXPECT["repo_head"]:
        integrity_fails.append(f"the launch ran on {meta.get('repo_head')}, expected round 18's commit {EXPECT['repo_head']}")
    ends, starts = {}, {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
        elif e.get("event") == "start":
            starts[e["name"]] = starts.get(e["name"], 0) + 1
    want = {(m, t, lab, s) for m in MODELS for t in TASKS for lab in LABELS for s in SEEDS}
    have = [(p["model"], p["task"], p.get("label", p["arm"]), p["seed"]) for p in meta["plan"]]
    if len(have) != len(set(have)) or set(have) != want:
        integrity_fails.append(f"the plan differs from the fixed plan ({len(set(have) ^ want)} entries differ)")
    for p in meta["plan"]:
        spec = ARM_SPEC.get(p["arm"])
        if spec is None or (p["score_source"], p["controller"], p["n_phases"]) != spec or p.get("extra"):
            integrity_fails.append(f"{p['name']}: the plan's method settings differ")
        if starts.get(p["name"], 0) != 1:
            integrity_fails.append(f"{p['name']}: started {starts.get(p['name'], 0)} times")
    extra_runs = sorted(set(starts) - {p["name"] for p in meta["plan"]})
    if extra_runs:
        integrity_fails.append(f"runs outside the plan in the ledger: {extra_runs[:5]}")
    gate = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
    smoke = {f"{m}_mrpc_{lab}_seed{SEEDS[0]}" for m in MODELS for lab in LABELS}
    if gate is None or not gate.get("pass") or set((gate.get("runs") or {})) != smoke:
        integrity_fails.append("the smoke gate did not pass on its six runs" if gate else "SMOKE_GATE.json missing")
    done = json.loads((out / "DONE.json").read_text())
    if done.get("runs") != len(meta["plan"]) or done.get("exit_zero") != len(meta["plan"]) or done.get("failed") \
            or done.get("held_back_interrupted") or done.get("smoke_gate_pass") is not True:
        integrity_fails.append(f"DONE.json: {done.get('runs')} runs, {done.get('exit_zero')} exit 0, failed "
                               f"{done.get('failed')}, held back {done.get('held_back_interrupted')}")
    runs = [check_run(p, ends.get(p["name"]), out, revs[p["model"]], LEARNING_RATE, parameters[p["model"]],
                      "round 19") for p in meta["plan"]]
    for x in runs:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    table = {(x["model"], x["task"], x["label"], x["seed"]): x for x in runs}
    # in each seed, random keep trained on LERNA v2's scheduled batches, and plain training on their first 35%
    same_batches = {}
    for x in runs:
        if x["label"] == REFERENCE or not x.get("log_rows"):
            continue
        ref = table.get((x["model"], x["task"], REFERENCE, x["seed"]))
        rrows = [(int(r_[7]), int(r_[8])) for r_ in (ref or {}).get("log_rows") or []]
        mine = [(int(r_[7]), int(r_[8])) for r_ in x["log_rows"]]
        same = bool(rrows) and len(mine) <= len(rrows) and rrows[:len(mine)] == mine
        if x["label"] == "randkeep_b035":
            same = same and len(mine) == len(rrows)
        same_batches[x["name"]] = same
        if not same:
            integrity_fails.append(f"{x['name']}: scheduled batches differ from LERNA v2's in the same seed")
    # every seed has its own batch order
    for m in MODELS:
        for t in TASKS:
            orders = [tuple((int(r_[7]), int(r_[8])) for r_ in (table.get((m, t, REFERENCE, s)) or {}).get("log_rows") or [])
                      for s in SEEDS]
            if any(not o for o in orders) or len(set(orders)) != len(SEEDS):
                integrity_fails.append(f"{m}/{t}: the {len(SEEDS)} seeds don't give {len(SEEDS)} different batch orders")
    # measured compute: relative to full fine-tuning's, i.e. 3 units per scheduled padded token of the seed's full
    # schedule (LERNA v2's scheduled batches)
    for key, x in table.items():
        ref = table.get((key[0], key[1], REFERENCE, key[3]))
        full_units = 3 * sum(int(r_[8]) for r_ in ref["log_rows"]) if (ref and ref.get("log_rows")) else None
        u = x["facts"].get("units")
        x["facts"]["compute"] = (u / full_units) if (u and full_units) else None
    # the budget measured from the batch logs: each sampling run spent its budget of its seed's full schedule, and
    # the fraction it reported is the one its log shows
    for key, x in table.items():
        if x["label"] in LERNA2 and x["ok"]:
            c_, rf, b_ = x["facts"].get("compute"), x["facts"].get("realized_fraction"), LERNA2[x["label"]][0]
            if not isinstance(c_, (int, float)) or abs(c_ - b_) > BUDGET_TOLERANCE \
                    or not isinstance(rf, (int, float)) or abs(c_ - rf) > 1e-9:
                integrity_fails.append(f"{x['name']}: compute from the batch log {c_}, reported {rf}, budget {b_}")

    def acc(m, t, lab, s):
        x = table.get((m, t, lab, s))
        return 100.0 * x["facts"]["accuracy"] if x and x["ok"] else None

    cells = {}
    for m in MODELS:
        for t in TASKS:
            plain_wall = mean_sd([(table.get((m, t, "plain_035", s)) or {}).get("facts", {}).get("wall_seconds")
                                  for s in SEEDS])[0]
            methods = {}
            for lab in LABELS:
                ok = [x for x in (table.get((m, t, lab, s)) for s in SEEDS) if x and x["ok"]]
                accs_l = [100.0 * x["facts"]["accuracy"] for x in ok]
                f1s = [100.0 * x["facts"]["f1"] for x in ok if isinstance(x["facts"].get("f1"), (int, float))]
                cs = [x["facts"].get("compute") for x in ok]
                mw = mean_sd([x["facts"].get("wall_seconds") for x in ok])[0]
                rfs = [x["facts"].get("realized_fraction") for x in ok if x["facts"].get("realized_fraction") is not None]
                methods[lab] = {"n_runs": len(ok), "mean_accuracy": mean_sd(accs_l)[0], "sd_accuracy": mean_sd(accs_l)[1],
                                "accuracy_by_seed": {s: acc(m, t, lab, s) for s in SEEDS},
                                "mean_f1": mean_sd(f1s)[0], "mean_compute": mean_sd(cs)[0],
                                "min_compute": min([c_ for c_ in cs if isinstance(c_, (int, float))], default=None),
                                "max_compute": max([c_ for c_ in cs if isinstance(c_, (int, float))], default=None),
                                "mean_wall_seconds": mw,
                                "wall_vs_plain": (mw / plain_wall) if (plain_wall and mw) else None,
                                "max_budget_deviation": max([abs(v_ - LERNA2[lab][0]) for v_ in rfs], default=None)
                                if lab in LERNA2 else None}
            cells[(m, t)] = methods

    def contrast(units_keys, la, lb):
        vals = {}
        for (m, t, s) in units_keys:
            va, vb = acc(m, t, la, s), acc(m, t, lb, s)
            if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                vals[f"{m}/{t}/{s}"] = va - vb
        return summarize(vals)

    def unadjusted(d):
        return ("EDGE" if d.get("p", 1) < 0.05 and d["mean"] > 0 else
                "LOSS" if d.get("p", 1) < 0.05 and d["mean"] < 0 else "no significant difference")

    all_units = [(m, t, s) for m in MODELS for t in TASKS for s in SEEDS]
    primary = []
    for key, la, lb in PRIMARY:
        d = contrast(all_units, la, lb)
        d.update(key=key, method=la, compared=lb)
        primary.append(d)
    for r_, pa in zip(primary, holm([r_.get("p") for r_ in primary])):
        r_["p_holm"] = pa
        r_["reading"] = read_out(r_, pa)
    secondary = []
    for key, la, lb in SECONDARY:
        d = contrast(all_units, la, lb)
        d.update(key=key, method=la, compared=lb, reading_unadjusted=unadjusted(d))
        secondary.append(d)
    per_model = {}
    for m in MODELS:
        per_model[m] = []
        for key, la, lb in PRIMARY + SECONDARY:
            d = contrast([(m, t, s) for t in TASKS for s in SEEDS], la, lb)
            d.update(key=key, method=la, compared=lb, reading_unadjusted=unadjusted(d))
            per_model[m].append(d)
    per_cell = {}
    for m in MODELS:
        for t in TASKS:
            per_cell[f"{m}/{t}"] = []
            for key, la, lb in PRIMARY + SECONDARY:
                d = contrast([(m, t, s) for s in SEEDS], la, lb)
                d.update(key=key, method=la, compared=lb, reading_unadjusted=unadjusted(d))
                per_cell[f"{m}/{t}"].append(d)
    final_table = []
    for lab in FINAL_ROWS:
        row = {"row": lab, "name": LABEL[lab], "models": {}}
        comps, overall = [], []
        for m in MODELS:
            row["models"][m] = {}
            means = []
            for t in TASKS:
                d = cells[(m, t)][lab]
                row["models"][m][t] = {"mean": d["mean_accuracy"], "sd": d["sd_accuracy"], "n": d["n_runs"],
                                       "f1": d["mean_f1"], "compute": d["mean_compute"]}
                means.append(d["mean_accuracy"])
                comps.append(d["mean_compute"])
            ok_means = [v_ for v_ in means if isinstance(v_, (int, float))]
            row["models"][m]["mean"] = sum(ok_means) / len(ok_means) if len(ok_means) == len(TASKS) else None
            overall.append(row["models"][m]["mean"])
        row["mean_over_models"] = (sum(overall) / len(overall)) if all(isinstance(v_, (int, float)) for v_ in overall) else None
        row["mean_compute"] = mean_sd(comps)[0]
        final_table.append(row)
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails, "notes": notes,
              "models": {m: {"id": MODELS[m], "revision": revs[m], "parameters": parameters[m],
                             "reference": pins[m].get("reference")} for m in MODELS},
              "model_check_pass": mc.get("pass"), "learning_rate": LEARNING_RATE, "seeds": list(SEEDS),
              "smoke_gate": gate, "done": done, "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "same_scheduled_batches": same_batches, "final_table": final_table, "primary": primary,
              "secondary": secondary, "per_model": per_model, "per_model_task": per_cell,
              "cells": {f"{m}/{t}": v_ for (m, t), v_ in cells.items()},
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    def ci_text(d):
        ci = d.get("ci95")
        return f"[{num(ci[0] if ci else None, '+.2f')}, {num(ci[1] if ci else None, '+.2f')}]"

    with open(out / "FINAL_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        head = ["method", "arm", "compute"]
        for m in MODELS:
            head += [f"{MODEL_NAME[m]} {TASK_NAME[t]}" for t in TASKS] + [f"{MODEL_NAME[m]} sd {TASK_NAME[t]}" for t in TASKS]
            head += [f"{MODEL_NAME[m]} mean"]
        w.writerow(head + ["mean over models"])
        for r_ in final_table:
            row = [r_["name"], r_["row"], num(r_["mean_compute"], ".3f")]
            for m in MODELS:
                row += [num(r_["models"][m][t]["mean"], ".2f") for t in TASKS]
                row += [num(r_["models"][m][t]["sd"], ".2f") for t in TASKS]
                row += [num(r_["models"][m]["mean"], ".2f")]
            w.writerow(row + [num(r_["mean_over_models"], ".2f")])
    with open(out / "MAIN_TABLE.csv", "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["scope", "contrast", "method", "compared", "n", "mean difference", "sd", "ci95 low", "ci95 high",
                    "p", "p (Holm)", "reading"])
        for r_ in primary:
            ci = r_.get("ci95") or [None, None]
            w.writerow(["pooled (primary)", r_["key"], r_["method"], r_["compared"], r_["n"], num(r_["mean"], ".3f"),
                        num(r_["sd"], ".3f"), num(ci[0], ".3f"), num(ci[1], ".3f"), num(r_.get("p"), ".4f"),
                        num(r_.get("p_holm"), ".4f"), r_["reading"]])
        for r_ in secondary:
            ci = r_.get("ci95") or [None, None]
            w.writerow(["pooled (secondary)", r_["key"], r_["method"], r_["compared"], r_["n"], num(r_["mean"], ".3f"),
                        num(r_["sd"], ".3f"), num(ci[0], ".3f"), num(ci[1], ".3f"), num(r_.get("p"), ".4f"), "",
                        r_["reading_unadjusted"] + " (unadjusted)"])
        for m, rows_m in per_model.items():
            for r_ in rows_m:
                ci = r_.get("ci95") or [None, None]
                w.writerow([MODEL_NAME[m], r_["key"], r_["method"], r_["compared"], r_["n"], num(r_["mean"], ".3f"),
                            num(r_["sd"], ".3f"), num(ci[0], ".3f"), num(ci[1], ".3f"), num(r_.get("p"), ".4f"), "",
                            r_["reading_unadjusted"] + " (unadjusted)"])
    lines = ["=" * 100, "LERNA ROUND-19 CHECK: CONFIRMATORY TEST ON THE DENSE LLMs (Llama-3.2-1B, Qwen3-0.6B-Base), 35% COMPUTE",
             "=" * 100, f"integrity: {verdict}" + (f" ({len(integrity_fails)} problems)" if integrity_fails else "")]
    lines += [f"  - {x}" for x in integrity_fails[:40]]
    lines += [f"note: {x}" for x in notes]
    lines.append(f"runs passing their checks: {report['runs_ok']} of {report['runs_planned']}; "
                 f"smoke gate: {(gate or {}).get('pass')}; learning rate {LEARNING_RATE}; seeds {', '.join(map(str, SEEDS))}")
    for m in MODELS:
        lines.append(f"{MODEL_NAME[m]}: {MODELS[m]}@{revs[m]}, {num(parameters[m], ',')} parameters")
    lines.append("")
    lines.append(f"THE TABLE: accuracy (%), mean (sd) over the {len(SEEDS)} seeds; compute relative to full fine-tuning's")
    head = f"{'method':44s} {'compute':>7s}"
    for m in MODELS:
        head += f" | {MODEL_NAME[m][:15]:>15s}: {'MRPC':>12s} {'RTE':>12s} {'mean':>6s}"
    lines.append(head + f" | {'all':>6s}")
    for r_ in final_table:
        s_ = f"{r_['name'][:44]:44s} {num(r_['mean_compute'], '.3f'):>7s}"
        for m in MODELS:
            cellv = r_["models"][m]
            s_ += (f" | {'':15s}  {num(cellv['mrpc']['mean'], '.2f'):>6s} ({num(cellv['mrpc']['sd'], '.2f'):>4s})"
                   f" {num(cellv['rte']['mean'], '.2f'):>6s} ({num(cellv['rte']['sd'], '.2f'):>4s}) {num(cellv['mean'], '.2f'):>6s}")
        lines.append(s_ + f" | {num(r_['mean_over_models'], '.2f'):>6s}")
    lines.append("")
    n_pairs = len(MODELS) * len(TASKS) * len(SEEDS)
    lines.append(f"THE PRIMARY TEST: method minus plain training at 35%, {n_pairs} pairs ({len(MODELS)} models x "
                 f"{len(TASKS)} tasks x {len(SEEDS)} seeds), two-sided t-test, Holm over the 2 rows")
    for r_ in primary:
        lines.append(f"  {r_['key']:26s} n={r_['n']:2d} diff {num(r_['mean'], '+.2f'):>6s} (sd {num(r_['sd'], '.2f')}) "
                     f"CI {ci_text(r_)} p={num(r_.get('p'), '.4f')} Holm={num(r_.get('p_holm'), '.4f')} "
                     f"+{r_['positive']}/-{r_['negative']}  {r_['reading']}")
    lines.append("SECONDARY (descriptive, unadjusted)")
    for r_ in secondary:
        lines.append(f"  {r_['key']:26s} n={r_['n']:2d} diff {num(r_['mean'], '+.2f'):>6s} (sd {num(r_['sd'], '.2f')}) "
                     f"CI {ci_text(r_)} p={num(r_.get('p'), '.4f')} +{r_['positive']}/-{r_['negative']}  "
                     f"{r_['reading_unadjusted']}")
    lines.append("")
    lines.append(f"PER MODEL (exploratory, {len(TASKS) * len(SEEDS)} pairs each, unadjusted)")
    for m, rows_m in per_model.items():
        lines.append(f"  {MODEL_NAME[m]}")
        for r_ in rows_m:
            lines.append(f"    {r_['key']:26s} diff {num(r_['mean'], '+.2f'):>6s} CI {ci_text(r_)} "
                         f"p={num(r_.get('p'), '.4f')}  {r_['reading_unadjusted']}")
    lines.append("")
    lines.append(f"PER MODEL AND TASK (descriptive, {len(SEEDS)} pairs each): mean difference [95% CI]")
    for k_, rows_c in per_cell.items():
        lines.append(f"  {k_:12s} " + "  ".join(f"{r_['key'].split('_', 1)[1]}: {num(r_['mean'], '+.2f')} {ci_text(r_)}"
                                                for r_ in rows_c))
    lines.append("")
    lines.append("BUDGET EXACTNESS, COMPUTE AND WALL-CLOCK (per model and task; wall relative to plain training at 35%)")
    for (m, t), methods in cells.items():
        lines.append(f"  {MODEL_NAME[m]} {TASK_NAME[t]}: "
                     + "; ".join(f"{lab}: compute {num(d['mean_compute'], '.3f')}"
                                 + (f" (max dev {num(d['max_budget_deviation'], '.4f')})" if d['max_budget_deviation'] is not None else "")
                                 + f", wall {num(d['wall_vs_plain'], '.2f')}" for lab, d in methods.items()))
    (out / "CHECK_SUMMARY.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA Step 5 preparation check, version 1 (3 November 2026). Read-only.

Collects the facts for the Step 5 decisions, without training or changing anything:
  A. the training recipe preregistered in experiments/PREREG_V4.md: the full text, and the
     lines about learning rate, warmup, schedule, batch size, steps, evaluation and seeds,
     at HEAD and in the v4-prereg-r3 tag;
  B. the recipe the archived runs actually used: every run_config value in their results.json
     files, per arm, with counts, and one full example per arm. The roots are the two fixed
     cohorts (stage2_confirmatory, sst2_replication) and the timing, LR-check, E1 and E3 runs;
  C. the archived runs' per-step costs on the V100s, from their trainer instrumentation;
  D. the launch scripts of the archived runs (/raid/*.sh), and the interpreters they name;
  E. the historical GPU environments: every interpreter the launch scripts name, plus
     /home/fy/miniconda3/envs/py310, /new_raid/nanhangproj/conda_envs/lerna and
     /raid/qwen-v100, each started only to print its versions, with GPUs hidden;
  F. current GPU occupancy (nvidia-smi query: memory used and utilisation per GPU only).

Usage (outside the repository):
  python -B LERNA_STEP5_PREP_CHECK.py --repo /home/nanhangproj/LERNA --out <new folder>

Writes only into --out, which must not exist yet. It never imports project code, never
writes, copies or moves a file it finds, and runs git only with --no-optional-locks and
read-only subcommands. Values that look like secrets are redacted from captured text.
Exit 0 means the report was written, whatever it found; exit 2 means bad arguments or an
existing --out.
"""
import os
import sys

os.environ["CUDA_VISIBLE_DEVICES"] = ""
sys.dont_write_bytecode = True

import argparse
import datetime
import hashlib
import json
import re
import subprocess
import time
import traceback
from collections import Counter
from pathlib import Path

VERSION = "LERNA_STEP5_PREP_CHECK v1 (2026-11-03)"
PREREG_REL = "experiments/PREREG_V4.md"
PREREG_TAG = "v4-prereg-r3"
COHORT_ROOTS = ["/raid/stage2_confirmatory", "/raid/sst2_replication", "/raid/stage2_timing", "/raid/stage2_lrcheck",
                "/raid/stage2_e1", "/raid/stage2_e3", "/raid/stage2_e3_fixed"]
LAUNCH_DIR = "/raid"
EXTRA_PYTHONS = ["/home/fy/miniconda3/envs/py310/bin/python3.10", "/home/fy/miniconda3/envs/py310/bin/python",
                 "/new_raid/nanhangproj/conda_envs/lerna/bin/python", "/raid/qwen-v100/bin/python"]
RECIPE_RE = re.compile(r"(?i)(learning.rate|\blr\b|warm.?up|decay|schedul|\blinear\b|cosine|constant|batch|epoch|"
                       r"total.steps|max_steps|\b6548\b|\b2619\b|\b392\b|\b157\b|grad.?norm|clip|weight.decay|adamw|"
                       r"optimi[sz]er|\beval|seed|precision|fp16|bf16|\bamp\b|max_length|\b512\b)")
PY_PATH_RE = re.compile(r"(/[\w./+-]+/bin/python[\w.]*)")
COST_KEYS = ("mean_step_time_executed", "mean_step_time_skipped", "mean_step_ms_executed", "mean_step_ms_skipped",
             "train_loop_seconds", "wall_seconds", "setup_seconds", "eval_seconds", "dataloader_wait_seconds")
SECRET_RES = [
    re.compile(r"(?i)((?:token|secret|password|passwd|api[_-]?key|auth|credential)[A-Za-z0-9_]*[\"']?\s*[:=]\s*[\"']?)"
               r"([^\s\"',}]{4,})"),
    re.compile(r"(hf_)[A-Za-z0-9]{20,}"),
    re.compile(r"(sk-)[A-Za-z0-9_-]{16,}"),
]
REDACTIONS = [0]


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def iso(ts):
    return datetime.datetime.fromtimestamp(ts).astimezone().isoformat(timespec="seconds")


def err(e):
    return f"{type(e).__name__}: {e}"[:800]


def redact(s):
    for rx in SECRET_RES:
        s, n = rx.subn(lambda m: m.group(1) + "<redacted>", s)
        REDACTIONS[0] += n
    return s


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run_cmd(cmd, timeout=120, cwd=None, env=None, cap=2_000_000):
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, cwd=cwd, env=env)
        out = p.stdout.decode("utf-8", "replace")
        return {"cmd": cmd, "exit": p.returncode, "stdout": out[:cap], "stderr": p.stderr.decode("utf-8", "replace")[-3000:]}
    except FileNotFoundError as e:
        return {"cmd": cmd, "exit": None, "error": err(e)}
    except subprocess.TimeoutExpired:
        return {"cmd": cmd, "exit": None, "error": f"timed out after {timeout} s"}


def git(repo, *args):
    return run_cmd(["git", "--no-optional-locks", "-C", str(repo), *args])


# ----------------------------------------------------------------------------- state
def section_state(repo):
    head = git(repo, "rev-parse", "HEAD")
    st = git(repo, "status", "--porcelain")
    lines = [l for l in (st.get("stdout") or "").splitlines() if l.strip()]
    return {"head": (head.get("stdout") or "").strip(), "porcelain_entries": len(lines), "porcelain": lines[:50],
            "time": now()}


# ----------------------------------------------------------------------------- A. preregistered recipe
def recipe_lines(text, cap=400):
    out = []
    for i, line in enumerate(text.splitlines()):
        if RECIPE_RE.search(line):
            out.append([i + 1, redact(line)[:600]])
    return out[:cap]


def section_prereg(repo):
    res = {}
    p = repo / PREREG_REL
    if p.is_file():
        t = p.read_text(errors="replace")
        res["working tree"] = {"sha256": sha256_file(p), "lines": len(t.splitlines()), "recipe_lines": recipe_lines(t),
                               "full_text": redact(t[:400000])}
    r = git(repo, "show", f"{PREREG_TAG}:{PREREG_REL}")
    if r.get("exit") == 0:
        t = r["stdout"]
        res[PREREG_TAG] = {"lines": len(t.splitlines()), "recipe_lines": recipe_lines(t),
                           "same_as_working_tree": t == (p.read_text(errors="replace") if p.is_file() else None)}
    else:
        res[PREREG_TAG] = {"error": (r.get("stderr") or r.get("error") or "")[-300:]}
    return res


# ----------------------------------------------------------------------------- B, C. archived cohorts
def flatten(d, prefix="", depth=0, out=None):
    out = {} if out is None else out
    if depth > 3 or not isinstance(d, dict):
        return out
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            flatten(v, key + ".", depth + 1, out)
        elif isinstance(v, list):
            out[key] = f"<list len={len(v)}>"
        else:
            out[key] = v
    return out


def find_numbers(obj, keys, depth=0, out=None):
    """Numeric values for the given key names anywhere in a nested dict (first occurrence wins)."""
    out = {} if out is None else out
    if depth > 6:
        return out
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in keys and k not in out and isinstance(v, (int, float)) and not isinstance(v, bool):
                out[k] = float(v)
            elif isinstance(v, (dict, list)):
                find_numbers(v, keys, depth + 1, out)
    elif isinstance(obj, list):
        for v in obj[:50]:
            find_numbers(v, keys, depth + 1, out)
    return out


def trim(obj, depth=0):
    if depth > 6:
        return "<deep>"
    if isinstance(obj, dict):
        return {k: trim(v, depth + 1) for k, v in list(obj.items())[:200]}
    if isinstance(obj, list):
        return obj if len(obj) <= 20 else f"<list len={len(obj)}>"
    if isinstance(obj, str):
        return redact(obj[:500])
    return obj


def section_cohorts(roots, max_files=3000):
    res = {"roots": {}}
    for root in roots:
        rp = Path(root)
        item = {"exists": rp.is_dir(), "results_files": 0, "parse_errors": 0, "arms": {}}
        if not rp.is_dir():
            res["roots"][root] = item
            continue
        files = sorted(rp.rglob("results.json"))[:max_files]
        item["results_files"] = len(files)
        for f in files:
            rel = f.relative_to(rp).parts
            arm = rel[0] if len(rel) > 1 else "."
            seed = rel[1] if len(rel) > 2 else None
            try:
                obj = json.loads(f.read_text(errors="replace"))
            except Exception:
                item["parse_errors"] += 1
                continue
            a = item["arms"].setdefault(arm, {"n": 0, "seeds": [], "top_keys": Counter(), "recipe": {},
                                              "costs": {k: [] for k in COST_KEYS}, "example": None,
                                              "provenance": {}})
            a["n"] += 1
            if seed is not None and len(a["seeds"]) < 60:
                a["seeds"].append(seed)
            if isinstance(obj, dict):
                a["top_keys"].update(obj.keys())
                rc = obj.get("run_config") if isinstance(obj.get("run_config"), dict) else {}
                for k, v in flatten(rc).items():
                    a["recipe"].setdefault(k, Counter())[redact(str(v))[:120]] += 1
                for k, v in find_numbers(obj.get("true_skip_instrumentation") or obj, set(COST_KEYS)).items():
                    a["costs"][k].append(v)
                pv = obj.get("provenance") if isinstance(obj.get("provenance"), dict) else {}
                for k, v in flatten(pv).items():
                    a["provenance"].setdefault(k, Counter())[redact(str(v))[:120]] += 1
                if a["example"] is None:
                    a["example"] = {"file": str(f), "mtime": iso(f.stat().st_mtime),
                                    "content": {k: trim(obj.get(k)) for k in ("run_config", "eval_metrics",
                                                                              "true_skip_instrumentation",
                                                                              "policy_diagnostics", "provenance")
                                                if k in obj}}
        for a in item["arms"].values():
            a["top_keys"] = dict(a["top_keys"].most_common(40))
            a["recipe"] = {k: dict(c.most_common(8)) for k, c in sorted(a["recipe"].items())}
            a["provenance"] = {k: dict(c.most_common(5)) for k, c in sorted(a["provenance"].items())}
            stats = {}
            for k, vals in a["costs"].items():
                if vals:
                    stats[k] = {"n": len(vals), "mean": sum(vals) / len(vals), "min": min(vals), "max": max(vals)}
            a["costs"] = stats
        res["roots"][root] = item
    return res


# ----------------------------------------------------------------------------- D. launch scripts
def section_launch(launch_dir):
    res = {"dir": launch_dir, "scripts": [], "interpreters": []}
    d = Path(launch_dir)
    if not d.is_dir():
        res["exists"] = False
        return res
    found = []
    for f in sorted(d.glob("*.sh")):
        try:
            if not f.is_file() or f.stat().st_size > 200_000:
                continue
            text = f.read_text(errors="replace")
        except OSError:
            continue
        pys = sorted(set(PY_PATH_RE.findall(text)))
        found += pys
        res["scripts"].append({"file": str(f), "size": f.stat().st_size, "mtime": iso(f.stat().st_mtime),
                               "interpreters": pys, "content": redact(text[:20000])})
    res["interpreters"] = sorted(set(found))
    return res


# ----------------------------------------------------------------------------- E. environments
ENV_PROBE = r'''
import json, sys
d = {"python": sys.version.split()[0], "prefix": sys.prefix, "executable": sys.executable}
for m in ("torch", "transformers", "datasets", "accelerate", "tokenizers", "huggingface_hub", "numpy"):
    try:
        mod = __import__(m)
        d[m] = getattr(mod, "__version__", "?")
    except Exception as e:
        d[m] = "missing (" + type(e).__name__ + ")"
try:
    import torch
    d["torch_cuda_build"] = torch.version.cuda
except Exception:
    pass
try:
    from transformers import ModernBertConfig
    d["has_ModernBertConfig"] = True
    try:
        d["config_has_reference_compile"] = hasattr(ModernBertConfig(), "reference_compile")
    except Exception as e:
        d["config_has_reference_compile"] = "error (" + type(e).__name__ + ")"
except Exception as e:
    d["has_ModernBertConfig"] = "no (" + type(e).__name__ + ")"
print(json.dumps(d))
'''


def section_envs(candidates, out):
    res = {}
    env = dict(os.environ)
    env["CUDA_VISIBLE_DEVICES"] = ""
    for py in candidates:
        item = {"exists": os.path.exists(py)}
        if item["exists"]:
            try:
                st = os.stat(py)
                item.update({"realpath": os.path.realpath(py), "owner_uid": st.st_uid, "mode": oct(st.st_mode & 0o777),
                             "executable_by_me": os.access(py, os.X_OK)})
            except OSError as e:
                item["stat_error"] = err(e)
            if item.get("executable_by_me"):
                r = run_cmd([py, "-I", "-B", "-c", ENV_PROBE], timeout=240, cwd=str(out), env=env)
                try:
                    item["probe"] = json.loads((r.get("stdout") or "").strip().splitlines()[-1])
                except Exception:
                    item["probe"] = {"error": r.get("error") or (r.get("stderr") or "")[-800:], "exit": r.get("exit")}
        res[py] = item
    return res


# ----------------------------------------------------------------------------- F. GPU occupancy
def section_gpus():
    r = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,utilization.gpu,driver_version",
                 "--format=csv,noheader"], timeout=60)
    rows = []
    for line in (r.get("stdout") or "").splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 6:
            rows.append(dict(zip(("index", "name", "memory_total", "memory_used", "utilization", "driver"), parts)))
    return {"exit": r.get("exit"), "error": r.get("error"), "gpus": rows, "stderr": (r.get("stderr") or "")[-500:]}


# ----------------------------------------------------------------------------- summary
def short(h, n=12):
    return (h or "")[:n] + ("…" if h and len(h) > n else "")


INTERESTING = re.compile(r"(?i)(learning_rate|^lr$|lr_|warmup|schedul|decay|total_steps|max_steps|batch|max_length|"
                         r"grad|clip|precision|fp16|bf16|seed|epoch|eval|optim|min_step|rate|controller|score)")


def glance(rep):
    L = [f"AT A GLANCE ({VERSION})"]
    s0, s1 = rep.get("state_start") or {}, rep.get("state_end") or {}
    L.append(f" Read-only: HEAD {short(s0.get('head'))} at start, {short(s1.get('head'))} at end; porcelain entries "
             f"{s0.get('porcelain_entries')} at start, {s1.get('porcelain_entries')} at end")
    pr = rep.get("prereg") or {}
    wt = pr.get("working tree") or {}
    L.append(f" PREREG_V4.md: {wt.get('lines')} lines, {len(wt.get('recipe_lines') or [])} recipe lines; same in "
             f"{PREREG_TAG}: {(pr.get(PREREG_TAG) or {}).get('same_as_working_tree')}")
    for root, item in ((rep.get("cohorts") or {}).get("roots") or {}).items():
        L.append(f" Cohort {root}: exists {item.get('exists')}, results.json {item.get('results_files')}, "
                 f"parse errors {item.get('parse_errors')}")
        for arm, a in sorted((item.get("arms") or {}).items()):
            rec = a.get("recipe") or {}
            keyvals = [f"{k}={'|'.join(v.keys())}" for k, v in rec.items() if INTERESTING.search(k.split('.')[-1])]
            L.append(f"   {arm}: n={a.get('n')}  " + "; ".join(keyvals[:18])[:900])
            c = a.get("costs") or {}
            if c:
                L.append("     cost (mean s): " + ", ".join(f"{k} {v['mean']:.4g} (n={v['n']})" for k, v in c.items()))
    la = rep.get("launch") or {}
    L.append(f" Launch scripts in {la.get('dir')}: {len(la.get('scripts') or [])}; interpreters named: "
             f"{la.get('interpreters')}")
    for py, e in (rep.get("environments") or {}).items():
        p = e.get("probe") or {}
        if not e.get("exists"):
            L.append(f" python {py}: NOT FOUND")
        elif "error" in p or not p:
            L.append(f" python {py}: exists, probe failed ({str(p.get('error'))[:100]})")
        else:
            L.append(f" python {py}: Python {p.get('python')}, torch {p.get('torch')} (CUDA {p.get('torch_cuda_build')}), "
                     f"transformers {p.get('transformers')}, datasets {p.get('datasets')}, accelerate {p.get('accelerate')}, "
                     f"ModernBERT {p.get('has_ModernBertConfig')}, reference_compile attr {p.get('config_has_reference_compile')}")
    g = rep.get("gpus") or {}
    if g.get("gpus"):
        L.append(" GPUs: " + "; ".join(f"{x['index']} {x['memory_used']} used, {x['utilization']}" for x in g["gpus"]))
    else:
        L.append(f" GPUs: nvidia-smi gave nothing (exit {g.get('exit')}, {g.get('error')})")
    L.append(f" Possible secrets redacted: {rep.get('redactions', 0)}")
    if rep.get("section_errors"):
        L.append(f" SECTION ERRORS: {', '.join(rep['section_errors'])}")
    return L


def summary_lines(rep):
    L = glance(rep)
    wt = (rep.get("prereg") or {}).get("working tree") or {}
    L += ["", "PREREG_V4.md lines about the recipe (working tree):"]
    L += [f"  {n:5d}: {t[:240]}" for n, t in (wt.get("recipe_lines") or [])[:160]]
    for root, item in ((rep.get("cohorts") or {}).get("roots") or {}).items():
        for arm, a in sorted((item.get("arms") or {}).items()):
            L += ["", f"{root} / {arm}: every run_config value (counts)"]
            for k, v in (a.get("recipe") or {}).items():
                L.append(f"  {k}: " + "; ".join(f"{val} ×{n}" for val, n in v.items()))
    la = rep.get("launch") or {}
    for s in la.get("scripts") or []:
        L += ["", f"Launch script {s['file']} ({s['mtime'][:10]}):"]
        L += ["  " + line for line in s["content"].splitlines()[:60]]
    return L


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cohort-root", action="append", default=None)
    ap.add_argument("--launch-dir", default=LAUNCH_DIR)
    ap.add_argument("--python", action="append", default=None, help="interpreter to probe (repeatable)")
    a = ap.parse_args()
    repo, out = Path(a.repo).resolve(), Path(a.out).resolve()
    if not (repo / "scripts" / "run_controller_ablation.py").is_file():
        print(f"--repo {repo} does not look like the LERNA checkout", file=sys.stderr)
        return 2
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if out == repo or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "python": sys.version, "section_errors": {}}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e), "traceback": traceback.format_exc()[-3000:]}
            rep["section_errors"][name] = err(e)
        rep.setdefault("seconds", {})[name] = round(time.time() - t0, 1)
        save()
        print(f"[{now()}] {name} done in {rep['seconds'][name]} s", flush=True)

    section("state_start", section_state, repo)
    section("prereg", section_prereg, repo)
    section("cohorts", section_cohorts, a.cohort_root or COHORT_ROOTS)
    section("launch", section_launch, a.launch_dir)
    cands = list(dict.fromkeys((a.python or EXTRA_PYTHONS) + list((rep.get("launch") or {}).get("interpreters") or [])))
    section("environments", section_envs, cands, out)
    section("gpus", section_gpus)
    section("state_end", section_state, repo)
    rep["redactions"] = REDACTIONS[0]
    rep["finished"] = now()
    save()
    (out / "SUMMARY.txt").write_text("\n".join(summary_lines(rep)) + "\n")
    print("\n".join(glance(rep)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

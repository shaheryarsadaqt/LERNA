#!/usr/bin/env python3
"""LERNA round 14: the LERNA v2 development round's launcher (6 November 2026).

It runs the round fixed in claude/LERNA_R14_METHOD_PLAN_2026-11-06.md (version 2), in qwen-v100,
one GPU per run, seeds 11, 13, 17, 19 and 23, with the Step 5 recipe (linear decay, warmup 6% of T,
eager attention, FP32), on QNLI (T=6548) and SST-2 (T=4210):
  - at 35% of full fine-tuning's compute, the main test and its 2 x 2 factorial: LERNA v2
    (lerna2_b035), v2 without the learning-rate factor (lerna2_nolr_b035), random keep with the
    learning-rate factor (randkeep_lr_b035) and plain random keep (randkeep_b035);
  - at 40%, the plan's original test: LERNA v2 (lerna2_b040) and random keep (randkeep_b040);
  - LERNA v2 at 60% and 83% (lerna2_b060, lerna2_b083): 80 runs in all;
  - three reproduction runs of round 13 at seed 11 (QNLI InfoBatch, SST-2 full fine-tuning and
    SST-2 InfoBatch), which must match round 13 bit for bit: 3 runs.

The smoke gate. Two of the 80 runs go first, alone: SST-2 lerna2_b035 and randkeep_b035 at seed
11. When both have ended, the launcher checks them (status OK, every step run, the dropped examples
counted, nothing dropped in the warmup, the spent compute within 0.005 of the budget). Only if both
pass does it start the other 81 runs, longest first, on every GPU. If the gate fails it stops and
writes SMOKE_GATE.json and DONE.json. There are no retries and no seed changes.

Each GPU has one private copy of each task's prepared cache, used by its runs one after another.

With --resume on an existing --out it continues an interrupted launch. It skips the runs that
started, never reruns a failed run, and holds back any run that started but has no end record,
listing it for a decision. A smoke gate that already passed is not run again. It refuses to resume
while the earlier launcher's process (launcher.pid) is still alive.

It writes only into --out, which must not exist:
  ds_cache/   per GPU, one private copy of each task's prepared cache, checked byte for byte
  runs/       one output folder per run
  logs/       one log per run
  plan.json, ledger.jsonl, SMOKE_GATE.json and DONE.json

Usage:
  python -s -B LERNA_R14_DEV_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R14_DEV_LAUNCH 2026-11-06 v2"
EXPECT = {
    "parent": "c8e521688bf02bd52b4116f4e5feaa908eca2dc2",
    "subject": "Round 14 runner: LERNA v2 (learning-rate-aware example selection under an exact budget)",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
FILES = {
    "scripts/run_controller_ablation.py": "52934f43f1e36a55edc3394ea39018d82b7b94f09d4092d1ef1a5d9d8c9af715",
    "lerna/utils/budget_selection.py": "a83905f9e537f04f532b87e489a7befd11427e875351b833e0272d1f7640a908",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
MODEL_REV = "45d08642849e5c5701b162671ac811b7654bfd9f"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"qnli": "qnli", "sst-2": "sst2"}
SHORT = {"qnli": "qnli", "sst-2": "sst2"}
HORIZON = {"qnli": {"total_steps": 6548, "min_step": 392}, "sst-2": {"total_steps": 4210, "min_step": 252}}
SEEDS = (11, 13, 17, 19, 23)
BUDGET = {"lerna2_b035": 0.35, "lerna2_nolr_b035": 0.35, "randkeep_lr_b035": 0.35, "randkeep_b035": 0.35,
          "lerna2_b040": 0.40, "randkeep_b040": 0.40, "lerna2_b060": 0.60, "lerna2_b083": 0.83}
GATE_TOLERANCE = 0.005
# arm: score source, controller, phases (the plain-arm settings; the runner forces them for these arms)
ARM_SPEC = {arm: ("uniform", "legacy_v4", 1) for arm in BUDGET}
ARM_SPEC.update({"full_finetune": ("uniform", "legacy_v4", 1), "infobatch": ("uniform", "legacy_v4", 1)})
SMOKE = ("sst2_lerna2_b035_seed11", "sst2_randkeep_b035_seed11")
# (task, arm) longest first, by the measured or expected length of each run
_ARM_ORDER = ("lerna2_b083", "lerna2_b060", "lerna2_b040", "randkeep_b040",
              "lerna2_b035", "lerna2_nolr_b035", "randkeep_lr_b035", "randkeep_b035")
ORDER = [(t, a) for t in ("qnli", "sst-2") for a in _ARM_ORDER]
REPRO = [("qnli", "infobatch"), ("sst-2", "full_finetune"), ("sst-2", "infobatch")]


def _entry(name, task, seed, arm):
    return (name, task, seed, arm) + ARM_SPEC[arm] + (HORIZON[task],)


DEV = [_entry(f"{SHORT[t]}_{a}_seed{s}", t, s, a) for t, a in ORDER for s in SEEDS]
REP = [_entry(f"repro_{SHORT[t]}_{a}_seed11", t, 11, a) for t, a in REPRO]
_smoke = [p for p in DEV if p[0] in SMOKE]
_rest = [p for p in DEV if p[0] not in SMOKE]
# smoke first; then the QNLI InfoBatch reproduction (the longest run), the rest of the QNLI runs,
# the two SST-2 reproductions and the rest of the SST-2 runs
PLAN = (_smoke + [REP[0]] + [p for p in _rest if p[1] == "qnli"] + REP[1:]
        + [p for p in _rest if p[1] == "sst-2"])
MIN_FREE_GB = 30
RUN_TIMEOUT = 3 * 3600


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def command(a, name, task, seed, arm, source, controller, phases, horizon):
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--device", "cuda",
           "--model-revision", MODEL_REV, "--tokenizer-revision", MODEL_REV, "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    if task == "qnli":
        cmd += ["--probe-exclusions-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
                "--probe-exclusions-hash", EXPECT["probe_file_sha256"]]
    return cmd


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def gate_check(out, entry, end):
    """The smoke gate's checks of one smoke run. Returns a list of failures (empty = pass)."""
    name, task, seed, arm = entry[0], entry[1], entry[2], entry[3]
    T = HORIZON[task]["total_steps"]
    fails = []
    if end is None:
        return ["no end record (interrupted)"]
    if end.get("exit") != 0:
        fails.append(f"exit code {end.get('exit')}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        return fails + [f"{len(found)} execution manifests found"]
    m = json.loads(found[0].read_text())
    if m.get("status") != "OK":
        return fails + [f"status {m.get('status')}: {str(m.get('reason'))[:300]}"]
    r = m.get("result", {})
    sel = r.get("selection") or {}
    for k, v in (("skipped", 0), ("backwards", T), ("forwards", T), ("forward_skipped", 0),
                 ("scheduler_advances", T), ("optimizer_updates", T)):
        if r.get(k) != v:
            fails.append(f"{k}={r.get(k)}, expected {v}")
    if sel.get("policy") != "lerna_budget":
        fails.append(f"selection policy {sel.get('policy')!r}")
    if sel.get("budget") != BUDGET[arm]:
        fails.append(f"budget {sel.get('budget')}, expected {BUDGET[arm]}")
    rf = sel.get("realized_fraction")
    if not isinstance(rf, (int, float)) or abs(rf - BUDGET[arm]) > GATE_TOLERANCE:
        fails.append(f"spent {rf} of the scheduled compute, budget {BUDGET[arm]} +/- {GATE_TOLERANCE}")
    dropped = r.get("examples_dropped_before_forward")
    if not isinstance(dropped, int) or dropped <= 0 or dropped != sel.get("pruned_examples"):
        fails.append(f"examples_dropped={dropped}, policy pruned={sel.get('pruned_examples')}")
    if sel.get("pruned_during_warmup") != 0:
        fails.append(f"pruned_during_warmup={sel.get('pruned_during_warmup')}")
    if sel.get("steps_seen") != T:
        fails.append(f"steps_seen={sel.get('steps_seen')}, expected {T}")
    if sel.get("warmup_steps") != int(math.floor(0.06 * T + 1e-9)):
        fails.append(f"warmup_steps={sel.get('warmup_steps')}")
    acc = r.get("final_eval_accuracy")
    if not isinstance(acc, (int, float)) or not 0.0 <= acc <= 1.0:
        fails.append(f"final_eval_accuracy={acc}")
    flr = r.get("final_learning_rate")
    if not isinstance(flr, (int, float)) or abs(flr) > 1e-12:
        fails.append(f"final_learning_rate={flr}")
    return fails


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--resume", action="store_true", help="continue an interrupted launch in --out")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists() and not a.resume:
        print(f"--out {out} already exists; choose a new folder, or add --resume", file=sys.stderr)
        return 2
    if a.resume and not (out / "plan.json").is_file():
        print(f"--resume needs an earlier launch in {out}", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    parent = git(repo, "rev-parse", "HEAD^")
    subject = git(repo, "log", "-1", "--format=%s")
    if parent != EXPECT["parent"]:
        problems.append(f"HEAD's parent is {parent}, expected {EXPECT['parent']} (round 12's commit)")
    if subject != EXPECT["subject"]:
        problems.append(f"HEAD's subject is {subject!r}, expected the round-14 commit")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the committed round-14 version")
    probe = repo / "experiments" / "probe_indices_v4.json"
    if not probe.is_file() or sha256_file(probe) != EXPECT["probe_file_sha256"]:
        problems.append("the probe file is missing or differs")
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out if out.exists() else (out.parent if out.parent.exists() else "/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    tasks = sorted({p[1] for p in PLAN})
    for task in tasks:
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    plan = list(PLAN)
    held_back = []
    ledger = out / "ledger.jsonl"
    pid_file = out / "launcher.pid"
    if a.resume and pid_file.is_file():
        try:
            other = int(pid_file.read_text().strip())
            os.kill(other, 0)
            print(f"STOP: another launcher (pid {other}) is still running on {out}", file=sys.stderr)
            return 2
        except (ValueError, ProcessLookupError):
            pass
        except PermissionError:
            print(f"STOP: a process with the launcher's pid is still running on {out}", file=sys.stderr)
            return 2
    if a.resume:
        meta = json.loads((out / "plan.json").read_text())
        if [x["name"] for x in meta["plan"]] != [p[0] for p in PLAN]:
            print("STOP: the plan in plan.json differs from this launcher's plan", file=sys.stderr)
            return 2
        gate_prev = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
        if gate_prev is not None and not gate_prev.get("pass"):
            print("STOP: the smoke gate failed in the earlier launch; nothing more is run", file=sys.stderr)
            return 3
        starts, ends = set(), {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e["event"] == "start":
                    starts.add(e["name"])
                elif e["event"] == "end":
                    ends[e["name"]] = e
        held_back = sorted(n for n in starts if n not in ends)
        plan = [p for p in PLAN if p[0] not in starts]
        meta.setdefault("resumes", []).append({"time": now(), "argv": sys.argv, "finished": len(ends),
                                               "held_back_interrupted": held_back, "to_run": len(plan)})
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
        print(json.dumps({"resume": True, "already_finished": len(ends), "interrupted_held_back": held_back,
                          "to_run": len(plan)}, indent=1))
    else:
        out.mkdir(parents=True)
        (out / "runs").mkdir()
        (out / "logs").mkdir()
        source_sha = {t: {f: sha256_file(cache_dir(a.source_cache, t) / f) for f in CACHE_FILES} for t in tasks}
        copies = {"source_sha256": source_sha, "gpus": {}}
        for g in gpus:
            for t in tasks:
                dst = cache_dir(out / "ds_cache" / f"gpu{g}", t)
                dst.mkdir(parents=True)
                for f in CACHE_FILES:
                    shutil.copy2(cache_dir(a.source_cache, t) / f, dst / f)
                same = all(sha256_file(dst / f) == source_sha[t][f] for f in CACHE_FILES)
                copies["gpus"][f"{g}/{t}"] = same
                if not same:
                    print(f"STOP: the private {t} cache copy for GPU {g} differs from its source", file=sys.stderr)
                    return 2
        meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "repo_parent": parent,
                "files": FILES, "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
                "smoke": list(SMOKE), "gate_tolerance": GATE_TOLERANCE,
                "plan": [{"name": p[0], "task": p[1], "seed": p[2], "arm": p[3], "score_source": p[4],
                          "controller": p[5], "n_phases": p[6], **p[7]} for p in PLAN]}
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
    pid_file.write_text(str(os.getpid()))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false"})
    lock = threading.Lock()

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    def run_queue(queue, gpu_list):
        def worker(gpu):
            while True:
                with lock:
                    if not queue:
                        return
                    p = queue.pop(0)
                name = p[0]
                cmd = command(a, *p)
                env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu),
                           HF_DATASETS_CACHE=str(out / "ds_cache" / f"gpu{gpu}"))
                t0 = time.time()
                record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
                with open(out / "logs" / f"{name}.log", "wb") as log:
                    try:
                        rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=RUN_TIMEOUT).returncode
                    except subprocess.TimeoutExpired:
                        rc = "timeout"
                manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
                record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                        "seconds": round(time.time() - t0, 1), "manifests": manifests})

        threads = [threading.Thread(target=worker, args=(g,)) for g in gpu_list]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    def all_ends():
        ends = {}
        if ledger.is_file():
            for line in ledger.read_text().splitlines():
                e = json.loads(line)
                if e.get("event") == "end":
                    ends[e["name"]] = e
        return ends

    def finish(extra):
        ends = all_ends()
        done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends.values() if e["exit"] == 0),
                "failed": sorted(n for n, e in ends.items() if e["exit"] != 0), "held_back_interrupted": held_back}
        done.update(extra)
        (out / "DONE.json").write_text(json.dumps(done, indent=1))
        print(json.dumps(done, indent=1))
        try:
            pid_file.unlink()
        except FileNotFoundError:
            pass

    # --- the smoke gate ---
    gate_file = out / "SMOKE_GATE.json"
    if not gate_file.is_file():
        smoke_queue = [p for p in plan if p[0] in SMOKE]
        if smoke_queue:
            run_queue(smoke_queue, gpus[:len(smoke_queue)])
        ends = all_ends()
        results = {p[0]: gate_check(out, p, ends.get(p[0])) for p in PLAN if p[0] in SMOKE}
        gate = {"time": now(), "pass": all(not f for f in results.values()), "tolerance": GATE_TOLERANCE,
                "runs": {n: {"pass": not f, "fails": f} for n, f in results.items()}}
        gate_file.write_text(json.dumps(gate, indent=1))
        print(json.dumps({"smoke_gate": gate}, indent=1))
        if not gate["pass"]:
            finish({"stopped_at": "smoke gate", "smoke_gate_pass": False})
            return 3
    # --- the other runs ---
    queue = [p for p in plan if p[0] not in SMOKE]
    run_queue(queue, gpus)
    finish({"smoke_gate_pass": True})
    return 0


if __name__ == "__main__":
    sys.exit(main())

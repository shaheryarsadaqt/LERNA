#!/usr/bin/env python3
"""LERNA round 14: checks and the pre-specified reading of the LERNA v2 development round. Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, SMOKE_GATE.json, runs/, logs/), round 13's
development folder (--r13) and the Step 5 main study's folder (--step5), and writes only
check_report.json and CHECK_SUMMARY.txt into the launcher's folder. Exit 0 means the report was
written; the verdict is inside it. Exit 2 means the folder isn't a finished launcher folder.

Per new run (63: the 60 LERNA v2 runs and the 3 reproductions), it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, revisions, device, and
    the LERNA v2 options (floor 0.1, window 64, chunks 16);
  - the exact counts: every scheduled step has a forward pass, a backward pass, an update and a
    scheduler step; no skip; the warmup steps; a final LR of 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases, attention,
    AdamW betas and eps, the pinned GPU;
  - the batch log (9 fields per row), and for LERNA v2 the policy's own accounting against it: the
    dropped examples, nothing dropped in the warmup, the spent and scheduled compute unit for unit,
    and the spent compute within 0.005 of the budget;
  - that every LERNA v2 run trained on the scheduled batches of full fine-tuning (same task and
    seed), row for row.
It also checks the comparators it reads: round 13's runs (its own check must have passed them) and
Step 5's QNLI runs; and the three reproductions of round 13, bit for bit.
Then it runs the reading fixed in claude/LERNA_R14_METHOD_PLAN_2026-11-06.md (version 2):
  - measured compute = (forward padded tokens + 2 x updated padded tokens) / the same for full
    fine-tuning of the same task and seed;
  - per task and seed, the plain-run curve through the six plain runs (30, 40, 50, 60, 70 and
    100% of T), joined by straight lines;
  - per method, task and seed, the gap to that curve in accuracy points; per method and task the
    mean, SD, 95% t-interval and number of positive gaps;
  - paired by seed: v2 - random keep at 35% (the second condition), the 2 x 2 factorial at 35%
    (scores, learning-rate factor, interaction), v2 - random keep at 40%, v2 at 83% - InfoBatch,
    v2 at 40% - the plain run at 40%;
  - THE RULE: v2 at 35% (lerna2_b035) goes on to confirmation only if, on both QNLI and SST-2,
    its mean gap is above 0 AND its mean paired difference from random keep (randkeep_b035) is
    above 0, each with at least 3 seeds;
  - the plan's original rule, the same at 40% (lerna2_b040, randkeep_b040), is reported beside it
    and decides nothing.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R14_DEV_CHECK 2026-11-06 v2"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
SEEDS = (11, 13, 17, 19, 23)
TASKS = ("qnli", "sst-2")
SHORT = {"qnli": "qnli", "sst-2": "sst2"}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349}
BATCH_SIZE = 32
HORIZON = {"qnli": 6548, "sst-2": 4210}
RATE = 0.60
# arm: (budget, scores, learning-rate factor)
LERNA2 = {"lerna2_b035": (0.35, True, True), "lerna2_nolr_b035": (0.35, True, False),
          "randkeep_lr_b035": (0.35, False, True), "randkeep_b035": (0.35, False, False),
          "lerna2_b040": (0.40, True, True), "randkeep_b040": (0.40, False, False),
          "lerna2_b060": (0.60, True, True), "lerna2_b083": (0.83, True, True)}
LERNA2_OPTIONS = {"lerna2_pi_min": 0.1, "lerna2_window": 64, "lerna2_chunks": 16}
BUDGET_TOLERANCE = 0.005
PLAIN_FRACTIONS = {"plain_030": 0.30, "plain_050": 0.50, "plain_070": 0.70}
CURVE_ARMS = ("plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070", "full_finetune")
# where each comparator comes from: QNLI's Step 5 arms, everything else from round 13
STEP5_QNLI = ("full_finetune", "reduced_steps", "equal_compute", "gate_s1_p4", "control_uniform_p4")
R13_QNLI = ("plain_030", "plain_050", "plain_070", "infobatch", "stale_s1_p4")
R13_SST2 = ("full_finetune", "reduced_steps", "equal_compute", "plain_030", "plain_050", "plain_070",
            "infobatch", "stale_s1_p4", "gate_s1_p4", "control_uniform_p4")
STEP5_HORIZON = {"total_steps": 6548, "min_step": 392}
METHODS = ("lerna2_b035", "lerna2_nolr_b035", "randkeep_lr_b035", "randkeep_b035", "lerna2_b040", "randkeep_b040",
           "lerna2_b060", "lerna2_b083", "infobatch", "stale_s1_p4", "gate_s1_p4", "control_uniform_p4")
LABEL = {"lerna2_b035": "LERNA v2, 35%", "lerna2_nolr_b035": "v2 without LR factor, 35%",
         "randkeep_lr_b035": "random keep + LR factor, 35%", "randkeep_b035": "random keep, 35%",
         "lerna2_b040": "LERNA v2, 40%", "randkeep_b040": "random keep, 40%",
         "lerna2_b060": "LERNA v2, 60%", "lerna2_b083": "LERNA v2, 83%", "infobatch": "InfoBatch (round 13)",
         "stale_s1_p4": "M1 (round 13)", "gate_s1_p4": "LERNA v1 (A1)", "control_uniform_p4": "random skipping (A2)"}
# (the method, its random-keep comparator): THE RULE at 35%, the plan's original rule at 40%
RULE_ARMS = {"b035": ("lerna2_b035", "randkeep_b035"), "b040": ("lerna2_b040", "randkeep_b040")}
REPRO = {"repro_qnli_infobatch_seed11": "qnli_infobatch_seed11",
         "repro_sst2_full_finetune_seed11": "sst2_full_finetune_seed11",
         "repro_sst2_infobatch_seed11": "sst2_infobatch_seed11"}
# two-sided 95% t quantiles by degrees of freedom
T975 = {1: 12.706204736174698, 2: 4.302652729749464, 3: 3.182446305284263, 4: 2.7764451051977987}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    """Compute units from batch-log rows of either format (6 or 9 fields)."""
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def check_run(p, end, out):
    name, task, arm, seed = p["name"], p["task"], p["arm"], p["seed"]
    T = p["total_steps"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "task": task, "arm": arm, "seed": seed, "total_steps": T}
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    warm = int(math.floor(0.06 * T + 1e-9))
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", T),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"] if task == "qnli" else None)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm in LERNA2:
        for k, v in LERNA2_OPTIONS.items():
            need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        need(c.get("infobatch_prune_ratio") == 0.5 and c.get("infobatch_anneal_fraction") == 0.875,
             "InfoBatch options are not 0.5 and 0.875")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k, v in (("effective_total", T), ("skipped", 0), ("backwards", T), ("forwards", T),
                 ("scheduler_advances", T), ("optimizer_updates", T), ("lr_warmup_steps", warm),
                 ("forward_skipped", 0)):
        need(r.get(k) == v, f"{k}={r.get(k)}, expected {v}")
    if arm == "full_finetune":
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == T, f"batch log rows {len(rows)}, expected {T}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if ok_shape and rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(all(int(x[4]) == 0 for x in rows), "a skip in the batch log")
            need(all(int(x[6]) == 1 for x in rows), "a row without a forward pass")
            need(all(math.isfinite(float(x[5])) for x in rows), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) <= int(x[8]) for x in rows),
                 "real tokens must be positive and at most the padded, and those at most the scheduled")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm == "full_finetune":
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            if arm in LERNA2:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows[:warm]), "an example dropped during the warmup")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    if arm in LERNA2:
        budget, scores, lr = LERNA2[arm]
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            for k, want in (("policy", "lerna_budget"), ("budget", budget), ("use_scores", scores),
                            ("use_lr_weight", lr), ("pi_min", 0.1), ("window", 64), ("chunks", 16),
                            ("warmup_steps", warm), ("total_steps", T), ("steps_seen", T),
                            ("batches_per_epoch", bpe), ("num_examples", n_train),
                            ("pruned_examples", dropped), ("pruned_during_warmup", 0)):
                need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
            rf = sel.get("realized_fraction")
            need(isinstance(rf, (int, float)) and abs(rf - budget) <= BUDGET_TOLERANCE,
                 f"spent {rf} of the scheduled compute, budget {budget} +/- {BUDGET_TOLERANCE}")
            need(dropped > 0, "no example dropped")
            if rows:
                need(sel.get("spent_units") == units_of(rows), "policy spent units differ from the batch log")
                need(sel.get("scheduled_units") == 3 * sum(int(x[8]) for x in rows),
                     "policy scheduled units differ from the batch log")
                need(sel.get("scheduled_examples") == sum(int(x[7]) for x in rows),
                     "policy scheduled examples differ from the batch log")
            need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
                 "kept + pruned differ from the scheduled examples")
            mw = sel.get("max_weight")
            need(isinstance(mw, (int, float)) and mw <= 10.0 + 1e-9, f"max_weight={mw}")
    elif arm == "infobatch":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
            need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    facts.update(accuracy=acc, loss=loss, wall_seconds=r.get("wall_seconds"), examples_dropped=dropped,
                 units=units_of(rows) if rows else None,
                 realized_fraction=(sel or {}).get("realized_fraction") if arm in LERNA2 else None,
                 never_seen=(sel or {}).get("never_seen_examples") if arm in LERNA2 else None,
                 fallbacks=(sel or {}).get("empty_batch_fallbacks") if arm in LERNA2 else None,
                 epochs={k: v.get("kept_fraction") for k, v in ((sel or {}).get("epochs") or {}).items()}
                 if arm in LERNA2 else None)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def load_comparator(folder, run_dir_name, task, arm, seed, horizon, source, ok_flag):
    """A round-13 or Step 5 run, lightly re-checked (its own round's checker verified it in full)."""
    res = {"name": f"{source}:{run_dir_name}", "task": task, "arm": arm, "seed": seed, "fails": [], "facts": {},
           "log_rows": []}
    if ok_flag is False:
        res["fails"].append(f"{source}'s own check did not pass this run")
    found = sorted((folder / "runs" / run_dir_name).rglob("execution_manifest.json"))
    if len(found) != 1:
        res["fails"].append(f"{len(found)} manifests found")
        res["ok"] = False
        return res
    m = json.loads(found[0].read_text())
    c, r = m.get("config", {}), m.get("result", {})
    if m.get("status") != "OK":
        res["fails"].append(f"status {m.get('status')}")
    for k, v in (("task", task), ("arm", arm), ("policy_seed", seed), ("total_steps", horizon)):
        if c.get(k) != v:
            res["fails"].append(f"config {k}={c.get(k)!r}, expected {v!r}")
    blf = m.get("batch_log_file") or {}
    lpath = found[0].parent / str(blf.get("file", "batch_log.csv"))
    rows = []
    if not lpath.is_file() or sha256_file(lpath) != blf.get("sha256"):
        res["fails"].append("batch log missing or its hash differs from the manifest")
    else:
        rows = read_log(lpath)[1]
    res["facts"] = {"accuracy": r.get("final_eval_accuracy"), "loss": r.get("final_eval_loss"),
                    "wall_seconds": r.get("wall_seconds"), "units": units_of(rows) if rows else None}
    res["log_rows"] = rows
    res["ok"] = not res["fails"]
    return res


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def curve_at(points, c):
    """Straight lines through (compute, accuracy) points; None outside their range."""
    pts = sorted(points)
    if len(pts) < 2 or c < pts[0][0] - 1e-12 or c > pts[-1][0] + 1e-12:
        return None
    for (c0, a0), (c1, a1) in zip(pts, pts[1:]):
        if c0 - 1e-12 <= c <= c1 + 1e-12:
            return a0 if c1 == c0 else a0 + (a1 - a0) * (c - c0) / (c1 - c0)
    return None


def summarize(values):
    vals = [g for g in values.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0), "by_seed": values}
    if n >= 2 and sd is not None and (n - 1) in T975:
        half = T975[n - 1] * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
    return out


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True)
    ap.add_argument("--r13", required=True, help="round 13's development folder (.../LERNA_r13/dev)")
    ap.add_argument("--step5", required=True, help="the Step 5 main study's folder (.../LERNA_step5_main/main)")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    r13, step5 = Path(a.r13).resolve(), Path(a.step5).resolve()
    plan = json.loads((out / "plan.json").read_text())
    gate = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    integrity_fails = []
    if gate is None or not gate.get("pass"):
        integrity_fails.append("the smoke gate did not pass" if gate else "SMOKE_GATE.json missing")
    runs = [check_run(p, ends.get(p["name"]), out) for p in plan["plan"]]
    # round 13's own check report decides which of its runs may be used. A comparator that is
    # missing or failed is left out of the reading for that seed, with the reason stated; it does
    # not change this round's integrity verdict, which is about this round's own runs.
    comparator_issues = []
    r13_report = r13 / "check_report.json"
    r13_ok, r13_integrity = {}, None
    if r13_report.is_file():
        rep = json.loads(r13_report.read_text())
        r13_integrity = rep.get("integrity")
        r13_ok = {x["name"]: bool(x.get("ok")) for x in rep.get("runs", [])}
        if r13_integrity != "PASS":
            comparator_issues.append(f"round 13's own check reported integrity {r13_integrity}")
    else:
        comparator_issues.append("round 13's check_report.json is missing: none of its runs is used")
    comps = []
    for s in SEEDS:
        for arm in STEP5_QNLI:
            comps.append(load_comparator(step5, f"{arm}_seed{s}", "qnli", arm, s, STEP5_HORIZON["total_steps"],
                                         "step5", None))
        for arm in R13_QNLI:
            nm = f"qnli_{arm}_seed{s}"
            comps.append(load_comparator(r13, nm, "qnli", arm, s, HORIZON["qnli"], "r13", r13_ok.get(nm, False)))
        for arm in R13_SST2:
            nm = f"sst2_{arm}_seed{s}"
            comps.append(load_comparator(r13, nm, "sst-2", arm, s, HORIZON["sst-2"], "r13", r13_ok.get(nm, False)))
    # reproductions of round 13, bit for bit
    by_name = {x["name"]: x for x in runs}
    repro = {}
    for mine, theirs in REPRO.items():
        x = by_name.get(mine)
        y = next((c for c in comps if c["name"] == f"r13:{theirs}"), None)
        if x is None or not x.get("log_rows") or y is None or not y.get("log_rows"):
            repro[mine] = {"comparable": False}
            integrity_fails.append(f"reproduction of round 13's {theirs} not comparable")
            continue
        same = {"same_accuracy": y["facts"].get("accuracy") == x["facts"].get("accuracy"),
                "same_loss": y["facts"].get("loss") == x["facts"].get("loss"),
                "same_batch_log": y["log_rows"] == x["log_rows"]}
        repro[mine] = dict(comparable=True, **same)
        if not all(same.values()):
            integrity_fails.append(f"{mine} does not reproduce round 13's {theirs} bit for bit")
    # every run keyed by (task, arm, seed); the reproductions are kept out of the reading
    table = {}
    for x in comps + [x for x in runs if x["name"] not in REPRO]:
        table[(x["task"], x["arm"], x["seed"])] = x
    for x in runs:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    for x in comps:
        if not x["ok"]:
            comparator_issues.append(f"{x['name']} left out: " + "; ".join(x["fails"][:3]))
    # LERNA v2 trained on full fine-tuning's scheduled batches, row for row
    same_batches = {}
    for x in runs:
        if x["arm"] not in LERNA2 or not x.get("log_rows"):
            continue
        full = table.get((x["task"], "full_finetune", x["seed"]))
        frows = (full or {}).get("log_rows") or []
        same = (len(frows) == len(x["log_rows"])
                and all(int(fr[2]) == int(r[8]) and int(fr[3]) == int(r[7]) for fr, r in zip(frows, x["log_rows"])))
        same_batches[x["name"]] = same
        if not same:
            integrity_fails.append(f"{x['name']}: scheduled batches differ from full fine-tuning's")
    # measured compute against full fine-tuning of the same task and seed
    for x in runs + comps:
        full = table.get((x["task"], "full_finetune", x["seed"]))
        u, fu = x["facts"].get("units"), (full or {}).get("facts", {}).get("units")
        x["facts"]["compute"] = (u / fu) if (u and fu and full.get("ok")) else None
    analysis = {}
    for task in TASKS:
        curves = {}
        for s in SEEDS:
            pts = []
            for arm in CURVE_ARMS:
                x = table.get((task, arm, s))
                if x and x["ok"] and isinstance(x["facts"].get("compute"), (int, float)):
                    pts.append((x["facts"]["compute"], 100.0 * x["facts"]["accuracy"]))
            curves[s] = pts
        methods = {}
        for meth in METHODS:
            gaps, cs, walls, accs, notes = {}, [], [], [], {}
            for s in SEEDS:
                x = table.get((task, meth, s))
                if not x or not x["ok"]:
                    notes[s] = "run missing or failed its checks"
                    continue
                c = x["facts"].get("compute")
                accs.append(100.0 * x["facts"]["accuracy"])
                walls.append(x["facts"].get("wall_seconds"))
                cs.append(c)
                if len(curves[s]) < len(CURVE_ARMS):
                    notes[s] = f"curve has {len(curves[s])} of {len(CURVE_ARMS)} points"
                    continue
                cv = curve_at(curves[s], c) if isinstance(c, (int, float)) else None
                gaps[s] = "outside the curve" if cv is None else 100.0 * x["facts"]["accuracy"] - cv
            sm = summarize(gaps)
            sm.update(mean_compute=mean_sd(cs)[0], mean_accuracy=mean_sd(accs)[0], sd_accuracy=mean_sd(accs)[1],
                      mean_wall_seconds=mean_sd(walls)[0], notes=notes)
            methods[meth] = sm

        def acc(arm, s):
            x = table.get((task, arm, s))
            return 100.0 * x["facts"]["accuracy"] if x and x["ok"] else None

        def paired(fn):
            vals = {}
            for s in SEEDS:
                try:
                    v = fn(s)
                except TypeError:
                    v = None
                if isinstance(v, (int, float)):
                    vals[s] = v
            return summarize(vals)

        contrasts = {
            "v2_minus_randkeep_b035": paired(lambda s: acc("lerna2_b035", s) - acc("randkeep_b035", s)),
            "score_effect_b035": paired(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("randkeep_lr_b035", s))
                                                         + (acc("lerna2_nolr_b035", s) - acc("randkeep_b035", s)))),
            "lr_factor_effect_b035": paired(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                             + (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s)))),
            "interaction_b035": paired(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                        - (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s)))),
            "v2_minus_randkeep_b040": paired(lambda s: acc("lerna2_b040", s) - acc("randkeep_b040", s)),
            "v2_b083_minus_infobatch": paired(lambda s: acc("lerna2_b083", s) - acc("infobatch", s)),
            "v2_b040_minus_plain_at_40": paired(lambda s: acc("lerna2_b040", s) - acc("reduced_steps", s)),
        }
        arms = {}
        for arm in sorted({k[1] for k in table if k[0] == task}):
            xs = [table[(task, arm, s)] for s in SEEDS if (task, arm, s) in table and table[(task, arm, s)]["ok"]]
            arms[arm] = {"n": len(xs),
                         "mean_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[0],
                         "sd_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[1],
                         "mean_compute": mean_sd([x["facts"].get("compute") for x in xs])[0],
                         "mean_wall_seconds": mean_sd([x["facts"].get("wall_seconds") for x in xs])[0]}
        analysis[task] = {"methods": methods, "contrasts": contrasts, "arms": arms,
                          "curves": {str(s): sorted(v) for s, v in curves.items()}}
    # THE RULE at 35%, and the plan's original rule at 40% (reported, decides nothing)
    def rule_at(tag):
        method, comparator = RULE_ARMS[tag]
        cond = {}
        for task in TASKS:
            g = analysis[task]["methods"][method]
            d = analysis[task]["contrasts"][f"v2_minus_randkeep_{tag}"]
            cond[task] = {"method": method, "comparator": comparator,
                          "gap_n": g["n"], "gap_mean": g["mean"], "vs_random_n": d["n"], "vs_random_mean": d["mean"],
                          "gap_above_0": isinstance(g["mean"], (int, float)) and g["mean"] > 0,
                          "beats_random": isinstance(d["mean"], (int, float)) and d["mean"] > 0,
                          "enough_seeds": g["n"] >= 3 and d["n"] >= 3}
        if not all(c["enough_seeds"] for c in cond.values()):
            text = "NO READING: fewer than 3 seeds with a gap or a paired difference on a task"
        elif all(c["gap_above_0"] and c["beats_random"] for c in cond.values()):
            text = ("GOES ON to confirmation: on both tasks, mean gap above 0 and mean difference "
                    "from random keep above 0")
        else:
            text = ("STOPS: on at least one task, the mean gap or the mean difference from random keep "
                    "is not above 0")
        return cond, text

    cond, rule = rule_at("b035")
    cond40, rule40 = rule_at("b040")
    rule40 = rule40.replace("GOES ON to confirmation", "would have gone on").replace("STOPS", "would have stopped")
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails,
              "comparator_issues": comparator_issues,
              "smoke_gate": gate, "round13_integrity": r13_integrity,
              "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "comparators_ok": sum(1 for x in comps if x["ok"]), "comparators_expected": len(comps),
              "reproduction": repro, "same_scheduled_batches": same_batches,
              "analysis": analysis, "rule": rule, "rule_conditions": cond,
              "original_rule_at_40": rule40, "original_rule_conditions": cond40,
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs],
              "comparators": [{k: v for k, v in x.items() if k != "log_rows"} for x in comps]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    def ci_text(d):
        ci = d.get("ci95")
        return f"[{num(ci[0] if ci else None, '+.3f')}, {num(ci[1] if ci else None, '+.3f')}]"

    lines = [f"LERNA V2 DEVELOPMENT ROUND CHECK ({VERSION}): integrity {verdict}; "
             f"{report['runs_ok']} of {len(runs)} new runs and {report['comparators_ok']} of {len(comps)} "
             f"comparator runs pass; smoke gate {'passed' if gate and gate.get('pass') else 'NOT passed'}; "
             f"round 13's own check: {r13_integrity}",
             "  reproduction of round 13 (seed 11): " +
             ", ".join(f"{k}: {'identical' if all(v.get(z) for z in ('same_accuracy', 'same_loss', 'same_batch_log')) else 'DIFFERS'}"
                       if v.get("comparable") else f"{k}: not comparable" for k, v in repro.items()),
             f"  LERNA v2 runs on full fine-tuning's scheduled batches: "
             f"{sum(1 for v in same_batches.values() if v)} of {len(same_batches)}"]
    for task in TASKS:
        lines.append(f"  {task}: arms (mean accuracy %, SD, measured compute vs full, mean wall seconds)")
        for arm, d in analysis[task]["arms"].items():
            lines.append(f"    {arm:<20} n {d['n']}  {num(d['mean_accuracy'], '.2f'):>6}  sd {num(d['sd_accuracy'], '.2f'):>5}  "
                         f"compute {num(d['mean_compute'], '.3f'):>6}  wall {num(d['mean_wall_seconds'], '.0f'):>5}")
        lines.append(f"  {task}: gap to the plain-run curve, accuracy points (mean, 95% t-interval, positive seeds)")
        for meth in METHODS:
            d = analysis[task]["methods"][meth]
            lines.append(f"    {LABEL[meth]:<30} n {d['n']}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  "
                         f"positive {d['positive']} of {d['n']}  compute {num(d['mean_compute'], '.3f')}")
            for s, why in d["notes"].items():
                lines.append(f"      seed {s}: {why}")
        lines.append(f"  {task}: paired by seed, accuracy points (mean, 95% t-interval, positive seeds)")
        for k, d in analysis[task]["contrasts"].items():
            lines.append(f"    {k:<30} n {d['n']}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  positive {d['positive']} of {d['n']}")
    lines.append("  THE RULE (plan version 2, section 4): LERNA v2 at 35% goes on only if, on both tasks, its mean gap")
    lines.append("  is above 0 and its mean paired difference from random keep at 35% is above 0")
    for task in TASKS:
        c = cond[task]
        lines.append(f"    {task}: gap {num(c['gap_mean'], '+.3f')} (n {c['gap_n']}), vs random keep "
                     f"{num(c['vs_random_mean'], '+.3f')} (n {c['vs_random_n']})")
    lines.append(f"    -> {rule}")
    lines.append("  The plan's original rule, the same at 40% (reported; it decides nothing):")
    for task in TASKS:
        c = cond40[task]
        lines.append(f"    {task}: gap {num(c['gap_mean'], '+.3f')} (n {c['gap_n']}), vs random keep "
                     f"{num(c['vs_random_mean'], '+.3f')} (n {c['vs_random_n']})")
    lines.append(f"    -> {rule40}")
    for msg in integrity_fails:
        lines.append(f"  FAIL: {msg}")
    for msg in comparator_issues:
        lines.append(f"  COMPARATOR: {msg}")
    lines.append("  Development round: a screening result, not a claim. Confirmation needs untouched tasks.")
    text = "\n".join(lines)
    (out / "CHECK_SUMMARY.txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

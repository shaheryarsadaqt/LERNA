#!/usr/bin/env python3
"""LERNA Step 5, round 10: pilot launcher (5 November 2026).

It runs the Step 5 pilot in qwen-v100: 9 arms x seeds 11, 13, 17 = 27 runs at the full
QNLI horizon (T=6548, min_step=392), one GPU per run. The runs share one queue, longest
first, and whichever GPU is free takes the next run. There are no retries and no seed
changes.

It writes only into --out, which must not exist:
  ds_cache/   one private copy of the prepared QNLI cache per run, each checked byte for byte,
              so that parallel runs never write map caches into the same folder
  runs/       one output folder per run
  logs/       one log per run
  ledger.jsonl and DONE.json

The recipe is the Step 5 one (linear decay, warmup 6% of each arm's length, eager attention,
FP32), as fixed in claude/LERNA_STEP5_ANALYSIS_PLAN_2026-11-05.md.

Usage:
  python -s -B LERNA_STEP5_PREP10_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_STEP5_PREP10_LAUNCH 2026-11-05"
EXPECT = {
    "head": "45dc79183ede882a7fa0f1ed1a8c200e33c00a69",
    "runner_sha256": "0b435c6288a86cc832884ba418b4e5e1d921f1ce57d47ad9bd26990285ecd08b",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
MODEL_REV = "45d08642849e5c5701b162671ac811b7654bfd9f"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
FULL = {"total_steps": 6548, "min_step": 392}
SEEDS = (11, 13, 17)
# arm, score source, controller, phases (the analysis plan's A1-A9)
ARMS = [
    ("full_finetune", "uniform", "legacy_v4", 1),        # A7
    ("gate_s1_p4", "s1", "phase_exact_v1", 4),           # A1
    ("control_uniform_p4", "uniform", "phase_exact_v1", 4),  # A2
    ("gate_loss_p4", "loss", "phase_exact_v1", 4),       # A3
    ("gate_s1inv_p4", "s1_inverted", "phase_exact_v1", 4),   # A4
    ("gate_s1_p1", "s1", "phase_exact_v1", 1),           # A5
    ("control_uniform_p1", "uniform", "phase_exact_v1", 1),  # A6
    ("equal_compute", "uniform", "legacy_v4", 1),        # A9
    ("reduced_steps", "uniform", "legacy_v4", 1),        # A8
]
# Longest first: all full fine-tuning runs, then the gated and equal-compute ones, then reduced.
PLAN = [(f"{arm}_seed{seed}", seed, arm, src, ctl, ph, FULL)
        for arm, src, ctl, ph in ARMS for seed in SEEDS]
MIN_FREE_GB = 30
RUN_TIMEOUT = 3 * 3600


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def command(a, name, seed, arm, source, controller, phases, horizon):
    return [a.python, "-s", "-B", str(Path(a.repo) / a.runner),
            "--task", "qnli", "--arm", arm, "--score-source", source, "--controller-version", controller,
            "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
            "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
            "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
            "--device", "cuda",
            "--model-revision", MODEL_REV, "--tokenizer-revision", MODEL_REV, "--dataset-revision", GLUE_REV,
            "--probe-exclusions-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
            "--probe-exclusions-hash", EXPECT["probe_file_sha256"],
            "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--runner", default="scripts/run_controller_ablation.py")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--plan-names", nargs="*", default=None, help="run only these plan entries (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECT[k] = v
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    if git(repo, "rev-parse", "HEAD") != EXPECT["head"]:
        problems.append(f"HEAD is {git(repo, 'rev-parse', 'HEAD')}, expected {EXPECT['head']}")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    runner = repo / a.runner
    if not runner.is_file() or sha256_file(runner) != EXPECT["runner_sha256"]:
        problems.append("the runner is missing or not the committed version")
    probe = repo / "experiments" / "probe_indices_v4.json"
    if not probe.is_file() or sha256_file(probe) != EXPECT["probe_file_sha256"]:
        problems.append("the probe file is missing or differs")
    plan = [p for p in PLAN if a.plan_names is None or p[0] in a.plan_names]
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out.parent if out.parent.exists() else "/").free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    src = Path(a.source_cache) / "glue" / "qnli" / "0.0.0" / GLUE_REV
    for f in CACHE_FILES:
        if not (src / f).is_file():
            problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    out.mkdir(parents=True)
    (out / "runs").mkdir()
    (out / "logs").mkdir()
    source_sha = {f: sha256_file(src / f) for f in CACHE_FILES}
    copies = {"source_sha256": source_sha, "runs": {}}
    for p in plan:
        dst = out / "ds_cache" / p[0] / "glue" / "qnli" / "0.0.0" / GLUE_REV
        dst.mkdir(parents=True)
        for f in CACHE_FILES:
            shutil.copy2(src / f, dst / f)
        same = all(sha256_file(dst / f) == source_sha[f] for f in CACHE_FILES)
        copies["runs"][p[0]] = same
        if not same:
            print(f"STOP: the private cache copy for {p[0]} differs from its source", file=sys.stderr)
            return 2
    meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": EXPECT["head"],
            "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
            "plan": [{"name": p[0], "seed": p[1], "arm": p[2], "score_source": p[3], "controller": p[4],
                      "n_phases": p[5], **p[6]} for p in plan]}
    (out / "plan.json").write_text(json.dumps(meta, indent=1))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false"})
    lock = threading.Lock()
    ledger = out / "ledger.jsonl"

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    queue = list(plan)

    def worker(gpu):
        while True:
            with lock:
                if not queue:
                    return
                p = queue.pop(0)
            name = p[0]
            cmd = command(a, *p)
            env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu), HF_DATASETS_CACHE=str(out / "ds_cache" / name))
            t0 = time.time()
            record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
            with open(out / "logs" / f"{name}.log", "wb") as log:
                try:
                    rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                        timeout=RUN_TIMEOUT).returncode
                except subprocess.TimeoutExpired:
                    rc = "timeout"
            manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
            record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                    "seconds": round(time.time() - t0, 1), "manifests": manifests})

    threads = [threading.Thread(target=worker, args=(g,)) for g in gpus]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    ends = [json.loads(l) for l in ledger.read_text().splitlines() if '"event": "end"' in l]
    done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends if e["exit"] == 0),
            "failed": [e["name"] for e in ends if e["exit"] != 0]}
    (out / "DONE.json").write_text(json.dumps(done, indent=1))
    print(json.dumps(done, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

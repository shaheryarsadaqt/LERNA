#!/usr/bin/env python3
"""LERNA Step 5, round 10: checks of the pilot outputs (5 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, runs/, logs/) and writes only
check_report.json and CHECK_SUMMARY.txt into that folder. Exit 0 means the report was
written; the verdict is inside it. Exit 2 means the folder isn't a finished launcher folder.

Per run, it checks:
  - the exit code and the manifest status;
  - the config: arm, controller, phases, score source, seed, recipe, revisions, device;
  - the exact counts: forwards, backwards, skips and scheduler steps;
  - the warmup steps, and that the final LR is 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases,
    attention, AdamW betas and eps, the pinned GPU;
  - the batch log: its row count, its hash, its skip count, and the sanity of its tokens.
It then applies the pilot gate of the analysis plan (section 6): every run finished, every
count is exact, and every final LR is 0. It also reports:
  - a descriptive table per arm and seed (the pilot's accuracies are not tested and are
    never pooled with the main study);
  - the measured compute of each arm relative to full fine-tuning of the same seed;
  - the seed-11 reproduction of the smoke-test runs (--reference), batch log by batch log.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_STEP5_PREP10_CHECK 2026-11-05"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
RATE = 0.60


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm == "full_finetune":
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def check_run(p, end, out):
    name = p["name"]
    gpu = end.get("gpu") if end else None
    fails, notes, facts = [], [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    need(end is not None, "no end record in the ledger")
    if end is None:
        return {"name": name, "ok": False, "fails": fails}
    need(end["exit"] == 0, f"exit code {end['exit']}")
    # Found relative to the launcher folder, so the check also works on a moved or unpacked copy.
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return {"name": name, "ok": False, "fails": fails}
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(p["arm"], p["total_steps"])
    # config
    for k, v in (("arm", p["arm"]), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", p["seed"]), ("total_steps", p["total_steps"]),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"]), ("precision", "fp32"),
                 ("attention", "eager"), ("dry_run", False)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    # counts and schedule
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == exp["effective_total"], f"forwards={r.get('forwards')}")
    need(r.get("scheduler_advances") == exp["effective_total"], f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    # runtime block
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    # batch log
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss"],
             f"batch log header {header}")
        need(len(rows) == exp["effective_total"], f"batch log rows {len(rows)}, expected {exp['effective_total']}")
        need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
        need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
        need(all(0 < int(x[1]) <= int(x[2]) for x in rows), "real tokens must be positive and at most the padded tokens")
        need(all(0 < int(x[3]) <= 32 for x in rows), "batch sizes outside 1..32")
        need(all(math.isfinite(float(x[5])) for x in rows), "non-finite forward loss in the log")
        s = r.get("batch_log_summary") or {}
        facts["compute_units_padded"] = s.get("compute_units_padded")
        facts["padded_tokens_all"] = s.get("padded_tokens_all")
    facts.update(accuracy=acc, loss=loss, wall_seconds=r.get("wall_seconds"),
                 seconds_per_step=(r.get("wall_seconds") / exp["effective_total"]) if r.get("wall_seconds") else None,
                 run_seconds=end.get("seconds"), cuda=rt.get("cuda"), cudnn_deterministic=rt.get("cudnn_deterministic"))
    if p["total_steps"] == 6548 and isinstance(acc, (int, float)) and acc < 0.85:
        notes.append(f"full-length accuracy {acc:.4f} is below 0.85: look at the log before any pilot")
    return {"name": name, "gpu": gpu, "seed": p["seed"], "arm": p["arm"], "ok": not fails, "fails": fails,
            "notes": notes, "facts": facts, "manifest": str(mpath.relative_to(out)), "log_rows": rows}


def compare_pair(a, b):
    res = {"names": [a["name"], b["name"]]}
    fa, fb = a.get("facts", {}), b.get("facts", {})
    if all(isinstance(x.get("accuracy"), (int, float)) for x in (fa, fb)):
        res["accuracy"] = [fa["accuracy"], fb["accuracy"]]
        res["accuracy_diff_points"] = 100 * (fa["accuracy"] - fb["accuracy"])
        res["loss_diff"] = fa["loss"] - fb["loss"]
    ra, rb = a.get("log_rows") or [], b.get("log_rows") or []
    if ra and rb and len(ra) == len(rb):
        res["same_batches"] = all(x[:5] == y[:5] for x, y in zip(ra, rb))
        diffs = [abs(float(x[5]) - float(y[5])) for x, y in zip(ra, rb)]
        res["forward_loss_max_abs_diff"] = max(diffs)
        first = next((i for i, d in enumerate(diffs) if d > 1e-6), None)
        res["first_step_loss_differs_1e-6"] = first
    return res


ARM_ORDER = ["gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "gate_s1inv_p4", "gate_s1_p1",
             "control_uniform_p1", "full_finetune", "reduced_steps", "equal_compute"]
LABEL = {"gate_s1_p4": "A1", "control_uniform_p4": "A2", "gate_loss_p4": "A3", "gate_s1inv_p4": "A4",
         "gate_s1_p1": "A5", "control_uniform_p1": "A6", "full_finetune": "A7", "reduced_steps": "A8",
         "equal_compute": "A9"}


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def reference_runs(ref):
    """The smoke test's seed-11 full-length runs, found inside the reference folder."""
    res = {}
    for smoke_name, arm in (("full_gate_s1_p4", "gate_s1_p4"), ("full_full_finetune_a", "full_finetune")):
        found = sorted((ref / "runs" / smoke_name).rglob("execution_manifest.json"))
        if len(found) == 1:
            m = json.loads(found[0].read_text())
            log = found[0].parent / "batch_log.csv"
            res[arm] = {"smoke_run": smoke_name, "accuracy": (m.get("result") or {}).get("final_eval_accuracy"),
                        "loss": (m.get("result") or {}).get("final_eval_loss"),
                        "rows": read_log(log)[1] if log.is_file() else None}
    return res


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True, help="the launcher's --out folder")
    ap.add_argument("--reference", default=None, help="the smoke test's folder, for the seed-11 reproduction")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECT[k] = v
    out = Path(a.out)
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json are needed)", file=sys.stderr)
        return 2
    plan = json.loads((out / "plan.json").read_text())["plan"]
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    runs = []
    for p in plan:
        try:
            runs.append(check_run(p, ends.get(p["name"]), out))
        except Exception as e:
            runs.append({"name": p["name"], "seed": p["seed"], "arm": p["arm"], "ok": False,
                         "fails": [f"checker error: {type(e).__name__}: {e}"]})
    by = {(r.get("arm"), r.get("seed")): r for r in runs}
    seeds = sorted({p["seed"] for p in plan})
    table = {}
    for arm in ARM_ORDER:
        accs = [((by.get((arm, s)) or {}).get("facts") or {}).get("accuracy") for s in seeds]
        walls = [((by.get((arm, s)) or {}).get("facts") or {}).get("wall_seconds") for s in seeds]
        frac = []
        for s in seeds:
            u = ((by.get((arm, s)) or {}).get("facts") or {}).get("compute_units_padded")
            f = ((by.get(("full_finetune", s)) or {}).get("facts") or {}).get("compute_units_padded")
            frac.append(u / f if u and f else None)
        m, sd = mean_sd(accs)
        table[arm] = {"label": LABEL[arm], "accuracy_by_seed": dict(zip(seeds, accs)), "mean": m, "sd": sd,
                      "wall_mean": mean_sd(walls)[0], "compute_fraction_by_seed": dict(zip(seeds, frac))}
    contrasts = {}
    for cname, x, y in (("C1 = A1 - A2", "gate_s1_p4", "control_uniform_p4"),
                        ("C2 = A1 - A9", "gate_s1_p4", "equal_compute")):
        d = []
        for s in seeds:
            ax = ((by.get((x, s)) or {}).get("facts") or {}).get("accuracy")
            ay = ((by.get((y, s)) or {}).get("facts") or {}).get("accuracy")
            d.append(100 * (ax - ay) if isinstance(ax, (int, float)) and isinstance(ay, (int, float)) else None)
        m, sd = mean_sd(d)
        contrasts[cname] = {"points_by_seed": dict(zip(seeds, d)), "mean": m, "sd": sd}
    repro = None
    if a.reference:
        repro = {}
        ref = reference_runs(Path(a.reference))
        for arm, rr in ref.items():
            pr = by.get((arm, 11)) or {}
            prow = pr.get("log_rows")
            same = None
            if rr.get("rows") is not None and prow is not None:
                same = rr["rows"] == prow
            repro[arm] = {"smoke_run": rr["smoke_run"], "smoke_accuracy": rr["accuracy"],
                          "pilot_accuracy": (pr.get("facts") or {}).get("accuracy"),
                          "batch_logs_identical": same}
    for r in runs:
        r.pop("log_rows", None)
    gate = "PASS" if len(runs) == len(plan) and all(r["ok"] for r in runs) else "FAIL"
    rep = {"version": VERSION, "pilot_gate": gate, "runs": runs, "table": table, "contrasts_descriptive": contrasts,
           "seed11_reproduction": repro, "expect": EXPECT}
    (out / "check_report.json").write_text(json.dumps(rep, indent=1, default=str))
    L = [f"PILOT CHECK ({VERSION}): pilot gate {gate}; {sum(r['ok'] for r in runs)} of {len(plan)} runs pass every check"]
    for r in runs:
        if not r["ok"]:
            L.append(f"  FAIL {r['name']} (gpu {r.get('gpu')})")
            for x in r.get("fails", [])[:8]:
                L.append(f"        - {x}")
        for x in r.get("notes", []):
            L.append(f"  note {r['name']}: {x}")
    L.append("  descriptive only (the pilot is not tested): accuracy % by seed " + "/".join(str(s) for s in seeds)
             + ", mean, SD; measured compute vs full fine-tuning; mean wall seconds")
    def pct(v):
        return "-" if v is None else f"{100 * v:.2f}"

    def num(v, fmt):
        return "-" if v is None else format(v, fmt)

    for arm in ARM_ORDER:
        row = table[arm]
        accs = " ".join(pct(v) for v in row["accuracy_by_seed"].values())
        fr = [v for v in row["compute_fraction_by_seed"].values() if v is not None]
        L.append(f"  {row['label']} {arm:<20} {accs}   mean {pct(row['mean'])}  sd {pct(row['sd'])}"
                 f"  compute {num(sum(fr) / len(fr) if fr else None, '.4f')}"
                 f"  wall {num(row['wall_mean'], '.0f')}")
    for cname, c in contrasts.items():
        vals = " ".join(num(v, '+.2f') for v in c["points_by_seed"].values())
        L.append(f"  {cname}: {vals} points; mean {num(c['mean'], '+.2f')}, sd {num(c['sd'], '.2f')} (descriptive)")
    if repro is not None:
        for arm, v in repro.items():
            L.append(f"  seed-11 reproduction of the smoke run {v['smoke_run']}: accuracy {v['smoke_accuracy']} vs {v['pilot_accuracy']},"
                     f" batch logs identical: {v['batch_logs_identical']}")
    (out / "CHECK_SUMMARY.txt").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA Step 5 preparation check, round 2 (3 November 2026). Read-only apart from --out.

Collects what round 1 left open, without training or changing anything:
  A. the archived runs: every results.json under the seven cohort roots in /raid, with its
     step cost (ms_per_step, wall_seconds), final LR and the shape of lr_history, accuracy,
     validation status and provenance, plus the version fields of the manifest.json beside it;
  B. the provenance SHAs those runs recorded: git object type, date and subject, ancestry
     against the v4-prereg-r3 tag and HEAD, and whether the preregistered gate files differ;
  C. the recipe lines (LR, warmup, schedule, batch, clipping, precision, seeds, device) of
     the archived runner scripts at those commits, and of today's runner at HEAD;
  D. the files in the checkout that mention the cohorts, and the top level of each cohort;
  E. each candidate interpreter as it really starts: isolated (-I), without user
     site-packages (-s) and normally, printing versions and where each package comes from;
     the Python 3.10 user site-packages; Python-related variables and shell-startup lines;
  F. whether today's code runs in each GPU candidate, started with -s, PYTHONPATH unset,
     GPUs hidden and the network off: all tracked .py files compiled in memory, the runner
     imported, and four fixture executions (run_execution with dry_run=True, which trains
     the runner's tiny mock model on CPU, the path the test suite uses);
  G. the user id, and one GPU occupancy snapshot (memory used and utilisation only).

Usage (outside the repository):
  python -B LERNA_STEP5_PREP2_CHECK.py --repo /home/nanhangproj/LERNA --out <new folder>

Writes only into --out, which must not exist yet. The interpreters it starts get HF_HOME and
the other caches pointed into --out. It never writes, copies or moves a file it finds, and
runs git only with --no-optional-locks and read-only subcommands. Values that look like
secrets are redacted from captured text. Exit 0 means the report was written, whatever it
found; exit 2 means bad arguments or an existing --out.
"""
import os
import sys

os.environ["CUDA_VISIBLE_DEVICES"] = ""
sys.dont_write_bytecode = True

import argparse
import datetime
import json
import pwd
import re
import statistics
import subprocess
import time
import traceback
from collections import Counter
from pathlib import Path

VERSION = "LERNA_STEP5_PREP2_CHECK v1 (2026-11-03)"
TAG = "v4-prereg-r3"
COHORT_ROOTS = ["/raid/stage2_confirmatory", "/raid/sst2_replication", "/raid/stage2_timing", "/raid/stage2_lrcheck",
                "/raid/stage2_e1", "/raid/stage2_e3", "/raid/stage2_e3_fixed"]
CANDIDATES = {"base": sys.executable,
              "lerna": "/new_raid/nanhangproj/conda_envs/lerna/bin/python",
              "qwen-v100": "/raid/qwen-v100/bin/python",
              "fy-py310": "/home/fy/miniconda3/envs/py310/bin/python3.10"}
COMPAT_DEFAULT = ["base", "lerna", "qwen-v100"]
RUNNER_REL = "scripts/run_controller_ablation.py"
ARCHIVED_RUNNERS = ["scripts/stage2_confirmatory.py", "scripts/run_stage2_multi_gpu.py"]
GATE_FILES = ["lerna/utils/forward_gate.py", "experiments/PREREG_V4.md", "tests/test_forward_gate.py"]
RECIPE_CODE_RE = (r"lr_scheduler|scheduler_type|get_linear|get_constant|get_cosine|LambdaLR|warmup|learning_rate|lr=|"
                  r"weight_decay|max_grad_norm|clip_grad|per_device|max_length|fp16|bf16|tf32|adam_|optim=|"
                  r"eval_strategy|use_cpu|no_cuda|max_steps")
COHORT_MENTION_RE = re.compile(r"stage2_e1|stage2_e3|e3_fixed|sst2_replication|stage2_lrcheck|stage2_timing|"
                               r"stage2_confirmatory")
ENV_VARS = ["PYTHONPATH", "PYTHONHOME", "PYTHONUSERBASE", "PYTHONNOUSERSITE", "PYTHONSTARTUP", "PYTHONSAFEPATH",
            "CONDA_PREFIX", "CONDA_DEFAULT_ENV", "VIRTUAL_ENV", "HF_HOME", "HF_HUB_CACHE", "HF_DATASETS_CACHE",
            "TRANSFORMERS_CACHE", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE", "CUDA_HOME",
            "LD_LIBRARY_PATH", "PATH"]
DOTFILES = [".bashrc", ".bash_profile", ".profile", ".zshrc", ".condarc"]
DOTFILE_RE = re.compile(r"(?i)(python|conda|site-packages|\bpip|HF_|TRANSFORMERS|HUGGINGFACE|CUDA|LD_LIBRARY|LERNA)")
MANIFEST_KEY_RE = re.compile(r"(?i)(sha|commit|revision|version|torch|transformers|datasets|accelerate|tokenizers|"
                             r"cuda|python|device|gpu|executable|platform|host)")
HEX_SHA_RE = re.compile(r"[0-9a-f]{7,40}")
SECRET_RES = [
    re.compile(r"(?i)(\b[A-Za-z0-9_-]*(?:token|secret|password|passwd|api[_-]?key|credentials?|authorization)\b"
               r"[\"']?\s*[:=]\s*(?:bearer\s+)?[\"']?)([^\s\"',}]{4,})"),
    re.compile(r"(hf_)[A-Za-z0-9]{20,}"),
    re.compile(r"(sk-)[A-Za-z0-9_-]{16,}"),
]
HARMLESS = {"true", "false", "none", "null", "yes", "no"}
REDACTIONS = [0]

FIXTURE_BASE = dict(task="qnli", controller_version="legacy_v4", score_source="s1", min_step=0, n_phases=1,
                    max_consecutive_skips=4, policy_seed=0, target_skip_rate=0.5, capture_logits=True,
                    lr_warmup_steps=0, dry_run=True, probe_exclusions_file=None, probe_exclusions_hash=None)
FIXTURE_CASES = [
    ["gate_s1_p1_legacy_T4", {"arm": "gate_s1_p1", "total_steps": 4}],
    ["full_finetune_T4", {"arm": "full_finetune", "total_steps": 4}],
    ["reduced_steps_T8", {"arm": "reduced_steps", "total_steps": 8}],
    ["gate_s1_p1_exact_linear_T20", {"arm": "gate_s1_p1", "total_steps": 20, "controller_version": "phase_exact_v1",
                                     "lr_schedule_shape": "linear", "lr_warmup_steps": 2}],
]


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def iso(ts):
    return datetime.datetime.fromtimestamp(ts).astimezone().isoformat(timespec="seconds")


def err(e):
    return f"{type(e).__name__}: {e}"[:800]


def redact(s):
    if not isinstance(s, str):
        return s

    def rep(m):
        val = m.group(2) if (m.lastindex or 0) >= 2 else ""
        if val and val.lower() in HARMLESS:
            return m.group(0)
        REDACTIONS[0] += 1
        return m.group(1) + "<redacted>"

    for rx in SECRET_RES:
        s = rx.sub(rep, s)
    return s


def redact_obj(o, depth=0):
    if depth > 12:
        return "<deep>"
    if isinstance(o, str):
        return redact(o)
    if isinstance(o, dict):
        return {k: redact_obj(v, depth + 1) for k, v in o.items()}
    if isinstance(o, list):
        return [redact_obj(v, depth + 1) for v in o]
    return o


def run_cmd(cmd, timeout=120, cwd=None, env=None, cap=2_000_000):
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, cwd=cwd, env=env)
        return {"cmd": [str(c) for c in cmd], "exit": p.returncode, "stdout": p.stdout.decode("utf-8", "replace")[:cap],
                "stderr": p.stderr.decode("utf-8", "replace")[-4000:]}
    except FileNotFoundError as e:
        return {"cmd": [str(c) for c in cmd], "exit": None, "stdout": "", "stderr": "", "error": err(e)}
    except PermissionError as e:
        return {"cmd": [str(c) for c in cmd], "exit": None, "stdout": "", "stderr": "", "error": err(e)}
    except subprocess.TimeoutExpired:
        return {"cmd": [str(c) for c in cmd], "exit": None, "stdout": "", "stderr": "", "error": f"timed out after {timeout} s"}


def git(repo, *args, timeout=120):
    return run_cmd(["git", "--no-optional-locks", "-C", str(repo), *args], timeout=timeout)


def owner(st_uid):
    try:
        return pwd.getpwuid(st_uid).pw_name
    except KeyError:
        return None


def num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def stats(vals):
    vals = [float(v) for v in vals if num(v)]
    if not vals:
        return None
    s = {"n": len(vals), "mean": statistics.fmean(vals), "min": min(vals), "max": max(vals)}
    if len(vals) > 1:
        s["sd"] = statistics.stdev(vals)
    return s


def trim(obj, depth=0):
    if depth > 5:
        return "<deep>"
    if isinstance(obj, dict):
        return {k: trim(v, depth + 1) for k, v in list(obj.items())[:60]}
    if isinstance(obj, list):
        return obj if len(obj) <= 12 else {"list_len": len(obj), "head": trim(obj[:3], depth + 1),
                                           "tail": trim(obj[-3:], depth + 1)}
    if isinstance(obj, str):
        return redact(obj[:400])
    return obj


def flat_numbers(v, prefix="", depth=0, out=None):
    out = {} if out is None else out
    if num(v):
        out[prefix or "value"] = float(v)
    elif isinstance(v, dict) and depth < 3:
        for k, x in v.items():
            flat_numbers(x, f"{prefix}.{k}" if prefix else str(k), depth + 1, out)
    return out


def flatten(d, prefix="", depth=0, out=None):
    out = {} if out is None else out
    if depth > 4 or not isinstance(d, dict):
        return out
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            flatten(v, key + ".", depth + 1, out)
        elif isinstance(v, list):
            out[key] = f"<list len={len(v)}>"
        else:
            out[key] = v
    return out


# ----------------------------------------------------------------------------- state
def section_state(repo):
    head = git(repo, "rev-parse", "HEAD")
    st = git(repo, "status", "--porcelain", "--untracked-files=all")
    lines = [l for l in (st.get("stdout") or "").splitlines() if l.strip()]
    uid = os.getuid()
    return {"head": (head.get("stdout") or "").strip(), "porcelain_entries": len(lines), "porcelain": lines[:50],
            "time": now(), "uid": uid, "user": owner(uid)}


# ----------------------------------------------------------------------------- A. archived runs
def lr_points(h):
    """(step, lr) pairs from the shapes an lr_history is likely to take."""
    pts = []
    if isinstance(h, dict):
        lists = {k: v for k, v in h.items() if isinstance(v, list)}
        lr_key = next((k for k in lists if re.search(r"(?i)(^lrs?$|learning_rate|(^|_)lr($|_|s$))", k)), None)
        st_key = next((k for k in lists if re.search(r"(?i)step", k)), None)
        if lr_key:
            lrs = lists[lr_key]
            steps = lists[st_key] if st_key else list(range(len(lrs)))
            pts = [(float(s), float(x)) for s, x in zip(steps, lrs) if num(s) and num(x)]
        else:
            for k, v in h.items():
                try:
                    pts.append((float(k), float(v)))
                except (TypeError, ValueError):
                    pass
    elif isinstance(h, list):
        for i, e in enumerate(h):
            if num(e):
                pts.append((float(i + 1), float(e)))
            elif isinstance(e, (list, tuple)) and len(e) >= 2 and num(e[0]) and num(e[1]):
                pts.append((float(e[0]), float(e[1])))
            elif isinstance(e, dict):
                lr = next((e[k] for k in ("lr", "learning_rate", "lr0") if k in e and num(e[k])), None)
                st = next((e[k] for k in ("step", "global_step", "batch", "i") if k in e and num(e[k])), i)
                if lr is not None:
                    pts.append((float(st), float(lr)))
    pts.sort(key=lambda p: p[0])
    return pts


def lr_summary(pts):
    if not pts:
        return {"n": 0, "shape": "none"}
    lrs = [p[1] for p in pts]
    peak = max(lrs)
    s = {"n": len(pts), "first": list(pts[0]), "last": list(pts[-1]), "peak": peak}
    if peak <= 0:
        s["shape"] = "zero"
        return s
    i_w = next(i for i, x in enumerate(lrs) if x >= 0.999 * peak)
    s["peak_reached_at"] = pts[i_w][0]
    s["points_before_peak"] = i_w
    tail = pts[i_w:]
    k = len(tail)
    s["samples"] = [list(pts[min(len(pts) - 1, round(j * (len(pts) - 1) / 8))]) for j in range(9)]
    if all(abs(x - peak) <= 1e-6 * peak for _, x in tail):
        s["shape"] = "constant_after_warmup" if i_w > 0 else "constant"
        return s
    if k < 3:
        s["shape"] = "other"
        return s
    s0, s1 = tail[0][0], tail[-1][0]
    last = tail[-1][1]
    span = (s1 - s0) or 1.0

    def dev(f):
        return max(abs(x - f((st - s0) / span)) for st, x in tail) / peak

    import math
    d_lin = dev(lambda f: peak + f * (last - peak))
    d_cos = dev(lambda f: last + (peak - last) * 0.5 * (1 + math.cos(math.pi * f)))
    s["dev_linear"], s["dev_cosine"] = round(d_lin, 6), round(d_cos, 6)
    monotone = all(b[1] <= a[1] + 1e-9 * peak for a, b in zip(tail, tail[1:]))
    to_zero = last <= 0.02 * peak
    tol = 0.01 + 2.0 / k  # allows the curve to be off by about two steps on short runs
    if monotone and d_lin <= tol:
        s["shape"] = "linear_decay" + ("_to_zero" if to_zero else "")
    elif monotone and d_cos <= tol:
        s["shape"] = "cosine_decay" + ("_to_zero" if to_zero else "")
    else:
        s["shape"] = "other"
    return s


def section_cohorts(roots, max_files=5000):
    res = {"roots": {}, "shas": []}
    shas = set()
    for root in roots:
        rp = Path(root)
        item = {"exists": rp.is_dir(), "results_files": 0, "parse_errors": [], "groups": {}, "top_level": {}}
        if not rp.is_dir():
            res["roots"][root] = item
            continue
        try:
            entries = sorted(rp.iterdir())[:60]
            item["top_level"] = {e.name: ("dir" if e.is_dir() else f"file {e.stat().st_size} B {iso(e.stat().st_mtime)}")
                                 for e in entries}
        except OSError as e:
            item["top_level"] = {"error": err(e)}
        files = sorted(rp.rglob("results.json"))[:max_files]
        item["results_files"] = len(files)
        for f in files:
            rel = f.relative_to(rp).parts
            group = "/".join(rel[:-2]) if len(rel) > 2 else (rel[0] if len(rel) > 1 else ".")
            try:
                obj = json.loads(f.read_text(errors="replace"))
                if not isinstance(obj, dict):
                    raise ValueError("not a JSON object")
            except Exception as e:
                item["parse_errors"].append([str(f), err(e)[:200]])
                continue
            g = item["groups"].setdefault(group, {"n": 0, "seeds": [], "arms": Counter(), "top_keys": Counter(),
                                                  "num": {}, "lr_shape": Counter(), "lr_peak_at": Counter(),
                                                  "lr_peak": Counter(), "validation_passed": Counter(),
                                                  "provenance": {}, "manifest": {}, "manifest_present": 0,
                                                  "sample": None})
            g["n"] += 1
            rc = obj.get("run_config") if isinstance(obj.get("run_config"), dict) else {}
            g["arms"][str(rc.get("arm"))] += 1
            if rc.get("seed") is not None:
                g["seeds"].append(rc.get("seed"))
            g["top_keys"].update(obj.keys())
            em = obj.get("eval_metrics") if isinstance(obj.get("eval_metrics"), dict) else {}
            vals = {"actual_steps_run": rc.get("actual_steps_run"), "total_steps": rc.get("total_steps"),
                    "min_step": rc.get("min_step"), "final_lr": obj.get("final_lr")}
            for k, v in em.items():
                vals["eval." + k] = v
            for k, v in flat_numbers(obj.get("ms_per_step"), "ms_per_step").items():
                vals[k] = v
            for k, v in flat_numbers(obj.get("wall_seconds"), "wall_seconds").items():
                vals[k] = v
            for k, v in vals.items():
                if num(v):
                    g["num"].setdefault(k, []).append(float(v))
            pts = lr_points(obj.get("lr_history"))
            ls = lr_summary(pts)
            g["lr_shape"][ls["shape"]] += 1
            if "peak_reached_at" in ls:
                g["lr_peak_at"][str(ls["peak_reached_at"])] += 1
                g["lr_peak"][f"{ls['peak']:.3g}"] += 1
            g["validation_passed"][str(obj.get("validation_passed", "absent"))] += 1
            pv = obj.get("provenance") if isinstance(obj.get("provenance"), dict) else {}
            for k, v in flatten(pv).items():
                sv = redact(str(v))[:120]
                g["provenance"].setdefault(k, Counter())[sv] += 1
                if "sha" in k.lower() and isinstance(v, str) and HEX_SHA_RE.fullmatch(v):
                    shas.add(v)
            mf = f.with_name("manifest.json")
            if mf.is_file():
                g["manifest_present"] += 1
                try:
                    mobj = json.loads(mf.read_text(errors="replace"))
                    for k, v in flatten(mobj if isinstance(mobj, dict) else {}).items():
                        last_key = k.split(".")[-1]
                        if MANIFEST_KEY_RE.search(last_key):
                            g["manifest"].setdefault(k, Counter())[redact(str(v))[:120]] += 1
                            if re.search(r"(?i)(git_sha|commit|^sha$|_sha$)", last_key) and isinstance(v, str) \
                                    and HEX_SHA_RE.fullmatch(v):
                                shas.add(v)
                except Exception as e:
                    g["manifest"].setdefault("<parse error>", Counter())[err(e)[:120]] += 1
            if g["sample"] is None:
                lh = obj.get("lr_history")
                g["sample"] = {"file": str(f), "mtime": iso(f.stat().st_mtime),
                               "ms_per_step": trim(obj.get("ms_per_step")), "wall_seconds": trim(obj.get("wall_seconds")),
                               "final_lr": obj.get("final_lr"), "lr_history_type": type(lh).__name__,
                               "lr_history_len": len(lh) if isinstance(lh, (list, dict)) else None,
                               "lr_history_raw": trim(lh), "lr_summary": ls,
                               "validation_stderr_tail": redact(str(obj.get("validation_stderr") or "")[-300:])}
        for g in item["groups"].values():
            g["seeds"] = sorted(set(g["seeds"]), key=lambda x: (str(type(x)), x))
            g["arms"] = dict(g["arms"])
            g["top_keys"] = dict(g["top_keys"].most_common(40))
            g["num"] = {k: stats(v) for k, v in sorted(g["num"].items())}
            for key in ("lr_shape", "lr_peak_at", "lr_peak", "validation_passed"):
                g[key] = dict(g[key].most_common(10))
            g["provenance"] = {k: dict(c.most_common(6)) for k, c in sorted(g["provenance"].items())}
            g["manifest"] = {k: dict(c.most_common(5)) for k, c in sorted(g["manifest"].items())[:80]}
        res["roots"][root] = item
    res["shas"] = sorted(shas)
    return res


# ----------------------------------------------------------------------------- B. provenance SHAs
def section_git(repo, shas):
    res = {"refs": {}, "prereg_tags": None, "objects": {}}
    for ref in (TAG, TAG + "^{commit}", TAG + ":experiments/PREREG_V4.md", "HEAD", "HEAD:experiments/PREREG_V4.md"):
        r = git(repo, "rev-parse", "--verify", "--quiet", ref)
        res["refs"][ref] = (r.get("stdout") or "").strip() or None
    t = git(repo, "for-each-ref", "--format=%(refname:short)|%(objectname)|%(*objectname)|%(objecttype)|%(creatordate:iso)",
            "refs/tags/v4-prereg-*")
    res["prereg_tags"] = [l.split("|") for l in (t.get("stdout") or "").splitlines() if l.strip()]
    tag_commit = res["refs"].get(TAG + "^{commit}")
    for sha in sorted(shas)[:40]:
        o = {}
        r = git(repo, "cat-file", "-t", sha)
        o["type"] = (r.get("stdout") or "").strip() or ("missing: " + (r.get("stderr") or r.get("error") or "").strip()[:200])
        if o["type"] == "commit":
            full = git(repo, "rev-parse", sha)
            o["full"] = (full.get("stdout") or "").strip()
            lg = git(repo, "log", "-1", "--format=%ci|%an|%s", sha)
            parts = (lg.get("stdout") or "").strip().split("|", 2)
            o["date"], o["author"], o["subject"] = (parts + [None, None, None])[:3]
            if tag_commit:
                a = git(repo, "merge-base", "--is-ancestor", tag_commit, sha)
                o["contains_tag"] = {0: True, 1: False}.get(a.get("exit"), f"error {a.get('exit')}")
            b = git(repo, "merge-base", "--is-ancestor", sha, "HEAD")
            o["in_head_history"] = {0: True, 1: False}.get(b.get("exit"), f"error {b.get('exit')}")
            if tag_commit:
                d = git(repo, "diff", "--stat", tag_commit, sha, "--", *GATE_FILES)
                o["gate_files_diff_vs_tag"] = (d.get("stdout") or "").strip().splitlines()[:12]
            d2 = git(repo, "diff", "--stat", sha, "HEAD", "--", *ARCHIVED_RUNNERS, RUNNER_REL)
            o["runner_files_diff_to_head"] = (d2.get("stdout") or "").strip().splitlines()[:12]
        elif o["type"] in ("tag", "blob", "tree"):
            p = git(repo, "cat-file", "-p", sha)
            o["content_head"] = [redact(l)[:200] for l in (p.get("stdout") or "").splitlines()[:8]]
            if o["type"] == "blob":
                o["equals_tag_prereg_blob"] = sha == (res["refs"].get(TAG + ":experiments/PREREG_V4.md") or "")[:len(sha)]
        res["objects"][sha] = o
    return res


# ----------------------------------------------------------------------------- C. recipe lines in code
def section_recipe(repo, git_res):
    commits = [s for s, o in (git_res.get("objects") or {}).items() if o.get("type") == "commit"]
    revs = list(dict.fromkeys(commits[:8] + ["HEAD"]))
    res = {"revs": revs, "lines": {}}
    for rev in revs:
        for path in ARCHIVED_RUNNERS + [RUNNER_REL]:
            r = git(repo, "grep", "-n", "-I", "-i", "-E", RECIPE_CODE_RE, rev, "--", path)
            out = []
            for l in (r.get("stdout") or "").splitlines():
                parts = l.split(":", 3)
                if len(parts) == 4:
                    out.append([parts[2], redact(parts[3].strip())[:220]])
            res["lines"][f"{rev}:{path}"] = {"exit": r.get("exit"), "n": len(out), "lines": out[:220]}
    return res


# ----------------------------------------------------------------------------- D. mentions of the cohorts
MENTION_EXT = {".py", ".sh", ".md", ".txt", ".json", ".yaml", ".yml", ".toml", ".cfg", ".ini", ".tex", ".rst",
               ".ipynb", ".csv"}


def section_mentions(repo, max_files=20000, max_bytes=2_000_000, max_total=300_000_000):
    hits, scanned, total = [], 0, 0
    skip = {".git", "__pycache__", ".pytest_cache", "node_modules", ".mypy_cache", ".venv", "venv", "wandb",
            ".ipynb_checkpoints"}
    for dirpath, dirnames, filenames in os.walk(repo):
        dirnames[:] = sorted(d for d in dirnames if d not in skip)
        for fn in sorted(filenames):
            p = Path(dirpath) / fn
            if p.suffix.lower() not in MENTION_EXT:
                continue
            scanned += 1
            if scanned > max_files or total > max_total:
                return {"hits": hits, "scanned": scanned, "bytes": total, "truncated": True}
            try:
                if p.is_symlink() or p.stat().st_size > max_bytes:
                    continue
                data = p.read_bytes()
                total += len(data)
            except OSError:
                continue
            if b"\0" in data[:4096]:
                continue
            text = data.decode("utf-8", "replace")
            if not COHORT_MENTION_RE.search(text):
                continue
            lines = [[i + 1, redact(l.strip())[:220]] for i, l in enumerate(text.splitlines()) if COHORT_MENTION_RE.search(l)]
            hits.append({"file": str(p.relative_to(repo)), "count": len(lines), "lines": lines[:4]})
            if len(hits) >= 300:
                return {"hits": hits, "scanned": scanned, "bytes": total, "truncated": True}
    return {"hits": hits, "scanned": scanned, "bytes": total, "truncated": False}


# ----------------------------------------------------------------------------- E. interpreters
ENV_PROBE = r'''
import json, sys, site
d = {"python": sys.version.split()[0], "executable": sys.executable, "prefix": sys.prefix,
     "flags": {"isolated": sys.flags.isolated, "no_user_site": sys.flags.no_user_site,
               "ignore_environment": sys.flags.ignore_environment},
     "enable_user_site": getattr(site, "ENABLE_USER_SITE", None), "sys_path": sys.path[:40]}
try:
    d["user_site"] = site.getusersitepackages()
except Exception as e:
    d["user_site"] = "error " + type(e).__name__
pk = {}
for m in ("torch", "transformers", "datasets", "accelerate", "tokenizers", "huggingface_hub", "numpy", "safetensors",
          "pytest", "lerna"):
    try:
        mod = __import__(m)
        pk[m] = {"version": getattr(mod, "__version__", "?"), "file": getattr(mod, "__file__", None)}
    except Exception as e:
        pk[m] = {"error": type(e).__name__ + ": " + str(e)[:200]}
d["packages"] = pk
try:
    import torch
    d["torch_cuda_build"] = torch.version.cuda
    f = getattr(torch._C, "_cuda_getArchFlags", None)
    d["torch_arch_flags"] = f() if f else None
except Exception as e:
    d["torch_note"] = type(e).__name__
try:
    from transformers import ModernBertConfig
    d["has_ModernBertConfig"] = True
except Exception as e:
    d["has_ModernBertConfig"] = "no (" + type(e).__name__ + ")"
print("ENV_PROBE_JSON " + json.dumps(d))
'''
MODES = {"isolated": ["-I", "-B"], "no_user_site": ["-s", "-B"], "normal": ["-B"]}


def contained_env(out, clear_pythonpath=False):
    env = dict(os.environ)
    if clear_pythonpath:
        for k in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP"):
            env.pop(k, None)
    cache = Path(out) / "caches"
    env.update({"CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1", "HF_HOME": str(cache / "hf_home"),
                "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
                "XDG_CACHE_HOME": str(cache / "xdg"), "MPLCONFIGDIR": str(cache / "mpl"),
                "TORCH_COMPILE_DISABLE": "1", "TORCHDYNAMO_DISABLE": "1", "TOKENIZERS_PARALLELISM": "false",
                "WANDB_DISABLED": "true", "WANDB_MODE": "disabled", "OMP_NUM_THREADS": "4"})
    env.pop("HF_HUB_CACHE", None)
    env.pop("TRANSFORMERS_CACHE", None)
    env.pop("HF_DATASETS_CACHE", None)
    return env


def parse_probe(r, marker):
    for line in reversed((r.get("stdout") or "").splitlines()):
        if line.startswith(marker + " "):
            try:
                return json.loads(line[len(marker) + 1:])
            except Exception as e:
                return {"error": "bad probe JSON: " + err(e)}
    return {"error": (r.get("error") or (r.get("stderr") or "")[-800:] or "no probe output"), "exit": r.get("exit")}


def section_envs(cands, out):
    res = {}
    workdir = Path(out) / "probe_cwd"
    workdir.mkdir(exist_ok=True)
    env = contained_env(out)
    for name, py in cands.items():
        item = {"path": py, "exists": os.path.exists(py)}
        if item["exists"]:
            try:
                st = os.stat(py)
                item.update({"realpath": os.path.realpath(py), "owner_uid": st.st_uid, "owner": owner(st.st_uid),
                             "executable_by_me": os.access(py, os.X_OK)})
            except OSError as e:
                item["stat_error"] = err(e)
            if item.get("executable_by_me"):
                item["modes"] = {}
                for mode, flags in MODES.items():
                    r = run_cmd([py, *flags, "-c", ENV_PROBE], timeout=240, cwd=str(workdir), env=env)
                    p = parse_probe(r, "ENV_PROBE_JSON")
                    if "error" in p:
                        p["stderr_tail"] = redact((r.get("stderr") or "")[-600:])
                    item["modes"][mode] = redact_obj(p)
        res[name] = item
    return res


def section_user_site(envs):
    paths = []
    for e in envs.values():
        p = ((e.get("modes") or {}).get("normal") or {})
        us = p.get("user_site")
        if isinstance(us, str) and us.startswith("/") and us not in paths:
            paths.append(us)
    res = {}
    for us in paths:
        d = Path(us)
        item = {"exists": d.is_dir()}
        if d.is_dir():
            dists, pth, dirs = [], {}, []
            try:
                for e in sorted(d.iterdir())[:2000]:
                    if e.name.endswith((".dist-info", ".egg-info", ".egg-link")):
                        dists.append([e.name, iso(e.stat().st_mtime)])
                    elif e.suffix == ".pth" and e.is_file():
                        try:
                            pth[e.name] = [redact(l)[:200] for l in e.read_text(errors="replace").splitlines()[:5]]
                        except OSError as x:
                            pth[e.name] = [err(x)]
                    elif e.is_dir():
                        dirs.append(e.name)
            except OSError as x:
                item["error"] = err(x)
            item.update({"dists": dists[:500], "n_dists": len(dists), "pth": pth, "dirs": dirs[:300]})
        res[us] = item
    return res


def section_shell(home):
    res = {"env": {}, "dotfiles": {}}
    for k in ENV_VARS:
        v = os.environ.get(k)
        res["env"][k] = None if v is None else redact(v)[:600]
    for name in DOTFILES:
        p = Path(home) / name
        if p.is_file():
            try:
                lines = p.read_text(errors="replace").splitlines()
            except OSError as e:
                res["dotfiles"][name] = {"error": err(e)}
                continue
            hits = [[i + 1, redact(l.rstrip())[:300]] for i, l in enumerate(lines) if DOTFILE_RE.search(l)]
            res["dotfiles"][name] = {"lines": len(lines), "matches": hits[:80]}
    return res


# ----------------------------------------------------------------------------- F. compatibility
COMPAT_PROBE = r'''
import importlib, importlib.util, json, os, sys, time, traceback
sys.dont_write_bytecode = True
repo, files_json, fix_dir, out_json, fixtures_json = sys.argv[1:6]
res = {"python": sys.version.split()[0], "executable": sys.executable, "no_user_site": sys.flags.no_user_site,
       "sys_path": sys.path[:30]}
def short(e):
    return (type(e).__name__ + ": " + str(e))[:600]
def save():
    with open(out_json, "w") as fh:
        fh.write(json.dumps(res, indent=1, default=str))
files = json.load(open(files_json))
fails, t0 = [], time.time()
for rel in files:
    p = os.path.join(repo, rel)
    try:
        with open(p, "rb") as fh:
            src = fh.read()
        compile(src, p, "exec", dont_inherit=True)
    except SyntaxError as e:
        fails.append([rel, e.lineno, str(e.msg)[:200]])
    except Exception as e:
        fails.append([rel, None, short(e)])
res["compile"] = {"files": len(files), "n_failures": len(fails), "failures": fails[:300], "seconds": round(time.time() - t0, 1)}
save()
pk = {}
for m in ("torch", "transformers", "datasets", "accelerate", "numpy"):
    try:
        mod = importlib.import_module(m)
        pk[m] = [getattr(mod, "__version__", "?"), getattr(mod, "__file__", None)]
    except BaseException as e:
        pk[m] = ["error", short(e)]
res["packages"] = pk
save()
runner = os.path.join(repo, "scripts", "run_controller_ablation.py")
t0 = time.time()
try:
    spec = importlib.util.spec_from_file_location("lerna_step5_compat_runner", runner)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    res["runner_import"] = {"ok": True, "seconds": round(time.time() - t0, 1),
                            "model_loader_available": getattr(mod, "_MODEL_LOADER_AVAILABLE", None)}
except BaseException as e:
    res["runner_import"] = {"ok": False, "error": short(e), "traceback": traceback.format_exc()[-2500:]}
    save()
    print("COMPAT_DONE")
    sys.exit(0)
lm = sys.modules.get("lerna")
res["lerna_file"] = getattr(lm, "__file__", None)
try:
    importlib.import_module("lerna.utils.model_loader")
    res["model_loader_import"] = "ok"
except BaseException as e:
    res["model_loader_import"] = short(e)
save()
fx = json.loads(fixtures_json)
res["fixtures"] = {}
for name, over in fx["cases"]:
    kw = dict(fx["base"])
    kw.update(over)
    kw["output_dir"] = os.path.join(fix_dir, name)
    kw["attempt_id"] = name
    t0 = time.time()
    try:
        cfg = mod.ExperimentConfig(**kw)
        r = mod.run_execution(cfg)
        r = r if isinstance(r, dict) else {"status": "NOT_A_DICT", "reason": repr(r)[:300]}
        inner = r.get("result") if isinstance(r.get("result"), dict) else {}
        item = {"status": r.get("status"), "reason": (str(r.get("reason"))[:600] if r.get("reason") else None),
                "failure_stage": r.get("failure_stage"), "error": (str(r.get("error"))[:600] if r.get("error") else None),
                "keys": sorted(r.keys())[:40],
                "result_numbers": {k: v for k, v in list(inner.items())[:80]
                                   if isinstance(v, (int, float)) and not isinstance(v, bool)}}
    except BaseException as e:
        item = {"status": "EXCEPTION", "error": short(e), "traceback": traceback.format_exc()[-2500:]}
    item["seconds"] = round(time.time() - t0, 2)
    res["fixtures"][name] = item
    save()
print("COMPAT_DONE")
'''


def section_compat(repo, cands, names, out):
    """Each candidate twice: as Step 5 should start it (-s, PYTHONPATH unset) and as it starts normally."""
    res = {}
    cdir = Path(out) / "compat"
    cdir.mkdir(exist_ok=True)
    ls = git(repo, "ls-files", "-z", "--", "*.py")
    files = [f for f in (ls.get("stdout") or "").split("\0") if f]
    (cdir / "files.json").write_text(json.dumps(files))
    probe = cdir / "compat_probe.py"
    probe.write_text(COMPAT_PROBE)
    clean = contained_env(out, clear_pythonpath=True)
    clean["PYTHONNOUSERSITE"] = "1"
    modes = {"no_user_site": (["-s", "-B"], clean), "normal": (["-B"], contained_env(out))}
    fixtures = json.dumps({"base": FIXTURE_BASE, "cases": FIXTURE_CASES})
    for name in names:
        py = cands.get(name)
        if not py or not os.path.exists(py) or not os.access(py, os.X_OK):
            res[name] = {"path": py, "error": "interpreter not found or not executable"}
            continue
        res[name] = {"path": py, "tracked_py_files": len(files), "modes": {}}
        for mode, (flags, env) in modes.items():
            wdir = cdir / name / mode
            fix_dir = wdir / "fixtures"
            fix_dir.mkdir(parents=True, exist_ok=True)
            out_json = wdir / "compat.json"
            t0 = time.time()
            r = run_cmd([py, *flags, str(probe), str(repo), str(cdir / "files.json"), str(fix_dir), str(out_json),
                         fixtures], timeout=900, cwd=str(wdir), env=env)
            item = {"exit": r.get("exit"), "seconds": round(time.time() - t0, 1), "error": r.get("error"),
                    "done_marker": "COMPAT_DONE" in (r.get("stdout") or ""),
                    "stderr_tail": redact((r.get("stderr") or "")[-1500:])}
            try:
                item["result"] = redact_obj(json.loads(out_json.read_text()))
            except Exception as e:
                item["result"] = {"error": "no compat.json: " + err(e)}
            res[name]["modes"][mode] = item
    return res


# ----------------------------------------------------------------------------- G. GPUs
def section_gpus():
    r = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,utilization.gpu,driver_version",
                 "--format=csv,noheader"], timeout=60)
    rows = []
    for line in (r.get("stdout") or "").splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 6:
            rows.append(dict(zip(("index", "name", "memory_total", "memory_used", "utilization", "driver"), parts)))
    return {"exit": r.get("exit"), "error": r.get("error"), "gpus": rows, "time": now()}


# ----------------------------------------------------------------------------- summary
def short(h, n=12):
    return (h or "")[:n] + ("…" if h and len(h) > n else "")


def fmt_stat(s, scale=1.0, digits=4, unit=""):
    if not s:
        return "-"
    txt = f"{s['mean'] * scale:.{digits}g}"
    if s["n"] > 1:
        txt += f" ({s['min'] * scale:.{digits}g}–{s['max'] * scale:.{digits}g})"
    return txt + unit + f" n={s['n']}"


def glance(rep):
    L = [f"AT A GLANCE ({VERSION})"]
    s0, s1 = rep.get("state_start") or {}, rep.get("state_end") or {}
    L.append(f" Read-only: HEAD {short(s0.get('head'))} at start, {short(s1.get('head'))} at end; porcelain entries "
             f"{s0.get('porcelain_entries')} at start, {s1.get('porcelain_entries')} at end; user {s0.get('user')} "
             f"(uid {s0.get('uid')})")
    co = rep.get("cohorts") or {}
    for root, item in (co.get("roots") or {}).items():
        L.append(f" Cohort {root}: exists {item.get('exists')}, results.json {item.get('results_files')}, "
                 f"parse errors {len(item.get('parse_errors') or [])}")
        for grp, g in sorted((item.get("groups") or {}).items()):
            n = g.get("num") or {}
            ms = [f"{k.split('.', 1)[-1] if '.' in k else 'ms'} {fmt_stat(v, digits=4)}" for k, v in n.items()
                  if k.startswith("ms_per_step")]
            wall = [fmt_stat(v, digits=4) for k, v in n.items() if k.startswith("wall_seconds")]
            L.append(f"   {grp}: n={g.get('n')} steps {fmt_stat(n.get('actual_steps_run'), digits=6)}; "
                     f"ms/step {'; '.join(ms) or '-'}; wall s {'; '.join(wall) or '-'}")
            L.append(f"     LR: final {fmt_stat(n.get('final_lr'), digits=3)}; shape {g.get('lr_shape')}; peak "
                     f"{g.get('lr_peak')} first reached at step {g.get('lr_peak_at')}")
            acc = n.get("eval.eval_accuracy")
            L.append(f"     accuracy {fmt_stat(acc, scale=100, digits=4, unit=' %')}"
                     + (f" sd {acc['sd'] * 100:.3f} pp" if acc and 'sd' in acc else "")
                     + f"; validation_passed {g.get('validation_passed')}; manifests {g.get('manifest_present')}")
    gi = rep.get("git") or {}
    refs = gi.get("refs") or {}
    L.append(f" Tag {TAG}: object {short(refs.get(TAG))}, commit {short(refs.get(TAG + '^{commit}'))}, PREREG blob "
             f"{short(refs.get(TAG + ':experiments/PREREG_V4.md'))} (HEAD blob {short(refs.get('HEAD:experiments/PREREG_V4.md'))})")
    for sha, o in (gi.get("objects") or {}).items():
        if o.get("type") == "commit":
            L.append(f"   {short(sha)}: commit {str(o.get('date'))[:19]} \"{str(o.get('subject'))[:60]}\"; contains tag "
                     f"{o.get('contains_tag')}; in HEAD history {o.get('in_head_history')}; gate files vs tag: "
                     f"{'same' if not o.get('gate_files_diff_vs_tag') else 'DIFFER'}")
        else:
            L.append(f"   {short(sha)}: {o.get('type')}")
    rc = rep.get("recipe") or {}
    L.append(" Recipe lines found: " + "; ".join(f"{k.split(':')[0][:8]}:{k.split(':', 1)[1].split('/')[-1]} {v.get('n')}"
                                                for k, v in (rc.get("lines") or {}).items() if v.get("n")))
    me = rep.get("mentions") or {}
    L.append(f" Files mentioning the cohorts: {len(me.get('hits') or [])} (scanned {me.get('scanned')})")
    for name, e in (rep.get("environments") or {}).items():
        if not e.get("exists"):
            L.append(f" python {name} ({e.get('path')}): NOT FOUND")
            continue
        L.append(f" python {name} ({e.get('path')}, owner {e.get('owner')}):")
        for mode, p in (e.get("modes") or {}).items():
            if "error" in p:
                L.append(f"   {mode}: probe failed (exit {p.get('exit')}: {' '.join(str(p.get('error')).split())[:120]})")
                continue
            pk = p.get("packages") or {}

            def v(m):
                x = pk.get(m) or {}
                return x.get("version") if "version" in x else "missing"

            tf = pk.get("transformers") or {}
            L.append(f"   {mode}: Python {p.get('python')}, torch {v('torch')} (CUDA {p.get('torch_cuda_build')}, arch "
                     f"{p.get('torch_arch_flags')}), transformers {v('transformers')} from {tf.get('file')}, datasets "
                     f"{v('datasets')}, accelerate {v('accelerate')}, pytest {v('pytest')}, lerna "
                     f"{(pk.get('lerna') or {}).get('file') or 'missing'}, ModernBERT {p.get('has_ModernBertConfig')}, "
                     f"user site on {p.get('enable_user_site')}")
    for us, item in (rep.get("user_site") or {}).items():
        names = [d[0] for d in item.get("dists") or []]
        key = [x for x in names if re.match(r"(?i)(torch|transformers|datasets|accelerate|tokenizers|huggingface_hub|"
                                            r"numpy|safetensors|lerna)[-_]", x)]
        L.append(f" User site {us}: exists {item.get('exists')}, {item.get('n_dists', 0)} distributions; key: {key}; "
                 f".pth files {list((item.get('pth') or {}).keys())}")
    sh = rep.get("shell") or {}
    L.append(" Env: " + "; ".join(f"{k}={v[:80]}" for k, v in (sh.get("env") or {}).items()
                                  if v is not None and k not in ("PATH", "LD_LIBRARY_PATH")))
    L.append(" Shell startup lines: " + ", ".join(f"{k} {len(v.get('matches') or [])}"
                                                  for k, v in (sh.get("dotfiles") or {}).items()))
    labels = {"no_user_site": "-s, PYTHONPATH unset", "normal": "normal start"}
    for name, cc in (rep.get("compat") or {}).items():
        if cc.get("error"):
            L.append(f" Compat {name}: {cc.get('error')}")
            continue
        for mode, c in (cc.get("modes") or {}).items():
            r = c.get("result") or {}
            tag = f" Compat {name} ({labels.get(mode, mode)})"
            if "compile" not in r:
                L.append(f"{tag}: exit {c.get('exit')}, no result ({' '.join(str(r.get('error') or c.get('error')).split())[:160]}; "
                         f"stderr: {' '.join(str(c.get('stderr_tail') or '').split())[-160:]})")
                continue
            comp = r.get("compile") or {}
            ri = r.get("runner_import") or {}
            fx = r.get("fixtures") or {}
            pk = r.get("packages") or {}
            L.append(f"{tag}: exit {c.get('exit')}, {c.get('seconds')} s; compile failures "
                     f"{comp.get('n_failures')}/{comp.get('files')}; torch {(pk.get('torch') or ['?'])[0]}, transformers "
                     f"{(pk.get('transformers') or ['?'])[0]}; runner import {ri.get('ok')}"
                     + (f" ({str(ri.get('error'))[:160]})" if ri.get("ok") is False else
                        f", model_loader {ri.get('model_loader_available')}, lerna from {r.get('lerna_file')}"))
            if fx:
                L.append("   fixtures: " + "; ".join(f"{k} {v.get('status')}" + (f" [{str(v.get('reason') or v.get('error'))[:100]}]"
                                                                                if v.get("status") != "OK" else "")
                                                   for k, v in fx.items()))
            if comp.get("failures"):
                L.append("   compile failures: " + "; ".join(f"{f[0]}:{f[1]} {f[2][:60]}" for f in comp["failures"][:6]))
    g = rep.get("gpus") or {}
    if g.get("gpus"):
        L.append(" GPUs: " + "; ".join(f"{x['index']} {x['memory_used']} used, {x['utilization']}" for x in g["gpus"]))
    else:
        L.append(f" GPUs: nvidia-smi gave nothing (exit {g.get('exit')}, {g.get('error')})")
    L.append(f" Possible secrets redacted: {rep.get('redactions', 0)}")
    if rep.get("section_errors"):
        L.append(f" SECTION ERRORS: {', '.join(rep['section_errors'])}")
    return L


def summary_lines(rep):
    L = glance(rep)
    co = rep.get("cohorts") or {}
    for root, item in (co.get("roots") or {}).items():
        L += ["", f"{root}: top level {list((item.get('top_level') or {}).keys())[:30]}"]
        for grp, g in sorted((item.get("groups") or {}).items()):
            s = g.get("sample") or {}
            L.append(f"  {grp}: arms {g.get('arms')}; seeds {g.get('seeds')}")
            L.append(f"    sample {s.get('file')} ({str(s.get('mtime'))[:19]}): ms_per_step {s.get('ms_per_step')}; "
                     f"wall {s.get('wall_seconds')}; final_lr {s.get('final_lr')}; lr_history {s.get('lr_history_type')} "
                     f"len {s.get('lr_history_len')}")
            ls = s.get("lr_summary") or {}
            L.append(f"    lr summary: {json.dumps({k: ls.get(k) for k in ('shape', 'first', 'peak', 'peak_reached_at', 'last', 'dev_linear', 'dev_cosine', 'samples')})[:600]}")
            L.append(f"    provenance: {json.dumps(g.get('provenance'))[:500]}")
            if g.get("manifest"):
                L.append(f"    manifest: {json.dumps(g.get('manifest'))[:700]}")
    gi = rep.get("git") or {}
    L += ["", f"Prereg tags: {gi.get('prereg_tags')}"]
    for sha, o in (gi.get("objects") or {}).items():
        L.append(f"  {sha}: {json.dumps(o)[:700]}")
    rc = rep.get("recipe") or {}
    for k, v in (rc.get("lines") or {}).items():
        if v.get("n"):
            L += ["", f"Recipe lines {k} ({v.get('n')}):"]
            L += [f"  {n:>5}: {t}" for n, t in (v.get("lines") or [])[:120]]
    me = rep.get("mentions") or {}
    L += ["", "Files mentioning the cohorts:"]
    for h in (me.get("hits") or [])[:80]:
        L.append(f"  {h['file']} ({h['count']}): " + " | ".join(f"{n}: {t[:120]}" for n, t in h["lines"][:2]))
    for us, item in (rep.get("user_site") or {}).items():
        L += ["", f"User site {us}:"]
        L += [f"  {d[0]} ({d[1][:10]})" for d in (item.get("dists") or [])[:120]]
        for k, v in (item.get("pth") or {}).items():
            L.append(f"  .pth {k}: {v}")
    sh = rep.get("shell") or {}
    for k, v in (sh.get("dotfiles") or {}).items():
        L += ["", f"~/{k}:"]
        L += [f"  {n:>4}: {t}" for n, t in (v.get("matches") or [])]
    for name, cc in (rep.get("compat") or {}).items():
        for mode, c in (cc.get("modes") or {}).items():
            r = c.get("result") or {}
            ri = r.get("runner_import") or {}
            if ri.get("ok") is False:
                L += ["", f"Compat {name} {mode} runner import traceback:", ri.get("traceback") or ""]
            for k, v in (r.get("fixtures") or {}).items():
                if v.get("status") != "OK":
                    L += ["", f"Compat {name} {mode} fixture {k}: {json.dumps(v)[:2500]}"]
    return L


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cohort-root", action="append", default=None)
    ap.add_argument("--python", action="append", default=None, metavar="NAME=PATH",
                    help="replace the candidate interpreters (repeatable)")
    ap.add_argument("--compat", default=None, help="comma-separated candidate names for the compatibility check")
    ap.add_argument("--home", default=str(Path.home()))
    a = ap.parse_args()
    repo, out = Path(a.repo).resolve(), Path(a.out).resolve()
    if not (repo / RUNNER_REL).is_file():
        print(f"--repo {repo} does not look like the LERNA checkout", file=sys.stderr)
        return 2
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if out == repo or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    cands = dict(CANDIDATES)
    if a.python:
        cands = {}
        for spec in a.python:
            if "=" not in spec:
                print(f"--python {spec}: expected NAME=PATH", file=sys.stderr)
                return 2
            k, v = spec.split("=", 1)
            cands[k] = v
    compat_names = [x for x in (a.compat.split(",") if a.compat else COMPAT_DEFAULT) if x]
    out.mkdir(parents=True)
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "python": sys.version, "section_errors": {},
           "candidates": cands, "compat_names": compat_names}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e), "traceback": traceback.format_exc()[-3000:]}
            rep["section_errors"][name] = err(e)
        rep.setdefault("seconds", {})[name] = round(time.time() - t0, 1)
        save()
        print(f"[{now()}] {name} done in {rep['seconds'][name]} s", flush=True)

    section("state_start", section_state, repo)
    section("cohorts", section_cohorts, a.cohort_root or COHORT_ROOTS)
    section("git", section_git, repo, (rep.get("cohorts") or {}).get("shas") or [])
    section("recipe", section_recipe, repo, rep.get("git") or {})
    section("mentions", section_mentions, repo)
    section("environments", section_envs, cands, out)
    section("user_site", section_user_site, rep.get("environments") or {})
    section("shell", section_shell, a.home)
    section("compat", section_compat, repo, cands, compat_names, out)
    section("gpus", section_gpus)
    section("state_end", section_state, repo)
    rep["redactions"] = REDACTIONS[0]
    rep["finished"] = now()
    save()
    (out / "SUMMARY.txt").write_text("\n".join(summary_lines(rep)) + "\n")
    print("\n".join(glance(rep)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

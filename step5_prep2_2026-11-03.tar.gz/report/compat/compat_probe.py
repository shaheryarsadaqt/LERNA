
import importlib, importlib.util, json, os, sys, time, traceback
sys.dont_write_bytecode = True
repo, files_json, fix_dir, out_json, fixtures_json = sys.argv[1:6]
res = {"python": sys.version.split()[0], "executable": sys.executable, "no_user_site": sys.flags.no_user_site,
       "sys_path": sys.path[:30]}
def short(e):
    return (type(e).__name__ + ": " + str(e))[:600]
def save():
    with open(out_json, "w") as fh:
        fh.write(json.dumps(res, indent=1, default=str))
files = json.load(open(files_json))
fails, t0 = [], time.time()
for rel in files:
    p = os.path.join(repo, rel)
    try:
        with open(p, "rb") as fh:
            src = fh.read()
        compile(src, p, "exec", dont_inherit=True)
    except SyntaxError as e:
        fails.append([rel, e.lineno, str(e.msg)[:200]])
    except Exception as e:
        fails.append([rel, None, short(e)])
res["compile"] = {"files": len(files), "n_failures": len(fails), "failures": fails[:300], "seconds": round(time.time() - t0, 1)}
save()
pk = {}
for m in ("torch", "transformers", "datasets", "accelerate", "numpy"):
    try:
        mod = importlib.import_module(m)
        pk[m] = [getattr(mod, "__version__", "?"), getattr(mod, "__file__", None)]
    except BaseException as e:
        pk[m] = ["error", short(e)]
res["packages"] = pk
save()
runner = os.path.join(repo, "scripts", "run_controller_ablation.py")
t0 = time.time()
try:
    spec = importlib.util.spec_from_file_location("lerna_step5_compat_runner", runner)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    res["runner_import"] = {"ok": True, "seconds": round(time.time() - t0, 1),
                            "model_loader_available": getattr(mod, "_MODEL_LOADER_AVAILABLE", None)}
except BaseException as e:
    res["runner_import"] = {"ok": False, "error": short(e), "traceback": traceback.format_exc()[-2500:]}
    save()
    print("COMPAT_DONE")
    sys.exit(0)
lm = sys.modules.get("lerna")
res["lerna_file"] = getattr(lm, "__file__", None)
try:
    importlib.import_module("lerna.utils.model_loader")
    res["model_loader_import"] = "ok"
except BaseException as e:
    res["model_loader_import"] = short(e)
save()
fx = json.loads(fixtures_json)
res["fixtures"] = {}
for name, over in fx["cases"]:
    kw = dict(fx["base"])
    kw.update(over)
    kw["output_dir"] = os.path.join(fix_dir, name)
    kw["attempt_id"] = name
    t0 = time.time()
    try:
        cfg = mod.ExperimentConfig(**kw)
        r = mod.run_execution(cfg)
        r = r if isinstance(r, dict) else {"status": "NOT_A_DICT", "reason": repr(r)[:300]}
        inner = r.get("result") if isinstance(r.get("result"), dict) else {}
        item = {"status": r.get("status"), "reason": (str(r.get("reason"))[:600] if r.get("reason") else None),
                "failure_stage": r.get("failure_stage"), "error": (str(r.get("error"))[:600] if r.get("error") else None),
                "keys": sorted(r.keys())[:40],
                "result_numbers": {k: v for k, v in list(inner.items())[:80]
                                   if isinstance(v, (int, float)) and not isinstance(v, bool)}}
    except BaseException as e:
        item = {"status": "EXCEPTION", "error": short(e), "traceback": traceback.format_exc()[-2500:]}
    item["seconds"] = round(time.time() - t0, 2)
    res["fixtures"][name] = item
    save()
print("COMPAT_DONE")

#!/usr/bin/env python3
"""LERNA round 15: checks and the pre-specified comparison and ablation tables. Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, SMOKE_GATE.json, runs/), round 14's and
round 13's development folders (--r14, --r13) and the Step 5 main study's folder (--step5), and
writes only check_report.json and CHECK_SUMMARY.txt into the launcher's folder. Exit 0 means the
report was written; the verdict is inside it. Exit 2 means the folder isn't a finished launcher
folder.

Per new run (268), it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, revisions, device, and
    each method's own options (LERNA v2 0.1 / 64 / 16 and its selection mode; InfoBatch 0.5 / 0.875,
    or 0.9 / 1.0 for its most aggressive setting);
  - the exact counts (forward and backward passes, skips, updates, scheduler steps, warmup) and a
    final LR of 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases, attention,
    AdamW betas and eps, the pinned GPU;
  - the batch log (9 fields per row) and each policy's own accounting against it; for LERNA v2
    and hard top-k: nothing dropped in the warmup and the spent compute within 0.005 of the budget;
  - that every example-selection run trained on full fine-tuning's scheduled batches, row for row.
It also checks the comparators it reads (round 13's and round 14's runs, which their own checks
must have passed, and Step 5's QNLI runs), and the three reproductions of round 14, bit for bit.

Then it runs the reading fixed in claude/LERNA_R15_COMPARISON_PLAN_2026-11-06.md over the ten seeds
11, 13, 17, 19, 23, 29, 31, 37, 41 and 43:
  - measured compute = (forward padded tokens + 2 x updated padded tokens) / the same for full
    fine-tuning of the same task and seed; the plain-run curve per task and seed; each method's gap
    to it;
  - THE MAIN COMPARISON TABLE: LERNA v2 against each compared method, paired by seed, with the
    mean, the 95% t-interval, the paired-t p-value, Holm's adjustment over the table's eleven rows
    per task, and the number of seeds favouring LERNA v2. A row reads EDGE if the adjusted p is
    below 0.05 and the mean is above 0, LOSS if the adjusted p is below 0.05 and the mean is below
    0, and otherwise no significant difference;
  - THE ABLATIONS: the 2 x 2 factorial at 35% (scores x learning-rate factor), v2 against random
    keep at 35, 40, 60 and 83%, soft sampling against hard top-k at 35%, budget exactness, and
    wall-clock time.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R15_DEV_CHECK 2026-11-06"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
OLD_SEEDS = (11, 13, 17, 19, 23)
NEW_SEEDS = (29, 31, 37, 41, 43)
ALL_SEEDS = OLD_SEEDS + NEW_SEEDS
TASKS = ("qnli", "sst-2")
SHORT = {"qnli": "qnli", "sst-2": "sst2"}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349}
BATCH_SIZE = 32
HORIZON = {"qnli": 6548, "sst-2": 4210}
RATE = 0.60
PLAIN_FRACTIONS = {"plain_030": 0.30, "plain_050": 0.50, "plain_070": 0.70}
# arm: (budget, scores, learning-rate factor)
LERNA2 = {"lerna2_b035": (0.35, True, True), "lerna2_nolr_b035": (0.35, True, False),
          "randkeep_lr_b035": (0.35, False, True), "randkeep_b035": (0.35, False, False),
          "lerna2_b040": (0.40, True, True), "randkeep_b040": (0.40, False, False),
          "lerna2_b060": (0.60, True, True), "lerna2_b083": (0.83, True, True),
          "randkeep_b060": (0.60, False, False), "randkeep_b083": (0.83, False, False),
          "el2n_topk_b035": (0.35, True, False), "el2n_topk_b060": (0.60, True, False)}
TOPK = ("el2n_topk_b035", "el2n_topk_b060")
LERNA2_OPTIONS = {"lerna2_pi_min": 0.1, "lerna2_window": 64, "lerna2_chunks": 16}
INFOBATCH_OPTIONS = {"infobatch": (0.5, 0.875), "infobatch_max": (0.9, 1.0)}
SKIP_GATES = ("gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "stale_s1_p4")
BUDGET_TOLERANCE = 0.005
CURVE_ARMS = ("plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070", "full_finetune")
STEP5_HORIZON = 6548
# comparators by source: Step 5 (QNLI, all ten seeds), round 13 and round 14 (the old seeds)
STEP5_QNLI = ("full_finetune", "reduced_steps", "equal_compute", "gate_s1_p4", "control_uniform_p4", "gate_loss_p4")
R13_ARMS = {"qnli": ("plain_030", "plain_050", "plain_070", "infobatch", "stale_s1_p4"),
            "sst-2": ("full_finetune", "reduced_steps", "equal_compute", "plain_030", "plain_050", "plain_070",
                      "infobatch", "stale_s1_p4", "gate_s1_p4", "control_uniform_p4")}
R14_ARMS = ("lerna2_b035", "lerna2_nolr_b035", "randkeep_lr_b035", "randkeep_b035",
            "lerna2_b040", "randkeep_b040", "lerna2_b060", "lerna2_b083")
REPRO = {"repro_qnli_lerna2_b035_seed11": "qnli_lerna2_b035_seed11",
         "repro_sst2_lerna2_b035_seed11": "sst2_lerna2_b035_seed11",
         "repro_sst2_randkeep_b035_seed11": "sst2_randkeep_b035_seed11"}
METHODS = ("lerna2_b035", "lerna2_b040", "lerna2_b060", "lerna2_b083", "lerna2_nolr_b035", "randkeep_lr_b035",
           "randkeep_b035", "randkeep_b040", "randkeep_b060", "randkeep_b083", "el2n_topk_b035", "el2n_topk_b060",
           "infobatch", "infobatch_max", "stale_s1_p4", "gate_s1_p4", "control_uniform_p4", "gate_loss_p4")
LABEL = {"lerna2_b035": "LERNA v2, 35%", "lerna2_b040": "LERNA v2, 40%", "lerna2_b060": "LERNA v2, 60%",
         "lerna2_b083": "LERNA v2, 83%", "lerna2_nolr_b035": "v2 without LR factor, 35%",
         "randkeep_lr_b035": "random keep + LR factor, 35%", "randkeep_b035": "random keep, 35%",
         "randkeep_b040": "random keep, 40%", "randkeep_b060": "random keep, 60%", "randkeep_b083": "random keep, 83%",
         "el2n_topk_b035": "dynamic EL2N top-k, 35%", "el2n_topk_b060": "dynamic EL2N top-k, 60%",
         "infobatch": "InfoBatch (r 0.5)", "infobatch_max": "InfoBatch, most aggressive (r 0.9)",
         "stale_s1_p4": "M1, stale-score LERNA", "gate_s1_p4": "LERNA v1 (batch skipping)",
         "control_uniform_p4": "random batch skipping", "gate_loss_p4": "max-loss batch skipping",
         "full_finetune": "full fine-tuning", "reduced_steps": "plain run, 40%", "equal_compute": "plain run, 60%"}
# THE MAIN COMPARISON TABLE: (key, LERNA v2 arm, compared method)
MAIN = [("vs_lerna_v1", "lerna2_b060", "gate_s1_p4"),
        ("vs_random_skipping", "lerna2_b060", "control_uniform_p4"),
        ("vs_maxloss_skipping", "lerna2_b060", "gate_loss_p4"),
        ("vs_m1", "lerna2_b040", "stale_s1_p4"),
        ("vs_infobatch", "lerna2_b083", "infobatch"),
        ("vs_infobatch_max", "lerna2_b060", "infobatch_max"),
        ("vs_el2n_topk_35", "lerna2_b035", "el2n_topk_b035"),
        ("vs_el2n_topk_60", "lerna2_b060", "el2n_topk_b060"),
        ("vs_plain_40", "lerna2_b040", "reduced_steps"),
        ("vs_plain_60", "lerna2_b060", "equal_compute"),
        ("vs_full", "lerna2_b083", "full_finetune")]
# THE ABLATIONS: (key, a, b) as a - b, or the 2 x 2 contrasts
ABLATIONS = [("v2_minus_randkeep_35", "lerna2_b035", "randkeep_b035"),
             ("v2_minus_randkeep_40", "lerna2_b040", "randkeep_b040"),
             ("v2_minus_randkeep_60", "lerna2_b060", "randkeep_b060"),
             ("v2_minus_randkeep_83", "lerna2_b083", "randkeep_b083"),
             ("soft_minus_hard_35", "lerna2_nolr_b035", "el2n_topk_b035")]
T975 = {1: 12.706204736432095, 2: 4.302652729696142, 3: 3.182446305284263, 4: 2.7764451051977987,
        5: 2.570581835636314, 6: 2.4469118511449692, 7: 2.3646242515927844, 8: 2.306004135204166,
        9: 2.2621571628540993}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    """Compute units from batch-log rows of either format (6 or 9 fields)."""
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm in ("full_finetune", "infobatch") or arm in LERNA2:
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm in PLAIN_FRACTIONS:
        eff, skips = int(round(PLAIN_FRACTIONS[arm] * T)), 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def _betacf(a, b, x):
    """Continued fraction for the regularized incomplete beta function (Lentz's method)."""
    tiny, eps = 1e-300, 1e-15
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def betainc(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x)
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbeta) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbeta) * _betacf(b, a, 1.0 - x) / b


def t_two_sided_p(t, df):
    return betainc(df / 2.0, 0.5, df / (df + t * t))


def holm(pvals):
    """Holm's step-down adjustment; None entries stay None."""
    idx = [i for i, p in enumerate(pvals) if isinstance(p, (int, float))]
    order = sorted(idx, key=lambda i: pvals[i])
    m = len(order)
    adj = [None] * len(pvals)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * pvals[i]))
        adj[i] = running
    return adj


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def summarize(values):
    """values: {seed: number or note}. Mean, SD, t-interval, paired-t p-value, positives."""
    vals = [g for g in values.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0), "by_seed": values}
    if n >= 2 and sd is not None and (n - 1) in T975:
        half = T975[n - 1] * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
        if sd > 0:
            out["p"] = t_two_sided_p(m / (sd / math.sqrt(n)), n - 1)
    return out


def curve_at(points, c):
    pts = sorted(points)
    if len(pts) < 2 or c < pts[0][0] - 1e-12 or c > pts[-1][0] + 1e-12:
        return None
    for (c0, a0), (c1, a1) in zip(pts, pts[1:]):
        if c0 - 1e-12 <= c <= c1 + 1e-12:
            return a0 if c1 == c0 else a0 + (a1 - a0) * (c - c0) / (c1 - c0)
    return None


def check_run(p, end, out):
    name, task, arm, seed = p["name"], p["task"], p["arm"], p["seed"]
    label = p.get("label", arm)
    T = p["total_steps"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "task": task, "arm": arm, "label": label, "seed": seed, "total_steps": T}
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, T)
    eff = exp["effective_total"]
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", T),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"] if task == "qnli" else None)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm in LERNA2:
        for k, v in LERNA2_OPTIONS.items():
            need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        want = INFOBATCH_OPTIONS.get(label)
        need(want is not None and (c.get("infobatch_prune_ratio"), c.get("infobatch_anneal_fraction")) == want,
             f"InfoBatch options {c.get('infobatch_prune_ratio')}, {c.get('infobatch_anneal_fraction')} for {label}")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == eff - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == eff, f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    if arm != "stale_s1_p4":
        need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm != "infobatch" and arm not in LERNA2:
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if ok_shape and rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            free = [x for x in rows if int(x[6]) == 0]
            need(len(free) == fskip, f"batch log has {len(free)} forward-free skips, result {fskip}")
            need(all(int(x[4]) == 1 and x[5] == "nan" for x in free), "a forward-free row isn't a skip with a NaN loss")
            need(all(math.isfinite(float(x[5])) for x in rows if int(x[6]) == 1), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) <= int(x[8]) for x in rows),
                 "real tokens must be positive and at most the padded, and those at most the scheduled")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm != "infobatch" and arm not in LERNA2:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            if arm in LERNA2:
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows[:exp["warmup"]]), "an example dropped during the warmup")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    multi_epoch = bool(bpe) and eff > bpe
    if arm in LERNA2:
        budget, scores, lr = LERNA2[arm]
        mode = "topk" if arm in TOPK else "sample"
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            for k, want in (("policy", "lerna_budget"), ("selection", mode), ("budget", budget),
                            ("use_scores", scores), ("use_lr_weight", lr), ("pi_min", 0.1), ("window", 64),
                            ("chunks", 16), ("warmup_steps", exp["warmup"]), ("total_steps", T), ("steps_seen", T),
                            ("batches_per_epoch", bpe), ("num_examples", n_train), ("pruned_examples", dropped),
                            ("pruned_during_warmup", 0)):
                need(sel.get(k) == want, f"selection {k}={sel.get(k)!r}, expected {want!r}")
            rf = sel.get("realized_fraction")
            need(isinstance(rf, (int, float)) and abs(rf - budget) <= BUDGET_TOLERANCE,
                 f"spent {rf} of the scheduled compute, budget {budget} +/- {BUDGET_TOLERANCE}")
            need(dropped > 0, "no example dropped")
            if rows:
                need(sel.get("spent_units") == units_of(rows), "policy spent units differ from the batch log")
                need(sel.get("scheduled_units") == 3 * sum(int(x[8]) for x in rows),
                     "policy scheduled units differ from the batch log")
                need(sel.get("scheduled_examples") == sum(int(x[7]) for x in rows),
                     "policy scheduled examples differ from the batch log")
            need((sel.get("kept_examples") or 0) + (sel.get("pruned_examples") or 0) == sel.get("scheduled_examples"),
                 "kept + pruned differ from the scheduled examples")
            mw = sel.get("max_weight")
            cap = float(BATCH_SIZE) if mode == "topk" else 10.0
            need(isinstance(mw, (int, float)) and mw <= cap + 1e-9, f"max_weight={mw}")
            if mode == "topk":
                need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
    elif arm == "stale_s1_p4":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need((sel.get("stale_decisions") or 0) + (sel.get("fresh_decisions") or 0) == eff,
                 "stale + fresh decisions don't add up to the scheduled batches")
            need(sel.get("forward_skips") == fskip, "policy forward_skips differ from the result")
            if multi_epoch:
                need(fskip > 0, "no skip without a forward pass in a run longer than one epoch")
                need((sel.get("fresh_decisions") or 0) >= bpe, "fewer fresh decisions than one epoch of batches")
    elif arm == "infobatch":
        anneal = (INFOBATCH_OPTIONS.get(label) or (None, None))[1]
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict) and anneal is not None:
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
            need(sel.get("stop_prune_step") == int(math.floor(anneal * eff + 1e-9)), "stop_prune_step differs")
            need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
            need(len(sel.get("thresholds") or []) == math.ceil(eff / bpe), "one threshold per epoch expected")
            fb = sel.get("empty_batch_fallbacks")
            if label == "infobatch":
                # at r 0.5, a batch that loses every example has probability about 2e-10
                need(fb == 0, f"empty_batch_fallbacks={fb}")
            else:
                # at r 0.9 a batch can lose every example; the policy then keeps the whole batch
                need(isinstance(fb, int) and fb >= 0, f"empty_batch_fallbacks={fb}")
                facts["empty_batch_fallbacks"] = fb
            if multi_epoch:
                need(dropped > 0, "no example dropped in a run longer than one epoch")
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    facts.update(accuracy=acc, loss=loss, wall_seconds=r.get("wall_seconds"), forward_skipped=fskip,
                 examples_dropped=dropped, units=units_of(rows) if rows else None,
                 realized_fraction=(sel or {}).get("realized_fraction") if arm in LERNA2 else None)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def load_comparator(folder, run_dir_name, task, arm, seed, horizon, source, ok_flag):
    """A round-13, round-14 or Step 5 run, lightly re-checked (its own round's checker verified it)."""
    res = {"name": f"{source}:{run_dir_name}", "task": task, "arm": arm, "label": arm, "seed": seed,
           "fails": [], "facts": {}, "log_rows": []}
    if ok_flag is False:
        res["fails"].append(f"{source}'s own check did not pass this run")
    found = sorted((folder / "runs" / run_dir_name).rglob("execution_manifest.json"))
    if len(found) != 1:
        res["fails"].append(f"{len(found)} manifests found")
        res["ok"] = False
        return res
    m = json.loads(found[0].read_text())
    c, r = m.get("config", {}), m.get("result", {})
    if m.get("status") != "OK":
        res["fails"].append(f"status {m.get('status')}")
    for k, v in (("task", task), ("arm", arm), ("policy_seed", seed), ("total_steps", horizon)):
        if c.get(k) != v:
            res["fails"].append(f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch" and (c.get("infobatch_prune_ratio"), c.get("infobatch_anneal_fraction")) != (0.5, 0.875):
        res["fails"].append("InfoBatch comparator options are not 0.5 and 0.875")
    blf = m.get("batch_log_file") or {}
    lpath = found[0].parent / str(blf.get("file", "batch_log.csv"))
    rows = []
    if not lpath.is_file() or sha256_file(lpath) != blf.get("sha256"):
        res["fails"].append("batch log missing or its hash differs from the manifest")
    else:
        rows = read_log(lpath)[1]
    sel = r.get("selection") or {}
    res["facts"] = {"accuracy": r.get("final_eval_accuracy"), "loss": r.get("final_eval_loss"),
                    "wall_seconds": r.get("wall_seconds"), "units": units_of(rows) if rows else None,
                    "realized_fraction": sel.get("realized_fraction") if arm in LERNA2 else None}
    res["log_rows"] = rows
    res["ok"] = not res["fails"]
    return res


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True)
    ap.add_argument("--r14", required=True, help="round 14's development folder (.../LERNA_r14/dev)")
    ap.add_argument("--r13", required=True, help="round 13's development folder (.../LERNA_r13/dev)")
    ap.add_argument("--step5", required=True, help="the Step 5 main study's folder (.../LERNA_step5_main/main)")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    r14, r13, step5 = Path(a.r14).resolve(), Path(a.r13).resolve(), Path(a.step5).resolve()
    plan = json.loads((out / "plan.json").read_text())
    gate = json.loads((out / "SMOKE_GATE.json").read_text()) if (out / "SMOKE_GATE.json").is_file() else None
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    integrity_fails, comparator_issues = [], []
    if gate is None or not gate.get("pass"):
        integrity_fails.append("the smoke gate did not pass" if gate else "SMOKE_GATE.json missing")
    runs = [check_run(p, ends.get(p["name"]), out) for p in plan["plan"]]
    own = {}
    for tag, folder in (("r13", r13), ("r14", r14)):
        rp = folder / "check_report.json"
        if rp.is_file():
            rep = json.loads(rp.read_text())
            own[tag] = ({x["name"]: bool(x.get("ok")) for x in rep.get("runs", [])}, rep.get("integrity"))
            if rep.get("integrity") != "PASS":
                comparator_issues.append(f"{tag}'s own check reported integrity {rep.get('integrity')}")
        else:
            own[tag] = ({}, None)
            comparator_issues.append(f"{tag}'s check_report.json is missing: none of its runs is used")
    comps = []
    for s in ALL_SEEDS:
        for arm in STEP5_QNLI:
            comps.append(load_comparator(step5, f"{arm}_seed{s}", "qnli", arm, s, STEP5_HORIZON, "step5", None))
    for s in OLD_SEEDS:
        for task in TASKS:
            for arm in R13_ARMS[task]:
                nm = f"{SHORT[task]}_{arm}_seed{s}"
                comps.append(load_comparator(r13, nm, task, arm, s, HORIZON[task], "r13", own["r13"][0].get(nm, False)))
            for arm in R14_ARMS:
                nm = f"{SHORT[task]}_{arm}_seed{s}"
                comps.append(load_comparator(r14, nm, task, arm, s, HORIZON[task], "r14", own["r14"][0].get(nm, False)))
    # reproductions of round 14, bit for bit
    by_name = {x["name"]: x for x in runs}
    repro = {}
    for mine, theirs in REPRO.items():
        x = by_name.get(mine)
        y = next((c for c in comps if c["name"] == f"r14:{theirs}"), None)
        if x is None or not x.get("log_rows") or y is None or not y.get("log_rows"):
            repro[mine] = {"comparable": False}
            integrity_fails.append(f"reproduction of round 14's {theirs} not comparable")
            continue
        same = {"same_accuracy": y["facts"].get("accuracy") == x["facts"].get("accuracy"),
                "same_loss": y["facts"].get("loss") == x["facts"].get("loss"),
                "same_batch_log": y["log_rows"] == x["log_rows"]}
        repro[mine] = dict(comparable=True, **same)
        if not all(same.values()):
            integrity_fails.append(f"{mine} does not reproduce round 14's {theirs} bit for bit")
    for x in runs:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    for x in comps:
        if not x["ok"]:
            comparator_issues.append(f"{x['name']} left out: " + "; ".join(x["fails"][:3]))
    table = {}
    for x in comps + [x for x in runs if x["name"] not in REPRO]:
        table[(x["task"], x["label"], x["seed"])] = x
    # every example-selection run trained on full fine-tuning's scheduled batches, row for row
    same_batches = {}
    for x in runs:
        if (x["arm"] not in LERNA2 and x["arm"] != "infobatch") or not x.get("log_rows"):
            continue
        full = table.get((x["task"], "full_finetune", x["seed"]))
        frows = (full or {}).get("log_rows") or []
        same = (len(frows) == len(x["log_rows"])
                and all(int(fr[2]) == int(r[8]) and int(fr[3]) == int(r[7]) for fr, r in zip(frows, x["log_rows"])))
        same_batches[x["name"]] = same
        if not same:
            integrity_fails.append(f"{x['name']}: scheduled batches differ from full fine-tuning's")
    for x in runs + comps:
        full = table.get((x["task"], "full_finetune", x["seed"]))
        u, fu = x["facts"].get("units"), (full or {}).get("facts", {}).get("units")
        x["facts"]["compute"] = (u / fu) if (u and fu and full.get("ok")) else None
    analysis = {}
    for task in TASKS:
        curves = {}
        for s in ALL_SEEDS:
            pts = []
            for arm in CURVE_ARMS:
                x = table.get((task, arm, s))
                if x and x["ok"] and isinstance(x["facts"].get("compute"), (int, float)):
                    pts.append((x["facts"]["compute"], 100.0 * x["facts"]["accuracy"]))
            curves[s] = pts
        full_wall = mean_sd([table[(task, "full_finetune", s)]["facts"].get("wall_seconds") for s in ALL_SEEDS
                             if (task, "full_finetune", s) in table and table[(task, "full_finetune", s)]["ok"]])[0]

        def acc(label, s):
            x = table.get((task, label, s))
            return 100.0 * x["facts"]["accuracy"] if x and x["ok"] else None

        methods = {}
        for meth in METHODS:
            gaps, cs, walls, notes = {}, [], [], {}
            for s in ALL_SEEDS:
                x = table.get((task, meth, s))
                if not x or not x["ok"]:
                    notes[s] = "run missing or failed its checks"
                    continue
                c = x["facts"].get("compute")
                cs.append(c)
                walls.append(x["facts"].get("wall_seconds"))
                if len(curves[s]) < len(CURVE_ARMS):
                    notes[s] = f"curve has {len(curves[s])} of {len(CURVE_ARMS)} points"
                    continue
                cv = curve_at(curves[s], c) if isinstance(c, (int, float)) else None
                gaps[s] = "outside the curve" if cv is None else 100.0 * x["facts"]["accuracy"] - cv
            sm = summarize(gaps)
            accs = [acc(meth, s) for s in ALL_SEEDS]
            sm.update(mean_accuracy=mean_sd(accs)[0], sd_accuracy=mean_sd(accs)[1], mean_compute=mean_sd(cs)[0],
                      min_compute=min([v for v in cs if isinstance(v, (int, float))], default=None),
                      max_compute=max([v for v in cs if isinstance(v, (int, float))], default=None),
                      mean_wall_seconds=mean_sd(walls)[0],
                      wall_fraction=(mean_sd(walls)[0] / full_wall) if (full_wall and mean_sd(walls)[0]) else None,
                      notes=notes)
            methods[meth] = sm

        def paired(la, lb):
            vals = {}
            for s in ALL_SEEDS:
                va, vb = acc(la, s), acc(lb, s)
                if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                    vals[s] = va - vb
            return summarize(vals)

        main_rows = []
        for key, la, lb in MAIN:
            d = paired(la, lb)
            d.update(key=key, method=la, compared=lb,
                     compute_method=methods.get(la, {}).get("mean_compute"),
                     compute_compared=(methods.get(lb, {}).get("mean_compute") if lb in methods else
                                       mean_sd([(table.get((task, lb, s)) or {}).get("facts", {}).get("compute")
                                                for s in ALL_SEEDS])[0]))
            main_rows.append(d)
        adj = holm([r.get("p") for r in main_rows])
        for r_, pa in zip(main_rows, adj):
            r_["p_holm"] = pa
            if r_["n"] < 3 or pa is None:
                r_["reading"] = "too few seeds"
            elif pa < 0.05 and r_["mean"] > 0:
                r_["reading"] = "EDGE"
            elif pa < 0.05 and r_["mean"] < 0:
                r_["reading"] = "LOSS"
            else:
                r_["reading"] = "no significant difference"
        abl = {}
        for key, la, lb in ABLATIONS:
            abl[key] = paired(la, lb)

        def contrast(fn):
            vals = {}
            for s in ALL_SEEDS:
                try:
                    v = fn(s)
                except TypeError:
                    v = None
                if isinstance(v, (int, float)):
                    vals[s] = v
            return summarize(vals)

        abl["score_effect_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("randkeep_lr_b035", s))
                                                           + (acc("lerna2_nolr_b035", s) - acc("randkeep_b035", s))))
        abl["lr_factor_effect_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                               + (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s))))
        abl["interaction_35"] = contrast(lambda s: 0.5 * ((acc("lerna2_b035", s) - acc("lerna2_nolr_b035", s))
                                                          - (acc("randkeep_lr_b035", s) - acc("randkeep_b035", s))))
        budget_dev = {}
        for arm in LERNA2:
            devs = [abs(table[(task, arm, s)]["facts"]["realized_fraction"] - LERNA2[arm][0]) for s in ALL_SEEDS
                    if (task, arm, s) in table and table[(task, arm, s)]["ok"]
                    and isinstance(table[(task, arm, s)]["facts"].get("realized_fraction"), (int, float))]
            budget_dev[arm] = {"n": len(devs), "max_abs_deviation": max(devs) if devs else None}
        arms = {}
        for lab in sorted({k[1] for k in table if k[0] == task}):
            xs = [table[(task, lab, s)] for s in ALL_SEEDS if (task, lab, s) in table and table[(task, lab, s)]["ok"]]
            walls = [x["facts"].get("wall_seconds") for x in xs]
            arms[lab] = {"n": len(xs),
                         "mean_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[0],
                         "sd_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[1],
                         "mean_compute": mean_sd([x["facts"].get("compute") for x in xs])[0],
                         "mean_wall_seconds": mean_sd(walls)[0],
                         "wall_fraction": (mean_sd(walls)[0] / full_wall) if (full_wall and mean_sd(walls)[0]) else None}
        analysis[task] = {"methods": methods, "main": main_rows, "ablations": abl, "budget_exactness": budget_dev,
                          "arms": arms, "curves": {str(s): sorted(v) for s, v in curves.items()}}
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails,
              "comparator_issues": comparator_issues, "smoke_gate": gate,
              "own_checks": {k: v[1] for k, v in own.items()},
              "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "comparators_ok": sum(1 for x in comps if x["ok"]), "comparators_expected": len(comps),
              "reproduction": repro, "same_scheduled_batches": same_batches, "analysis": analysis,
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs],
              "comparators": [{k: v for k, v in x.items() if k != "log_rows"} for x in comps]}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    def ci_text(d):
        ci = d.get("ci95")
        return f"[{num(ci[0] if ci else None, '+.3f')}, {num(ci[1] if ci else None, '+.3f')}]"

    lines = [f"LERNA COMPARISON ROUND CHECK ({VERSION}): integrity {verdict}; "
             f"{report['runs_ok']} of {len(runs)} new runs and {report['comparators_ok']} of {len(comps)} "
             f"comparator runs pass; smoke gate {'passed' if gate and gate.get('pass') else 'NOT passed'}; "
             f"own checks: round 13 {own['r13'][1]}, round 14 {own['r14'][1]}",
             "  reproduction of round 14 (seed 11): " +
             ", ".join(f"{k}: {'identical' if all(v.get(z) for z in ('same_accuracy', 'same_loss', 'same_batch_log')) else 'DIFFERS'}"
                       if v.get("comparable") else f"{k}: not comparable" for k, v in repro.items()),
             f"  example-selection runs on full fine-tuning's scheduled batches: "
             f"{sum(1 for v in same_batches.values() if v)} of {len(same_batches)}"]
    for task in TASKS:
        an = analysis[task]
        lines.append(f"  {task}: THE MAIN COMPARISON TABLE (LERNA v2 minus the compared method, paired by seed; "
                     f"accuracy points)")
        for r_ in an["main"]:
            lines.append(f"    {LABEL[r_['method']]:<16} vs {LABEL.get(r_['compared'], r_['compared']):<34} "
                         f"n {r_['n']:>2}  mean {num(r_['mean'], '+.3f'):>7}  {ci_text(r_)}  "
                         f"p {num(r_.get('p'), '.4f')}  Holm {num(r_.get('p_holm'), '.4f')}  "
                         f"v2 ahead {r_['positive']} of {r_['n']}  compute {num(r_['compute_method'], '.3f')} vs "
                         f"{num(r_['compute_compared'], '.3f')}  -> {r_['reading']}")
        lines.append(f"  {task}: ABLATIONS (paired by seed; accuracy points)")
        for k, d in an["ablations"].items():
            lines.append(f"    {k:<26} n {d['n']:>2}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  "
                         f"p {num(d.get('p'), '.4f')}  positive {d['positive']} of {d['n']}")
        lines.append(f"  {task}: gap to the plain-run curve (mean, 95% t-interval, positive seeds), compute, wall/full")
        for meth in METHODS:
            d = an["methods"][meth]
            lines.append(f"    {LABEL[meth]:<36} n {d['n']:>2}  mean {num(d['mean'], '+.3f'):>7}  {ci_text(d)}  "
                         f"positive {d['positive']:>2} of {d['n']:>2}  compute {num(d['mean_compute'], '.3f')} "
                         f"({num(d['min_compute'], '.3f')}-{num(d['max_compute'], '.3f')})  "
                         f"wall {num(d['wall_fraction'], '.2f')}")
            for s, why in d["notes"].items():
                lines.append(f"      seed {s}: {why}")
        worst = max([v["max_abs_deviation"] for v in an["budget_exactness"].values()
                     if isinstance(v["max_abs_deviation"], (int, float))], default=None)
        lines.append(f"  {task}: budget exactness: largest |spent - budget| over every LERNA v2, random-keep and "
                     f"top-k run: {num(worst, '.5f')}")
    for msg in integrity_fails:
        lines.append(f"  FAIL: {msg}")
    for msg in comparator_issues:
        lines.append(f"  COMPARATOR: {msg}")
    lines.append("  The readings EDGE / LOSS / no significant difference use Holm's adjustment over the eleven rows")
    lines.append("  of each task's main table, at 0.05. Development tasks: a confirmation needs untouched tasks.")
    text = "\n".join(lines)
    (out / "CHECK_SUMMARY.txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

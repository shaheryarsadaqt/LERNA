#!/usr/bin/env python3
"""LERNA Step 5 preparation, round 5: environment probe (4 November 2026). Read-only.

Started by LERNA_STEP5_PREP5_CHECK.py, once per Python environment and mode. It writes
only its --out JSON file and its --scratch folder; the datasets cache it uses is the
private copy the driver points HF_DATASETS_CACHE at.

--mode cpu (GPUs hidden by the driver):
  versions    interpreter, flags, library versions and files, pytest
  integrity   every installed .py file of the main libraries against its RECORD hash
  layernorm   whether torch's nn.LayerNorm takes a bias argument
  modernbert  the installed ModernBERT source: hashes, and every nn.LayerNorm( line
  model       Ettin through the project's own loader: parameters, LayerNorm biases,
              loading warnings, encoder outputs on a fixed batch of 8 sentence pairs
  qnli        QNLI train and validation through datasets.load_dataset (glue, pinned
              revision), content hashes, the pinned parquet files, the probe exclusions
  runner      QNLI through the runner's own production loaders, collator and evaluator,
              with the probe exclusions; inference only, no optimizer, no backward
--mode gpu (exactly one GPU visible): CUDA facts, a small matmul, and the fixed batch on
  the GPU against the CPU result of the same process. Forward passes only.

Exit 0 means the JSON was written, whatever it found; exit 2 means bad arguments.
"""
import os
import sys

sys.dont_write_bytecode = True

import argparse
import base64
import datetime
import hashlib
import importlib
import importlib.metadata
import importlib.util
import inspect
import json
import logging
import time
import traceback
from pathlib import Path

VERSION = "LERNA_STEP5_PREP5_PROBE v1 (2026-11-04)"
PACKAGES = ("torch", "transformers", "datasets", "tokenizers", "huggingface_hub", "accelerate",
            "safetensors", "pyarrow", "numpy")
FIXED_PAIRS = [
    ("What is the capital of France?", "Paris is the capital and largest city of France."),
    ("How many legs does a spider have?", "Spiders have eight legs and two body segments."),
    ("When did the war end?", "The treaty was signed in the spring, ending years of conflict."),
    ("Who wrote the novel?", "The book was published anonymously in 1813."),
    ("What do bees produce?", "Honey bees make honey from the nectar of flowers."),
    ("Where is the museum located?", "It sits on the north bank of the river, near the old bridge."),
    ("Why is the sky blue?", "Shorter wavelengths of sunlight are scattered more by the atmosphere."),
    ("What is the boiling point of water?", "At sea level, water boils at 100 degrees Celsius."),
]


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def err(e):
    return f"{type(e).__name__}: {e}"[:1500]


def tb():
    return traceback.format_exc()[-4000:]


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def iso_mtime(p):
    st = Path(p).stat()
    f = lambda t: datetime.datetime.fromtimestamp(t).astimezone().isoformat(timespec="seconds")
    return {"mtime": f(st.st_mtime), "ctime": f(st.st_ctime), "size": st.st_size}


def rows_sha256(idx, question, sentence, label):
    """One canonical JSON line per row, in dataset order."""
    h = hashlib.sha256()
    n = 0
    for a, b, c, d in zip(idx, question, sentence, label):
        h.update(json.dumps([int(a), b, c, int(d)], ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
        h.update(b"\n")
        n += 1
    return h.hexdigest(), n


# --------------------------------------------------------------------------- cpu sections
def section_versions():
    d = {"python": sys.version, "executable": sys.executable, "prefix": sys.prefix,
         "flags": {"no_user_site": bool(sys.flags.no_user_site), "isolated": bool(getattr(sys.flags, "isolated", 0)),
                   "dont_write_bytecode": sys.dont_write_bytecode},
         "env": {k: os.environ.get(k) for k in ("PYTHONPATH", "PYTHONNOUSERSITE", "CUDA_VISIBLE_DEVICES", "HF_HOME",
                                                "HF_HUB_CACHE", "TRANSFORMERS_CACHE", "HF_DATASETS_CACHE",
                                                "HF_HUB_OFFLINE", "HF_DATASETS_OFFLINE", "TRANSFORMERS_OFFLINE")},
         "sys_path": list(sys.path)}
    try:
        import site
        d["user_site_enabled"] = site.ENABLE_USER_SITE
        d["user_site"] = site.getusersitepackages()
    except Exception as e:
        d["user_site_error"] = err(e)
    pk = {}
    for name in PACKAGES:
        try:
            m = importlib.import_module(name)
            pk[name] = {"version": getattr(m, "__version__", None), "file": getattr(m, "__file__", None)}
        except Exception as e:
            pk[name] = {"error": err(e)}
    d["packages"] = pk
    try:
        spec = importlib.util.find_spec("pytest")
        d["pytest"] = {"available": spec is not None,
                       "version": (importlib.metadata.version("pytest") if spec is not None else None),
                       "origin": (spec.origin if spec is not None else None)}
    except Exception as e:
        d["pytest"] = {"error": err(e)}
    try:
        import torch
        d["torch_extra"] = {"cuda_build": torch.version.cuda, "cuda_available": bool(torch.cuda.is_available()),
                            "num_threads": torch.get_num_threads()}
    except Exception as e:
        d["torch_extra"] = {"error": err(e)}
    return d


def section_integrity():
    """Compare every installed .py file with the hash its RECORD lists."""
    md = importlib.metadata
    res = {}
    for name in PACKAGES:
        r = {}
        try:
            dist = md.distribution(name)
        except Exception as e:
            res[name] = {"error": err(e)}
            continue
        r["version"] = dist.version
        r["dist_info"] = str(getattr(dist, "_path", None))
        try:
            mod = importlib.import_module(name)
            mod_file = Path(mod.__file__).resolve() if getattr(mod, "__file__", None) else None
        except Exception as e:
            mod_file = None
            r["import_error"] = err(e)
        files = dist.files or []
        checked = mismatch = missing = nohash = 0
        mism, miss = [], []
        covers_import = False
        for f in files:
            s = str(f)
            if not s.endswith(".py"):
                continue
            try:
                p = Path(f.locate()).resolve()
            except Exception:
                continue
            if mod_file is not None and p == mod_file:
                covers_import = True
            if f.hash is None:
                nohash += 1
                continue
            try:
                data = p.read_bytes()
            except OSError:
                missing += 1
                if len(miss) < 20:
                    miss.append(s)
                continue
            digest = base64.urlsafe_b64encode(hashlib.new(f.hash.mode, data).digest()).rstrip(b"=").decode()
            checked += 1
            if digest != f.hash.value:
                mismatch += 1
                if len(mism) < 100:
                    mism.append(s)
        r.update(py_files_checked=checked, mismatched=mismatch, missing=missing, without_hash=nohash,
                 mismatched_files=mism, missing_files=miss, record_covers_imported_module=covers_import,
                 imported_module_file=(str(mod_file) if mod_file else None))
        res[name] = r
    return res


def section_layernorm():
    import torch
    sig = inspect.signature(torch.nn.LayerNorm.__init__)
    return {"torch": torch.__version__, "init_parameters": list(sig.parameters),
            "accepts_bias_argument": "bias" in sig.parameters,
            "class_module": torch.nn.LayerNorm.__module__,
            "is_torch_class": torch.nn.LayerNorm is torch.nn.modules.normalization.LayerNorm}


def section_modernbert_source():
    import transformers
    d = Path(transformers.__file__).resolve().parent / "models" / "modernbert"
    res = {"transformers": transformers.__version__, "dir": str(d), "files": {}}
    for name in ("modeling_modernbert.py", "configuration_modernbert.py"):
        f = d / name
        if not f.is_file():
            res["files"][name] = "not found"
            continue
        lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
        e = {"path": str(f), "sha256": sha256_file(f), "lines": len(lines)}
        e.update(iso_mtime(f))
        e["layernorm_lines"] = [f"{i}: {l.strip()[:200]}" for i, l in enumerate(lines, 1) if "LayerNorm(" in l][:40]
        e["norm_bias_lines"] = [f"{i}: {l.strip()[:200]}" for i, l in enumerate(lines, 1) if "norm_bias" in l][:40]
        res["files"][name] = e
    return res


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.messages = []

    def emit(self, record):
        try:
            self.messages.append(record.getMessage()[:6000])
        except Exception:
            pass


def _load_model(repo):
    """The project's own loader, exactly as the round-3 check called it."""
    sys.path.insert(0, str(repo))
    import torch
    from lerna.utils import ettin_constants as ec
    from lerna.utils.model_loader import load_model_and_tokenizer
    cap = _Capture()
    lg = logging.getLogger("transformers")
    lg.addHandler(cap)
    try:
        torch.manual_seed(0)
        model, tok = load_model_and_tokenizer(ec.ETTIN_MODEL_ID, num_labels=2, revision=ec.ETTIN_REVISION,
                                              local_files_only=True)
    finally:
        lg.removeHandler(cap)
    model.eval()
    return model, tok, ec, cap.messages


def _fixed_batch(tok):
    return tok([q for q, _ in FIXED_PAIRS], [s for _, s in FIXED_PAIRS], padding=True, return_tensors="pt")


def _encoder_summary(model, batch, device):
    import torch
    ids = batch["input_ids"].to(device)
    am = batch["attention_mask"].to(device)
    with torch.no_grad():
        out = model.model(input_ids=ids, attention_mask=am)
        h = out.last_hidden_state.double()
        m = am.unsqueeze(-1).double()
        mean = (h * m).sum(1) / m.sum(1)
        first = h[:, 0, :]
        logits = model(input_ids=ids, attention_mask=am).logits.double()
    return {"finite": bool(torch.isfinite(h).all().item()), "hidden_shape": list(h.shape),
            "mean": mean.cpu().tolist(), "first": first.cpu().tolist(), "logits": logits.cpu().tolist()}


def section_model(repo):
    import torch
    t0 = time.time()
    model, tok, ec, warnings = _load_model(repo)
    res = {"ETTIN_MODEL_ID": ec.ETTIN_MODEL_ID, "ETTIN_REVISION": ec.ETTIN_REVISION, "class": type(model).__name__,
           "load_seconds": round(time.time() - t0, 1), "loading_warnings": warnings[:10]}
    res["parameters"] = int(sum(p.numel() for p in model.parameters()))
    lns = [(n, m) for n, m in model.named_modules() if isinstance(m, torch.nn.LayerNorm)]
    with_bias = [(n, m) for n, m in lns if getattr(m, "bias", None) is not None]
    res["layernorm_modules"] = len(lns)
    res["layernorm_with_bias"] = len(with_bias)
    res["layernorm_with_bias_names"] = [n for n, _ in with_bias][:60]
    res["layernorm_bias_max_abs"] = (max(float(m.bias.detach().abs().max()) for _, m in with_bias) if with_bias else None)
    res["layernorm_bias_trainable"] = (all(bool(m.bias.requires_grad) for _, m in with_bias) if with_bias else None)
    cfg = model.config
    res["config"] = {"norm_bias": getattr(cfg, "norm_bias", "absent"),
                     "reference_compile": str(getattr(cfg, "reference_compile", "absent")),
                     "attn_implementation": getattr(cfg, "_attn_implementation", None),
                     "classifier_pooling": getattr(cfg, "classifier_pooling", None),
                     "num_hidden_layers": getattr(cfg, "num_hidden_layers", None),
                     "hidden_size": getattr(cfg, "hidden_size", None)}
    first = next(model.parameters())
    res["dtype"], res["device"] = str(first.dtype), str(first.device)
    batch = _fixed_batch(tok)
    res["input_ids_sha256"] = sha256_bytes(json.dumps(batch["input_ids"].tolist()).encode())
    res["input_shape"] = list(batch["input_ids"].shape)
    res["tokenizer"] = {"class": type(tok).__name__, "pad_token_id": tok.pad_token_id,
                        "batch_keys": sorted(batch.keys())}
    res["cpu_forward"] = _encoder_summary(model, batch, "cpu")
    return res


def section_qnli(rev, hub_cache, probe_file, probe_sha):
    import datasets
    res = {"datasets": datasets.__version__, "HF_DATASETS_CACHE": os.environ.get("HF_DATASETS_CACHE"),
           "config_cache": str(getattr(datasets.config, "HF_DATASETS_CACHE", None)), "splits": {}}
    train_idx = None
    for split in ("train", "validation"):
        item = {}
        t0 = time.time()
        try:
            ds = datasets.load_dataset("glue", "qnli", split=split, revision=rev)
            item.update(ok=True, num_rows=int(ds.num_rows), columns=list(ds.column_names),
                        features=str(ds.features)[:600],
                        cache_file=(ds.cache_files[0].get("filename") if getattr(ds, "cache_files", None) else None))
            data = ds[:]
            item["rows_sha256"], _ = rows_sha256(data["idx"], data["question"], data["sentence"], data["label"])
            if split == "train":
                train_idx = [int(v) for v in data["idx"]]
                bad = next((i for i, v in enumerate(train_idx) if v != i), None)
                item["idx_equals_row"] = bad is None
        except Exception as e:
            item.update(ok=False, error=err(e), traceback=tb())
        item["seconds"] = round(time.time() - t0, 1)
        res["splits"][split] = item
    pq_res = {}
    snap = Path(hub_cache) / "datasets--glue" / "snapshots" / rev / "qnli"
    try:
        import pyarrow.parquet as pq
        for split in ("train", "validation"):
            f = snap / f"{split}-00000-of-00001.parquet"
            e = {"path": str(f)}
            try:
                e["file_sha256"] = sha256_file(f)
                d = pq.read_table(f).to_pydict()
                e["rows_sha256"], e["num_rows"] = rows_sha256(d["idx"], d["question"], d["sentence"], d["label"])
            except Exception as ex:
                e["error"] = err(ex)
            pq_res[split] = e
    except Exception as e:
        pq_res["error"] = err(e)
    res["parquet"] = pq_res
    ex = {"path": str(probe_file)}
    try:
        b = Path(probe_file).read_bytes()
        ex["sha256"] = sha256_bytes(b)
        ex["sha256_matches_expected"] = ex["sha256"] == probe_sha
        obj = json.loads(b.decode("utf-8"))
        s, e_ = set(obj["probe_s_ids"]), set(obj["probe_e_ids"])
        union = s | e_
        ex.update(s=len(s), e=len(e_), overlap=len(s & e_), union=len(union), max_id=max(union),
                  ids_sha256_field=obj.get("ids_sha256"))
        if train_idx is not None:
            present = union & set(train_idx)
            ex["union_present_in_train"] = len(present)
            ex["train_rows_after_exclusion"] = len(train_idx) - sum(1 for v in train_idx if v in union)
    except Exception as e:
        ex["error"] = err(e)
    res["exclusions"] = ex
    return res


def section_runner(repo, scratch, ettin_rev, glue_rev, probe_file, probe_sha):
    import dataclasses
    import torch
    sys.path.insert(0, str(repo))
    res = {}
    rca = importlib.import_module("scripts.run_controller_ablation")
    if dataclasses.is_dataclass(rca.ExperimentConfig):
        res["config_fields"] = [f.name for f in dataclasses.fields(rca.ExperimentConfig)]
    base = dict(task="qnli", n_phases=1, max_consecutive_skips=4, policy_seed=0, learning_rate=2e-5,
                train_batch_size=8, eval_batch_size=8, dry_run=False, arm="full_finetune",
                controller_version="legacy_v4", score_source="uniform", total_steps=20, min_step=0,
                target_skip_rate=0.0, lr_warmup_steps=3, lr_schedule_shape="linear", model_revision=ettin_rev,
                tokenizer_revision=ettin_rev, dataset_id="glue", dataset_revision=glue_rev,
                probe_exclusions_file=str(probe_file), probe_exclusions_hash=probe_sha,
                output_dir=str(Path(scratch) / "runner_probe"), attempt_id="prep5")
    res["config_used"] = base
    t0 = time.time()
    cfg = rca.ExperimentConfig(**base)
    model = rca._load_model_production(cfg)
    model.eval()
    tok = rca._load_tokenizer_production(cfg)
    train = rca._load_train_dataset_production(cfg, 0)
    evald = rca._load_eval_dataset_production(cfg)
    res.update(train_rows=len(train), eval_rows=len(evald), train_columns=list(train.column_names),
               load_seconds=round(time.time() - t0, 1))
    batch = rca._dynamic_padding_collator([train[i] for i in range(8)], pad_token_id=tok.pad_token_id)
    res["train_batch"] = {k: list(v.shape) for k, v in batch.items() if hasattr(v, "shape")}
    with torch.no_grad():
        o = model(**batch)
    loss = getattr(o, "loss", None)
    res["train_batch_forward"] = {"ok": True, "logits_shape": list(o.logits.shape),
                                  "loss_finite": (bool(torch.isfinite(loss).all()) if loss is not None else None)}
    sub = evald.select(range(min(16, len(evald))))
    e_loss, e_acc, e_f1 = rca._evaluate_model(None, model, sub, cfg, pad_token_id=tok.pad_token_id)
    res["evaluator_16_rows"] = {"ok": True, "loss": float(e_loss), "accuracy": float(e_acc),
                                "f1": (None if e_f1 is None else float(e_f1))}
    res["note"] = "inference only: the classification head is newly initialised, so loss and accuracy mean nothing"
    return res


# --------------------------------------------------------------------------- gpu section
def section_gpu(repo):
    import torch
    res = {"torch": torch.__version__, "cuda_build": torch.version.cuda,
           "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}
    res["cuda_available"] = bool(torch.cuda.is_available())
    if not res["cuda_available"]:
        return res
    res["device_count"] = torch.cuda.device_count()
    if res["device_count"] != 1:
        res["stopped"] = "exactly one visible GPU is required"
        return res
    res["device_name"] = torch.cuda.get_device_name(0)
    res["capability"] = list(torch.cuda.get_device_capability(0))
    try:
        res["cudnn"] = torch.backends.cudnn.version()
    except Exception as e:
        res["cudnn"] = err(e)
    try:
        res["arch_list"] = torch.cuda.get_arch_list()
    except Exception as e:
        res["arch_list"] = err(e)
    g = torch.Generator().manual_seed(0)
    a = torch.randn(256, 256, generator=g)
    ref = (a @ a).double()
    got = (a.cuda() @ a.cuda()).double().cpu()
    torch.cuda.synchronize()
    res["matmul_max_abs_diff"] = float((got - ref).abs().max())
    model, tok, ec, warnings = _load_model(repo)
    batch = _fixed_batch(tok)
    cpu = _encoder_summary(model, batch, "cpu")
    model.to("cuda")
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    gpu = _encoder_summary(model, batch, "cuda")
    torch.cuda.synchronize()
    res["gpu_forward_seconds"] = round(time.time() - t0, 3)
    res["gpu_finite"] = gpu["finite"]
    diff = lambda x, y: max(abs(p - q) for rx, ry in zip(x, y) for p, q in zip(rx, ry))
    res["mean_max_abs_diff_vs_cpu"] = diff(gpu["mean"], cpu["mean"])
    res["first_max_abs_diff_vs_cpu"] = diff(gpu["first"], cpu["first"])
    res["logits_max_abs_diff_vs_cpu"] = diff(gpu["logits"], cpu["logits"])
    res["peak_memory_mib"] = round(torch.cuda.max_memory_allocated() / 2 ** 20, 1)
    res["parameters"] = int(sum(p.numel() for p in model.parameters()))
    return res


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True, help="JSON file to write; must not exist")
    ap.add_argument("--scratch", required=True, help="folder for the runner's probe output; must not exist")
    ap.add_argument("--label", required=True)
    ap.add_argument("--mode", choices=("cpu", "gpu"), required=True)
    ap.add_argument("--ettin-rev", required=True)
    ap.add_argument("--glue-rev", required=True)
    ap.add_argument("--hub-cache", required=True)
    ap.add_argument("--probe-file", required=True)
    ap.add_argument("--probe-sha256", required=True)
    a = ap.parse_args()
    out, scratch = Path(a.out), Path(a.scratch)
    if out.exists() or scratch.exists():
        print("--out or --scratch already exists", file=sys.stderr)
        return 2
    scratch.mkdir(parents=True)
    rep = {"version": VERSION, "label": a.label, "mode": a.mode, "started": now(), "argv": sys.argv,
           "script_sha256": sha256_file(Path(__file__).resolve()), "seconds": {}, "section_errors": {}}

    def save():
        tmp = out.with_suffix(".tmp")
        tmp.write_text(json.dumps(rep, indent=1, default=str))
        tmp.replace(out)

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e), "traceback": tb()}
            rep["section_errors"][name] = err(e)
        rep["seconds"][name] = round(time.time() - t0, 1)
        save()
        print(f"[{now()}] {a.label} {a.mode} {name} done in {rep['seconds'][name]} s", flush=True)

    repo = Path(a.repo).resolve()
    if a.mode == "cpu":
        section("versions", section_versions)
        section("integrity", section_integrity)
        section("layernorm", section_layernorm)
        section("modernbert", section_modernbert_source)
        section("model", section_model, repo)
        section("qnli", section_qnli, a.glue_rev, a.hub_cache, a.probe_file, a.probe_sha256)
        section("runner", section_runner, repo, scratch, a.ettin_rev, a.glue_rev, a.probe_file, a.probe_sha256)
    else:
        section("versions", section_versions)
        section("gpu", section_gpu, repo)
    rep["finished"] = now()
    save()
    return 0


if __name__ == "__main__":
    sys.exit(main())

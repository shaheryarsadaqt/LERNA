#!/usr/bin/env python3
"""LERNA Step 5 preparation, round 5 (4 November 2026). Read-only; standard library only.

Settles the three findings of round 3 before the Step 5 runner patch:
  A. Which Python environment builds the intended Ettin model. In lerna, the installed
     modeling_modernbert.py differs from the official transformers 4.48.3 file, and the
     model gets 46 LayerNorm biases the checkpoint doesn't have (149,641,730 parameters
     instead of 149,606,402). Each candidate environment is probed by
     step5_prep5_probe.py: library integrity against RECORD hashes, the LayerNorm API,
     the ModernBERT source, the model, and its encoder outputs on a fixed batch.
  B. The QNLI data path offline. Round 3's new, empty datasets cache can't work:
     datasets 4.8.4 in offline mode only falls back to that cache. This round copies
     the prepared QNLI cache files (dataset_info.json and glue-*.arrow only) into a
     private cache per environment, loads train and validation, compares content hashes
     with the pinned parquet files, applies the probe exclusions, and runs the runner's
     own QNLI loaders, collator and evaluator without training.
  C. The preregistration tag history. The unreachable v4-prereg* tag objects are saved
     in full, with the PREREG_V4.md blob of each target commit.
Optionally (default on), one GPU runs the probe's fixed batch: forward passes only.

It writes only into --out, which must not exist. It never writes into the repository or
the shared caches, never installs, downloads, trains or commits. Exit 0 means the report
was written, whatever it found; exit 2 means bad arguments, an existing --out, or a kit
file whose SHA-256 isn't the expected one.

Usage (outside the repository):
  python -s -B LERNA_STEP5_PREP5_CHECK.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import os
import sys

sys.dont_write_bytecode = True

import argparse
import datetime
import difflib
import hashlib
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

VERSION = "LERNA_STEP5_PREP5_CHECK v1 (2026-11-04)"
EXPECTED = {
    "head": "3af68e85302a4975ef1eb2079e41066db1366520",
    "runner_sha256": "50a967ba1de3b9c0ad8e705497709e64ea852990ea2490775f5b938c79a62df8",
    "probe_script_sha256": "5f8aa911886cfd4072b572478a8c409ebe15dc1d38ab73e57959ca9878086f42",
    "official_modeling_sha256": "e235e8020c6ee082a21a6f262bf5b3cb3f476d630201ce3a1518f17200ae8deb",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
    "ettin_rev": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "glue_rev": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "bias_free_parameters": 149606402,
    "qnli_train_rows": 104743,
    "qnli_train_rows_after_exclusion": 104231,
}
ENVS = [
    ("lerna", "/new_raid/nanhangproj/conda_envs/lerna/bin/python", ["-s", "-B"]),
    ("qwen-v100", "/raid/qwen-v100/bin/python", ["-s", "-B"]),
    ("base", "/home/nanhangproj/miniconda3/bin/python", ["-s", "-B"]),
    # The October cohorts' stack: fy's interpreter started normally, so that the user-site
    # transformers 4.48.3 in ~/.local is used, exactly as in October. Reference only.
    ("october-stack", "/home/fy/miniconda3/envs/py310/bin/python", ["-B"]),
]
PROBE_TIMEOUT = {"cpu": 1800, "gpu": 900}
GPU_BUSY_MIB = 500


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def err(e):
    return f"{type(e).__name__}: {e}"[:1500]


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd, timeout=120, cwd=None, env=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd, env=env)
        return {"cmd": cmd, "exit": p.returncode, "stdout": p.stdout[-200000:], "stderr": p.stderr[-8000:]}
    except FileNotFoundError as e:
        return {"cmd": cmd, "exit": None, "error": err(e)}
    except subprocess.TimeoutExpired:
        return {"cmd": cmd, "exit": None, "error": f"timed out after {timeout} s"}


def git(repo, *args, timeout=120):
    return run(["git", "--no-optional-locks", "-C", str(repo), *args], timeout=timeout)


def out_of(r):
    return (r.get("stdout") or "").strip()


# --------------------------------------------------------------------------- 1. preflight
def section_preflight(repo, kit):
    res = {"head": out_of(git(repo, "rev-parse", "HEAD"))}
    st = git(repo, "status", "--porcelain")
    res["porcelain_entries"] = len([l for l in out_of(st).splitlines() if l.strip()])
    res["tree_clean"] = st.get("exit") == 0 and res["porcelain_entries"] == 0
    res["head_is_expected"] = res["head"] == EXPECTED["head"]
    runner = repo / "scripts" / "run_controller_ablation.py"
    res["runner_sha256"] = sha256_file(runner) if runner.is_file() else None
    res["runner_is_accepted"] = res["runner_sha256"] == EXPECTED["runner_sha256"]
    pf = repo / "experiments" / "probe_indices_v4.json"
    res["probe_file"] = str(pf)
    res["probe_file_sha256"] = sha256_file(pf) if pf.is_file() else None
    res["probe_file_is_expected"] = res["probe_file_sha256"] == EXPECTED["probe_file_sha256"]
    res["kit"] = {name: sha256_file(kit[name]) for name in kit}
    return res


# --------------------------------------------------------------------------- 2. tag history
TAG_RE = re.compile(r"^object (?P<object>[0-9a-f]{40})\ntype (?P<type>\S+)\ntag (?P<tag>\S+)\n"
                    r"tagger (?P<tagger>.*?) (?P<ts>\d+) (?P<tz>[+-]\d{4})\n", re.S)


def section_tag_history(repo, out):
    res = {"tag_objects": [], "targets": {}}
    # Full output, not truncated: a repository can list thousands of unreachable blobs.
    p = subprocess.run(["git", "--no-optional-locks", "-C", str(repo), "fsck", "--unreachable", "--no-reflogs",
                        "--no-progress"], capture_output=True, timeout=1200)
    lines = p.stdout.decode("utf-8", "replace").splitlines()
    res["fsck_exit"] = p.returncode
    kinds = {}
    tags = []
    for l in lines:
        parts = l.split()
        if len(parts) == 3 and parts[0] == "unreachable":
            kinds[parts[1]] = kinds.get(parts[1], 0) + 1
            if parts[1] == "tag":
                tags.append(parts[2])
    res["unreachable_counts"] = kinds
    tdir = out / "tag_objects"
    tdir.mkdir()
    for sha in tags:
        # Exact bytes of the tag object, so that its id can be recomputed from the saved file.
        raw = subprocess.run(["git", "--no-optional-locks", "-C", str(repo), "cat-file", "tag", sha],
                             capture_output=True, timeout=60).stdout
        (tdir / f"{sha}.tag").write_bytes(raw)
        text = raw.decode("utf-8", "replace")
        m = TAG_RE.match(text)
        o = {"tag_object": sha, "saved_as": f"tag_objects/{sha}.tag", "bytes": len(raw),
             "id_recomputed_from_saved_bytes": hashlib.sha1(b"tag %d\0" % len(raw) + raw).hexdigest() == sha}
        if m:
            ts = int(m.group("ts"))
            o.update(name=m.group("tag"), object=m.group("object"), type=m.group("type"),
                     tagger=m.group("tagger"), tagger_epoch=ts,
                     tagger_utc=datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).isoformat(),
                     message_first_line=text.split("\n\n", 1)[1].splitlines()[0][:200] if "\n\n" in text else "")
        else:
            o["parse_error"] = "could not parse the tag object"
        res["tag_objects"].append(o)
    res["tag_objects"].sort(key=lambda o: o.get("tagger_epoch", 0))
    commits = [o["object"] for o in res["tag_objects"] if o.get("type") == "commit"]
    named = {"HEAD": "HEAD", "v4-prereg-r3": "refs/tags/v4-prereg-r3", "v4-prereg-r2": "refs/tags/v4-prereg-r2",
             "training_commit": "a6c6d13563b9b03375cd4529628ea50b28ae9ccd",
             "results_commit": "30bca951cdfea5321deae89bf1ae06e584211e21"}
    for label, ref in named.items():
        c = out_of(git(repo, "rev-parse", "--verify", "--quiet", ref + "^{commit}"))
        res.setdefault("named_refs", {})[label] = c or None
        if c:
            commits.append(c)
    for c in dict.fromkeys(commits):
        t = {"exists": git(repo, "cat-file", "-e", c + "^{commit}").get("exit") == 0}
        if t["exists"]:
            t["show"] = out_of(git(repo, "show", "-s", "--format=%H%x09%ci%x09%s", c))
            t["branches_containing"] = [b.strip() for b in out_of(git(repo, "branch", "-a", "--contains", c,
                                                                       timeout=300)).splitlines()][:20]
            for path, key in (("experiments/PREREG_V4.md", "prereg_blob"), ("lerna/utils/forward_gate.py", "gate_blob")):
                t[key] = out_of(git(repo, "rev-parse", "--verify", "--quiet", f"{c}:{path}")) or None
        res["targets"][c] = t
    res["gc_config"] = {k: out_of(git(repo, "config", "--get", k)) or None
                        for k in ("gc.auto", "gc.pruneExpire", "gc.reflogExpireUnreachable", "core.logAllRefUpdates")}
    res["count_objects"] = out_of(git(repo, "count-objects", "-v"))
    return res


# --------------------------------------------------------------------------- 3. data copies
def section_prepared_cache(prepared_root, out, labels):
    src = Path(prepared_root) / "glue" / "qnli" / "0.0.0" / EXPECTED["glue_rev"]
    res = {"source": str(src), "exists": src.is_dir(), "copies": {}}
    if not src.is_dir():
        return res
    listing = []
    for p in sorted(src.iterdir()):
        try:
            st = p.stat()
            listing.append({"name": p.name, "size": st.st_size, "is_file": p.is_file()})
        except OSError as e:
            listing.append({"name": p.name, "error": err(e)})
    res["source_listing"] = listing
    wanted = [p for p in sorted(src.iterdir()) if p.is_file() and
              (p.name == "dataset_info.json" or (p.name.startswith("glue-") and p.name.endswith(".arrow")))]
    res["copied_files"] = [p.name for p in wanted]
    res["source_sha256"] = {p.name: sha256_file(p) for p in wanted}
    for label in labels:
        dst = out / "ds_cache" / label / "glue" / "qnli" / "0.0.0" / EXPECTED["glue_rev"]
        dst.mkdir(parents=True)
        for p in wanted:
            shutil.copy2(p, dst / p.name)
        res["copies"][label] = {"cache_root": str(out / "ds_cache" / label),
                                "identical": all(sha256_file(dst / p.name) == res["source_sha256"][p.name] for p in wanted)}
    return res


# --------------------------------------------------------------------------- 4. probes
def gpu_idle(index):
    r = run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"], timeout=30)
    if r.get("exit") != 0:
        return False, r.get("error") or r.get("stderr")
    for line in out_of(r).splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0] == str(index):
            used = int(parts[1])
            return used < GPU_BUSY_MIB, f"GPU {index}: {used} MiB used"
    return False, f"GPU {index} not listed"


def run_probe(label, python, flags, mode, a, out, cache_root, gpu_index):
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false",
                "CUDA_VISIBLE_DEVICES": ("" if mode == "cpu" else str(gpu_index))})
    if cache_root:
        env["HF_DATASETS_CACHE"] = cache_root
    js = out / "probes" / f"{label}_{mode}.json"
    scratch = out / "probes" / f"{label}_{mode}_scratch"
    cmd = [python, *flags, str(a.probe), "--repo", str(a.repo), "--out", str(js), "--scratch", str(scratch),
           "--label", label, "--mode", mode, "--ettin-rev", EXPECTED["ettin_rev"], "--glue-rev", EXPECTED["glue_rev"],
           "--hub-cache", str(a.hub_cache), "--probe-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
           "--probe-sha256", EXPECTED["probe_file_sha256"]]
    t0 = time.time()
    r = run(cmd, timeout=PROBE_TIMEOUT[mode], cwd=str(out / "probes"), env=env)
    log = out / "probes" / f"{label}_{mode}.log"
    log.write_text(f"$ {' '.join(cmd)}\nexit: {r.get('exit')} {r.get('error', '')}\n--- stdout\n{r.get('stdout', '')}"
                   f"\n--- stderr\n{r.get('stderr', '')}\n")
    res = {"cmd": cmd, "exit": r.get("exit"), "error": r.get("error"), "seconds": round(time.time() - t0, 1),
           "log": str(log.relative_to(out))}
    try:
        res["report"] = json.loads(js.read_text())
    except Exception as e:
        res["report_error"] = err(e)
    return res


# --------------------------------------------------------------------------- 5. comparisons
def g(d, *keys, default=None):
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return default
        d = d[k]
    return d


def max_diff(x, y):
    try:
        return max(abs(p - q) for rx, ry in zip(x, y) for p, q in zip(rx, ry))
    except Exception:
        return None


def summarize_env(label, cpu, gpu):
    r = g(cpu, "report") or {}
    pk = g(r, "versions", "packages") or {}
    integ = g(r, "integrity") or {}
    s = {"exit": g(cpu, "exit"), "section_errors": r.get("section_errors"),
         "python": (g(r, "versions", "python") or "").split()[0] if g(r, "versions", "python") else None,
         "user_site_used": g(r, "versions", "user_site_enabled"),
         "versions": {k: g(v, "version") for k, v in pk.items()} if pk else None,
         "pytest": g(r, "versions", "pytest", "version"),
         "torch_cuda_build": g(r, "versions", "torch_extra", "cuda_build"),
         "integrity_mismatches": {k: v.get("mismatched") for k, v in integ.items() if isinstance(v, dict) and v.get("mismatched")},
         "integrity_mismatched_files": {k: v.get("mismatched_files") for k, v in integ.items()
                                        if isinstance(v, dict) and v.get("mismatched")},
         "integrity_import_not_covered": [k for k, v in integ.items() if isinstance(v, dict) and "py_files_checked" in v
                                          and not v.get("record_covers_imported_module")],
         "layernorm_accepts_bias": g(r, "layernorm", "accepts_bias_argument"),
         "modernbert_sha256": g(r, "modernbert", "files", "modeling_modernbert.py", "sha256"),
         "modernbert_layernorm_lines": g(r, "modernbert", "files", "modeling_modernbert.py", "layernorm_lines"),
         "parameters": g(r, "model", "parameters"),
         "layernorm_with_bias": g(r, "model", "layernorm_with_bias"),
         "layernorm_bias_max_abs": g(r, "model", "layernorm_bias_max_abs"),
         "reference_compile": g(r, "model", "config", "reference_compile"),
         "attn_implementation": g(r, "model", "config", "attn_implementation"),
         "input_ids_sha256": g(r, "model", "input_ids_sha256"),
         "qnli": {sp: {k: g(r, "qnli", "splits", sp, k) for k in ("ok", "num_rows", "rows_sha256", "error", "cache_file")}
                  for sp in ("train", "validation")},
         "parquet": {sp: {k: g(r, "qnli", "parquet", sp, k) for k in ("num_rows", "rows_sha256", "error")}
                     for sp in ("train", "validation")},
         "exclusions": g(r, "qnli", "exclusions"),
         "runner": ({k: g(r, "runner", k) for k in ("train_rows", "eval_rows", "train_batch", "train_batch_forward",
                                                     "evaluator_16_rows", "error")} if g(r, "runner") else None)}
    s["model_is_bias_free"] = (s["parameters"] == EXPECTED["bias_free_parameters"] and s["layernorm_with_bias"] == 0) \
        if s["parameters"] is not None else None
    for sp in ("train", "validation"):
        a_, b_ = g(s, "qnli", sp, "rows_sha256"), g(s, "parquet", sp, "rows_sha256")
        s["qnli"][sp]["matches_parquet"] = (a_ == b_) if (a_ and b_) else None
    if gpu is not None:
        gr = g(gpu, "report", "gpu") or {}
        s["gpu"] = {"exit": g(gpu, "exit"), "skipped": g(gpu, "skipped"), "error": g(gr, "error") or g(gpu, "error"),
                    **{k: gr.get(k) for k in ("cuda_available", "device_count", "device_name", "capability", "cudnn",
                                              "matmul_max_abs_diff", "gpu_finite", "mean_max_abs_diff_vs_cpu",
                                              "logits_max_abs_diff_vs_cpu", "peak_memory_mib", "parameters",
                                              "gpu_forward_seconds", "stopped")}}
    return s


def compare_envs(results):
    ref_label = next((l for l in ("base", "october-stack", "qwen-v100") if g(results, l, "cpu", "report", "model", "cpu_forward")), None)
    res = {"reference": ref_label, "pairs": {}}
    if not ref_label:
        return res
    ref = g(results, ref_label, "cpu", "report", "model")
    for label, r in results.items():
        m = g(r, "cpu", "report", "model")
        if not m or not m.get("cpu_forward"):
            continue
        res["pairs"][label] = {"same_input_ids": m.get("input_ids_sha256") == ref.get("input_ids_sha256"),
                               "mean_max_abs_diff": max_diff(m["cpu_forward"]["mean"], ref["cpu_forward"]["mean"]),
                               "first_max_abs_diff": max_diff(m["cpu_forward"]["first"], ref["cpu_forward"]["first"])}
    return res


# --------------------------------------------------------------------------- 6. ModernBERT diff
def section_modernbert_diff(results, official, out):
    res = {"official": str(official), "official_sha256": sha256_file(official), "files": {}}
    off_lines = Path(official).read_text(encoding="utf-8").splitlines(keepends=True)
    for label, r in results.items():
        f = g(r, "cpu", "report", "modernbert", "files", "modeling_modernbert.py")
        ver = g(r, "cpu", "report", "modernbert", "transformers")
        if not isinstance(f, dict):
            continue
        e = {"path": f.get("path"), "sha256": f.get("sha256"), "transformers": ver, "mtime": f.get("mtime"),
             "ctime": f.get("ctime"), "is_official_4_48_3": f.get("sha256") == res["official_sha256"]}
        if ver == "4.48.3" and not e["is_official_4_48_3"]:
            try:
                mine = Path(f["path"]).read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
                d = list(difflib.unified_diff(off_lines, mine, "official-4.48.3/modeling_modernbert.py",
                                              f"{label}/modeling_modernbert.py"))
                name = f"modernbert_{label}_vs_official.diff"
                (out / name).write_text("".join(d))
                e.update(diff_file=name, diff_lines=len(d),
                         changed_lines=sum(1 for l in d if l[:1] in "+-" and not l.startswith(("+++", "---"))))
            except Exception as ex:
                e["diff_error"] = err(ex)
        res["files"][label] = e
    return res


# --------------------------------------------------------------------------- summary
def glance(rep):
    L = ["AT A GLANCE"]
    pf = rep.get("preflight", {})
    L.append(f"   checkout: HEAD {pf.get('head')} (expected {pf.get('head_is_expected')}), tree clean {pf.get('tree_clean')}, "
             f"accepted runner {pf.get('runner_is_accepted')}, probe file as expected {pf.get('probe_file_is_expected')}")
    for label, s in (rep.get("summary") or {}).items():
        if s.get("not_found"):
            L.append(f"   {label}: interpreter not found ({s['not_found']})")
            continue
        v = s.get("versions") or {}
        L.append(f"   {label}: python {s.get('python')}, torch {g(v, 'torch')} (CUDA {s.get('torch_cuda_build')}), "
                 f"transformers {g(v, 'transformers')}, datasets {g(v, 'datasets')}, pytest {s.get('pytest')}, "
                 f"user site {'on' if s.get('user_site_used') else 'off'}")
        L.append(f"      model: {s.get('parameters')} parameters, LayerNorms with bias {s.get('layernorm_with_bias')}, "
                 f"bias-free as intended {s.get('model_is_bias_free')}; LayerNorm takes bias: {s.get('layernorm_accepts_bias')}; "
                 f"library files differing from RECORD: {s.get('integrity_mismatches') or 'none'}")
        q = s.get("qnli") or {}
        ex = s.get("exclusions") or {}
        L.append(f"      QNLI: train {g(q, 'train', 'num_rows')} rows (matches parquet {g(q, 'train', 'matches_parquet')}), "
                 f"validation {g(q, 'validation', 'num_rows')} (matches parquet {g(q, 'validation', 'matches_parquet')}), "
                 f"after exclusion {ex.get('train_rows_after_exclusion')}"
                 + (f"; ERROR {g(q, 'train', 'error')}" if g(q, 'train', 'error') else ""))
        rn = s.get("runner") or {}
        L.append(f"      runner QNLI path: train {rn.get('train_rows')}, eval {rn.get('eval_rows')}, "
                 f"forward {g(rn, 'train_batch_forward', 'ok')}, evaluator {g(rn, 'evaluator_16_rows', 'ok')}"
                 + (f"; ERROR {rn.get('error')}" if rn.get("error") else ""))
        gp = s.get("gpu")
        if gp:
            if gp.get("skipped"):
                line = f"skipped ({gp.get('skipped')})"
            elif gp.get("cuda_available") is False:
                line = "CUDA not available in the probe process" + (f"; ERROR {gp.get('error')}" if gp.get("error") else "")
            else:
                line = (f"{gp.get('device_name')} (capability {gp.get('capability')}), finite {gp.get('gpu_finite')}, "
                        f"max |GPU-CPU| encoder mean {gp.get('mean_max_abs_diff_vs_cpu')}, peak {gp.get('peak_memory_mib')} MiB"
                        + (f", ERROR {gp.get('error')}" if gp.get("error") else "")
                        + (f", stopped: {gp.get('stopped')}" if gp.get("stopped") else ""))
            L.append(f"      GPU: {line}")
    cmp_ = rep.get("comparison") or {}
    if cmp_.get("pairs"):
        L.append(f"   encoder outputs vs {cmp_.get('reference')} (CPU, fixed batch): " + "; ".join(
            f"{k} {v['mean_max_abs_diff']:.3g}" + ("" if v["same_input_ids"] else " (different input ids)")
            for k, v in cmp_["pairs"].items() if v.get("mean_max_abs_diff") is not None))
    md = rep.get("modernbert_diff") or {}
    for label, e in (md.get("files") or {}).items():
        if e.get("diff_file"):
            L.append(f"   {label} modeling_modernbert.py: not the official 4.48.3 file; {e.get('changed_lines')} changed lines "
                     f"in {e['diff_file']}; mtime {e.get('mtime')}")
    pc = rep.get("prepared_cache") or {}
    L.append(f"   prepared QNLI cache: {pc.get('source')} exists {pc.get('exists')}; copied {pc.get('copied_files')}")
    th = rep.get("tag_history") or {}
    objs = th.get("tag_objects") or []
    L.append(f"   tag history: {len(objs)} unreachable tag objects saved; unreachable objects by kind {th.get('unreachable_counts')}")
    if rep.get("section_errors"):
        L.append(f"   sections that raised: {rep['section_errors']}")
    return L + [""]


def summary_lines(rep):
    L = [VERSION, f"started {rep['started']}, finished {rep.get('finished')}", ""] + glance(rep)
    th = rep.get("tag_history") or {}
    L.append("Tag objects, oldest first (tagger time UTC; target; PREREG_V4.md blob of the target):")
    for o in th.get("tag_objects") or []:
        t = (th.get("targets") or {}).get(o.get("object"), {})
        L.append(f"   {o.get('tagger_utc')}  {o.get('name')} -> {str(o.get('object'))[:10]}  prereg {str(t.get('prereg_blob'))[:10]}  "
                 f"branches {len(t.get('branches_containing') or [])}  | {o.get('message_first_line')}")
    L.append("Named refs: " + json.dumps(th.get("named_refs")))
    for label, c in (th.get("named_refs") or {}).items():
        if c:
            t = (th.get("targets") or {}).get(c, {})
            L.append(f"   {label}: prereg blob {t.get('prereg_blob')}, gate blob {t.get('gate_blob')}")
    L.append(f"git gc settings: {th.get('gc_config')}")
    return L


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--kit", default=str(Path(__file__).resolve().parent),
                    help="folder holding step5_prep5_probe.py and modeling_modernbert_4.48.3_official.py")
    ap.add_argument("--hub-cache", default=os.environ.get("HF_HUB_CACHE") or "/raid/hf_cache")
    ap.add_argument("--prepared-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--gpu-index", type=int, default=7)
    ap.add_argument("--no-gpu", action="store_true")
    ap.add_argument("--env", action="append", default=[],
                    help="label=python[,flag...]; replaces the built-in list (for tests)")
    ap.add_argument("--expect", action="append", default=[], help="key=value override of EXPECTED (for tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECTED[k] = int(v) if isinstance(EXPECTED.get(k), int) else v
    a.repo, out, kit_dir = Path(a.repo).resolve(), Path(a.out).resolve(), Path(a.kit).resolve()
    kit = {"probe": kit_dir / "step5_prep5_probe.py", "official": kit_dir / "modeling_modernbert_4.48.3_official.py"}
    if not (a.repo / "scripts" / "run_controller_ablation.py").is_file():
        print(f"--repo {a.repo} does not look like the LERNA checkout", file=sys.stderr)
        return 2
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if out == a.repo or a.repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    for name, p in kit.items():
        if not p.is_file():
            print(f"missing kit file {p}", file=sys.stderr)
            return 2
    if sha256_file(kit["probe"]) != EXPECTED["probe_script_sha256"]:
        print("step5_prep5_probe.py is not the issued file (SHA-256 differs); stop and ask the user", file=sys.stderr)
        return 2
    if sha256_file(kit["official"]) != EXPECTED["official_modeling_sha256"]:
        print("modeling_modernbert_4.48.3_official.py is not the issued file (SHA-256 differs)", file=sys.stderr)
        return 2
    a.probe = kit["probe"]
    envs = []
    for spec in a.env:
        label, rest = spec.split("=", 1)
        parts = rest.split(",")
        envs.append((label, parts[0], parts[1:]))
    envs = envs or ENVS
    out.mkdir(parents=True)
    (out / "probes").mkdir()
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "expected": dict(EXPECTED),
           "script_sha256": sha256_file(Path(__file__).resolve()), "section_errors": {}, "seconds": {}}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e)}
            rep["section_errors"][name] = err(e)
        rep["seconds"][name] = round(time.time() - t0, 1)
        save()
        print(f"[{now()}] {name} done in {rep['seconds'][name]} s", flush=True)

    section("preflight", section_preflight, a.repo, kit)
    section("tag_history", section_tag_history, a.repo, out)
    present = [(l, p, f) for l, p, f in envs if Path(p).exists()]
    section("prepared_cache", section_prepared_cache, a.prepared_cache, out, [l for l, _, _ in present])

    def do_probes():
        results = {}
        for label, python, flags in envs:
            if not Path(python).exists():
                results[label] = {"not_found": python}
                continue
            cache_root = g(rep, "prepared_cache", "copies", label, "cache_root")
            results[label] = {"cpu": run_probe(label, python, flags, "cpu", a, out, cache_root, a.gpu_index)}
            print(f"[{now()}] probe {label} cpu exit {results[label]['cpu'].get('exit')}", flush=True)
            cuda_build = g(results[label], "cpu", "report", "versions", "torch_extra", "cuda_build")
            if a.no_gpu:
                results[label]["gpu"] = {"skipped": "--no-gpu"}
            elif not cuda_build:
                results[label]["gpu"] = {"skipped": "torch has no CUDA build here"}
            else:
                idle, why = gpu_idle(a.gpu_index)
                if not idle:
                    results[label]["gpu"] = {"skipped": f"GPU {a.gpu_index} not confirmed idle: {why}"}
                else:
                    results[label]["gpu"] = run_probe(label, python, flags, "gpu", a, out, cache_root, a.gpu_index)
                    print(f"[{now()}] probe {label} gpu exit {results[label]['gpu'].get('exit')}", flush=True)
            save()
        return results
    section("probes", do_probes)
    probes = rep.get("probes") or {}
    rep["summary"] = {l: (r if r.get("not_found") else summarize_env(l, r.get("cpu"), r.get("gpu")))
                      for l, r in probes.items() if isinstance(r, dict)}
    section("comparison", compare_envs, probes)
    section("modernbert_diff", section_modernbert_diff, probes, kit["official"], out)
    after = git(a.repo, "status", "--porcelain")
    rep["tree_clean_after"] = after.get("exit") == 0 and not out_of(after)
    rep["head_after"] = out_of(git(a.repo, "rev-parse", "HEAD"))
    rep["finished"] = now()
    save()
    (out / "SUMMARY.txt").write_text("\n".join(summary_lines(rep)) + "\n")
    print((out / "SUMMARY.txt").read_text())
    return 0


if __name__ == "__main__":
    sys.exit(main())

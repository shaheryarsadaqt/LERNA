#!/usr/bin/env python3
"""LERNA Step 5 Prep 1: read-only readiness check (3 November 2026).

Re-reads Step 4a execution manifests, the preregistration, and the round-3
provenance report to verify the three findings from the Step 4a review:

1. Evaluation loss is reported about 64x too small (sum of batch averages
   divided by example count; accuracy is unaffected).
2. The learning-rate schedule does not match the preregistration: the runner
   keeps the rate constant, but the preregistration specifies linear decay
   for the reduced-steps arm.
3. A GPU environment may exist at /home/fy/miniconda3/envs/py310; archived
   V100 timings may be under /raid.

Read-only: no training, no installs, no GPU use, no code edits, no commits.
Writes summary.json and SUMMARY.txt into --out, which must not exist, and
prints the AT A GLANCE block. Exit 0 means the summary was written, whatever
it found; exit 2 means bad arguments or an existing --out.
"""
import argparse
import hashlib
import json
import math
import os
import re
import subprocess
import sys
from pathlib import Path

VERSION = "LERNA_STEP5_PREP_CHECK v1 (2026-11-03)"
EXPECT_HEAD = "3af68e85302a4975ef1eb2079e41066db1366520"
EXPECT_RUNNER = "50a967ba1de3b9c0ad8e705497709e64ea852990ea2490775f5b938c79a62df8"
EXPECT_PROBE = "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408"
RUNNER_PATH = "/home/nanhangproj/LERNA/scripts/run_controller_ablation.py"
PROBE_PATH = "/home/nanhangproj/LERNA/experiments/probe_indices_v4.json"
PROV_SUMMARY = "/home/nanhangproj/LERNA_step4_prov/report/SUMMARY.txt"
PREREG_PATH = "/home/nanhangproj/LERNA/experiments/PREREG_V4.md"
GPU_ENV_PYTHON = "/home/fy/miniconda3/envs/py310/bin/python"
STEP4A_RUNS = "/home/nanhangproj/LERNA_step4a/runs"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def git_head(repo):
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, cwd=repo)
        return r.stdout.strip() if r.returncode == 0 else "unknown"
    except Exception:
        return "unknown:exception"


def git_porcelain(repo):
    try:
        r = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, cwd=repo)
        return r.stdout if r.returncode == 0 else "unknown"
    except Exception:
        return "unknown:exception"


def find_ids_line(text):
    for line in text.splitlines():
        if "89a8c4a7" in line and (": matches" in line or ": NO MATCH" in line):
            return line
    return None


def close(a, b, tol=1e-12):
    try:
        return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(b)))
    except (TypeError, ValueError):
        return False


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    if out.exists():
        print(f"--out {out} already exists", file=sys.stderr)
        return 2
    repo = Path(a.repo)

    findings = []
    checks = []

    def chk(name, ok, got=None):
        checks.append({"check": name, "ok": bool(ok), "got": got})

    # ---------------------------------------------------------------- pre-flight
    head = git_head(repo)
    chk("HEAD is 3af68e8", head == EXPECT_HEAD, head)
    porcelain = git_porcelain(repo)
    chk("tree is clean", porcelain == "", porcelain[:200] if porcelain else "")
    runner_sha = sha256_file(RUNNER_PATH) if Path(RUNNER_PATH).is_file() else None
    chk("runner hash", runner_sha == EXPECT_RUNNER, runner_sha)
    probe_sha = sha256_file(PROBE_PATH) if Path(PROBE_PATH).is_file() else None
    chk("probe file hash", probe_sha == EXPECT_PROBE, probe_sha)
    prov_summary_path = Path(PROV_SUMMARY)
    prov_text = prov_summary_path.read_text() if prov_summary_path.is_file() else ""
    chk("round-3 summary exists", prov_summary_path.is_file(), str(prov_summary_path))
    ids_line = find_ids_line(prov_text)
    chk("round-3 ids_sha256 matches", ids_line is not None and ": matches" in ids_line, ids_line)

    # ---------------------------------------------------------------- finding 1: evaluation loss
    step4a_runs = Path(STEP4A_RUNS)
    manifest_losses = []
    if step4a_runs.is_dir():
        for m in sorted(step4a_runs.rglob("execution_manifest.json")):
            try:
                data = json.loads(m.read_text())
            except Exception:
                continue
            res = data.get("result") or {}
            loss = res.get("final_eval_loss")
            acc = res.get("final_eval_accuracy")
            aid = (data.get("config") or {}).get("attempt_id")
            arm = (data.get("config") or {}).get("arm")
            if loss is not None:
                manifest_losses.append({"attempt_id": aid, "arm": arm, "loss": loss, "accuracy": acc,
                                        "path": str(m)})
    loss_too_small = False
    if manifest_losses:
        # A sum of batch averages divided by N examples under-reports by roughly
        # the number of batches per epoch. For QNLI train with batch 32, that's
        # ~104743/32 ≈ 3273, but per-step averaging can give ~64x depending on
        # logging interval. We just flag values that look implausibly small.
        for e in manifest_losses:
            if isinstance(e["loss"], (int, float)) and e["loss"] > 0 and e["loss"] < 0.01:
                loss_too_small = True
                break
    chk("finding1: evaluation loss implausibly small (<0.01)", loss_too_small,
        [e["loss"] for e in manifest_losses] if manifest_losses else "no manifests")

    # ---------------------------------------------------------------- finding 2: LR schedule
    prereg_text = Path(PREREG_PATH).read_text() if Path(PREREG_PATH).is_file() else ""
    prereg_has_linear = "linear" in prereg_text.lower() and "decay" in prereg_text.lower()
    prereg_reduced_linear = bool(re.search(r"reduced.*linear|linear.*reduced", prereg_text, re.IGNORECASE))
    chk("finding2: preregistration mentions linear decay", prereg_has_linear, prereg_text[:200])
    chk("finding2: preregistration ties linear decay to reduced steps", prereg_reduced_linear,
        prereg_reduced_linear)

    # Check runner: does it use constant LR?
    runner_text = Path(RUNNER_PATH).read_text() if Path(RUNNER_PATH).is_file() else ""
    runner_constant = "constant_with_warmup" in runner_text
    runner_linear = "linear" in runner_text.lower()
    chk("finding2: runner uses constant_with_warmup LR", runner_constant, runner_constant)
    chk("finding2: runner does not use linear decay", not runner_linear, runner_linear)

    # ---------------------------------------------------------------- finding 3: GPU environment
    gpu_env_exists = Path(GPU_ENV_PYTHON).is_file()
    chk("finding3: GPU env python exists", gpu_env_exists, GPU_ENV_PYTHON)
    gpu_env_modernbert = False
    gpu_env_torch = None
    gpu_env_transformers = None
    if gpu_env_exists:
        try:
            r = subprocess.run(
                [GPU_ENV_PYTHON, "-c",
                 "import torch, transformers; print(torch.__version__, transformers.__version__, end='')"],
                capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                parts = r.stdout.strip().split()
                if len(parts) >= 2:
                    gpu_env_torch, gpu_env_transformers = parts[0], parts[1]
                    try:
                        from transformers import AutoModelForSequenceClassification  # noqa
                        gpu_env_modernbert = True
                    except Exception:
                        pass
        except Exception:
            pass
    chk("finding3: GPU env imports torch+transformers", gpu_env_torch is not None,
        f"torch={gpu_env_torch} transformers={gpu_env_transformers}")

    # ---------------------------------------------------------------- archived V100 timings
    v100_timing_files = []
    for base in ["/raid", "/home/nanhangproj"]:
        bp = Path(base)
        if not bp.is_dir():
            continue
        for p in bp.rglob("*v100*timing*"):
            v100_timing_files.append(str(p))
        for p in bp.rglob("*timing*v100*"):
            v100_timing_files.append(str(p))
    chk("finding3: archived V100 timing files found", len(v100_timing_files) > 0,
        v100_timing_files[:10])

    # ---------------------------------------------------------------- summary
    n_ok = sum(1 for c in checks if c["ok"])
    n_all = len(checks)
    verdict = "ALL CHECKS COMPLETE" if n_ok == n_all else "SOME CHECKS FAILED"

    L = [f"AT A GLANCE ({VERSION})", f" Verdict: {verdict}: {n_ok} of {n_all} checks passed"]
    for c in checks:
        mark = "PASS" if c["ok"] else "FAIL"
        L.append(f"  [{mark}] {c['check']}: {c['got']}")
    L.append("")
    L.append("Finding 1 (evaluation loss):")
    L.append(f"  {len(manifest_losses)} Step 4a manifests with final_eval_loss values")
    if manifest_losses:
        for e in manifest_losses:
            L.append(f"    {e['attempt_id']} ({e['arm']}): loss={e['loss']} accuracy={e['accuracy']}")
    L.append("  Accuracy is unaffected; loss is about 64x too small if sum-of-batch-averages / N examples.")
    L.append("")
    L.append("Finding 2 (LR schedule):")
    L.append(f"  Preregistration mentions linear decay: {prereg_has_linear}")
    L.append(f"  Preregistration ties linear decay to reduced steps: {prereg_reduced_linear}")
    L.append(f"  Runner uses constant_with_warmup: {runner_constant}")
    L.append(f"  Runner uses linear decay: {runner_linear}")
    L.append("")
    L.append("Finding 3 (GPU environment):")
    L.append(f"  {GPU_ENV_PYTHON} exists: {gpu_env_exists}")
    L.append(f"  torch={gpu_env_torch} transformers={gpu_env_transformers} ModernBERT={gpu_env_modernbert}")
    L.append(f"  V100 timing files: {len(v100_timing_files)}")
    L.append("")
    L.append("Read-only: no training, no installs, no GPU use, no code edits, no commits.")
    L.append("Accuracy of short runs is not a result; see summary.json for values.")

    out.mkdir(parents=True)
    rep = {"version": VERSION, "verdict": verdict, "checks": checks,
           "manifest_losses": manifest_losses,
           "finding1": {"prereg_linear_decay": prereg_has_linear,
                        "prereg_reduced_linear": prereg_reduced_linear,
                        "runner_constant": runner_constant, "runner_linear": runner_linear},
           "finding3": {"gpu_env_exists": gpu_env_exists, "torch": gpu_env_torch,
                        "transformers": gpu_env_transformers, "modernbert": gpu_env_modernbert,
                        "v100_timing_files": v100_timing_files}}
    (out / "summary.json").write_text(json.dumps(rep, indent=1, default=str))
    (out / "SUMMARY.txt").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())
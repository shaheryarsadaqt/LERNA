#!/usr/bin/env python3
"""LERNA round 13: checks and the pre-specified reading of the development round (6 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, runs/, logs/) and writes only
check_report.json and CHECK_SUMMARY.txt into that folder. Exit 0 means the report was written;
the verdict is inside it. Exit 2 means the folder isn't a finished launcher folder.

Per run (the 75 new runs), it checks:
  - the exit code and the manifest status;
  - the config: task, arm, controller, phases, score source, seed, recipe, revisions, device;
  - the exact counts: forwards (plus skips decided before any forward pass), backwards, skips,
    scheduler steps and updates; the warmup steps, and that the final LR is 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases, attention,
    AdamW betas and eps, the pinned GPU;
  - the batch log (9 fields per row) and the stored-score counters of M1 and InfoBatch.
It also checks:
  - the reused Step 5 QNLI runs (--step5): full fine-tuning, reduced, equal-compute, LERNA and
    random skipping for the same seeds: present, OK, and their batch logs intact;
  - the reproduction of round 12's seed-11 full-length runs (--r12), bit for bit.
Then it runs the reading fixed in claude/LERNA_R13_DEV_PLAN_2026-11-06.md, sections 2-4:
  - measured compute = (forward padded tokens + 2 x updated padded tokens) / the same for full
    fine-tuning of the same task and seed;
  - per task and seed, the plain-run curve through the six plain runs (30, 40, 50, 60, 70 and
    100% of T), joined by straight lines in measured compute;
  - per method (M1, InfoBatch, LERNA, random skipping), task and seed, the gap to that curve in
    accuracy points; per method and task, the mean gap, its SD, its 95% t-interval and the
    number of positive gaps;
  - the screening rule: a variant goes on to confirmation only if its mean gap is above 0 on
    both QNLI and SST-2.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_R13_DEV_CHECK 2026-11-06"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
RATE = 0.60
SEEDS = (11, 13, 17, 19, 23)
PLAIN_FRACTIONS = {"plain_030": 0.30, "plain_050": 0.50, "plain_070": 0.70}
HEADER = ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss",
          "forward_ran", "scheduled_batch_size", "scheduled_padded_tokens"]
TRAIN_ROWS = {"qnli": 104231, "sst-2": 67349}
BATCH_SIZE = 32
SHORT = {"qnli": "qnli", "sst-2": "sst2"}
CURVE_ARMS = ("plain_030", "reduced_steps", "plain_050", "equal_compute", "plain_070", "full_finetune")
METHODS = ("stale_s1_p4", "infobatch", "gate_s1_p4", "control_uniform_p4")
METHOD_LABEL = {"stale_s1_p4": "M1 (stale-score LERNA)", "infobatch": "InfoBatch",
                "gate_s1_p4": "LERNA (A1)", "control_uniform_p4": "random skipping (A2)"}
VARIANTS = ("stale_s1_p4", "infobatch")
STEP5_REUSED = ("full_finetune", "reduced_steps", "equal_compute", "gate_s1_p4", "control_uniform_p4")
STEP5_HORIZON = {"total_steps": 6548, "min_step": 392}
R12_PAIRS = {  # round-13 run -> round-12 smoke run (seed 11, full length)
    "qnli_stale_s1_p4_seed11": "qnli_full_stale_s1_p4",
    "qnli_infobatch_seed11": "qnli_full_infobatch",
    "sst2_full_finetune_seed11": "sst2_full_full_finetune",
    "sst2_stale_s1_p4_seed11": "sst2_full_stale_s1_p4",
    "sst2_infobatch_seed11": "sst2_full_infobatch",
}
# two-sided 95% t quantiles by degrees of freedom
T975 = {1: 12.706204736174698, 2: 4.302652729749464, 3: 3.182446305284263, 4: 2.7764451051977987}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm in ("full_finetune", "infobatch"):
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    elif arm in PLAIN_FRACTIONS:
        eff, skips = int(round(PLAIN_FRACTIONS[arm] * T)), 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def units_of(rows):
    """Compute units from batch-log rows of either format (6 or 9 fields)."""
    fwd = sum(int(x[2]) for x in rows if len(x) < 7 or int(x[6]) == 1)
    upd = sum(int(x[2]) for x in rows if int(x[4]) == 0)
    return fwd + 2 * upd


def check_run(p, end, out):
    name, task, arm, seed = p["name"], p["task"], p["arm"], p["seed"]
    gpu = end.get("gpu") if end else None
    fails, facts = [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    base = {"name": name, "task": task, "arm": arm, "seed": seed, "total_steps": p["total_steps"]}
    need(end is not None, "no end record in the ledger")
    if end is None:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    need(end["exit"] == 0, f"exit code {end['exit']}")
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return dict(base, ok=False, fails=fails, facts=facts, log_rows=[])
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(arm, p["total_steps"])
    for k, v in (("task", task), ("arm", arm), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", seed), ("total_steps", p["total_steps"]),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("precision", "fp32"), ("attention", "eager"), ("dry_run", False),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"] if task == "qnli" else None)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    if arm == "infobatch":
        need(c.get("infobatch_prune_ratio") == 0.5 and c.get("infobatch_anneal_fraction") == 0.875,
             "InfoBatch options are not 0.5 and 0.875")
    fskip = r.get("forward_skipped")
    dropped = r.get("examples_dropped_before_forward")
    need(isinstance(fskip, int) and isinstance(dropped, int), "forward_skipped / examples_dropped missing")
    fskip = fskip or 0
    dropped = dropped or 0
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == exp["effective_total"] - fskip, f"forwards={r.get('forwards')}, forward-free skips {fskip}")
    need(r.get("scheduler_advances") == exp["effective_total"], f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    if arm != "stale_s1_p4":
        need(fskip == 0, f"forward_skipped={fskip} for {arm}")
    if arm != "infobatch":
        need(dropped == 0, f"examples_dropped={dropped} for {arm}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    eff = exp["effective_total"]
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == HEADER, f"batch log header {header}")
        need(len(rows) == eff, f"batch log rows {len(rows)}, expected {eff}")
        ok_shape = all(len(x) == len(HEADER) for x in rows)
        need(ok_shape, "batch log rows don't all have 9 fields")
        if ok_shape and rows:
            need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
            need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
            free = [x for x in rows if int(x[6]) == 0]
            need(len(free) == fskip, f"batch log has {len(free)} forward-free skips, result {fskip}")
            need(all(int(x[4]) == 1 and x[5] == "nan" for x in free), "a forward-free row isn't a skip with a NaN loss")
            need(all(math.isfinite(float(x[5])) for x in rows if int(x[6]) == 1), "non-finite forward loss in the log")
            need(all(0 < int(x[1]) <= int(x[2]) for x in rows), "real tokens must be positive and at most the padded tokens")
            need(all(0 < int(x[3]) <= int(x[7]) <= BATCH_SIZE for x in rows), "batch sizes outside 1..scheduled..32")
            need(sum(int(x[7]) - int(x[3]) for x in rows) == dropped, "dropped examples in the log differ from the result")
            if arm != "infobatch":
                need(all(x[3] == x[7] and x[2] == x[8] for x in rows), "scheduled batch differs from the trained one")
            s = r.get("batch_log_summary") or {}
            need(s.get("compute_units_padded") == units_of(rows), "summary compute units differ from the log")
    sel = r.get("selection")
    n_train = TRAIN_ROWS.get(task)
    bpe = math.ceil(n_train / BATCH_SIZE) if n_train else None
    multi_epoch = bool(bpe) and eff > bpe
    if arm == "stale_s1_p4":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need((sel.get("stale_decisions") or 0) + (sel.get("fresh_decisions") or 0) == eff,
                 "stale + fresh decisions don't add up to the scheduled batches")
            need(sel.get("forward_skips") == fskip, "policy forward_skips differ from the result")
            if multi_epoch:
                need(fskip > 0, "no skip without a forward pass in a run longer than one epoch")
                need((sel.get("fresh_decisions") or 0) >= bpe, "fewer fresh decisions than one epoch of batches")
    elif arm == "infobatch":
        need(isinstance(sel, dict), "selection block missing")
        if isinstance(sel, dict):
            need(sel.get("num_examples") == n_train, f"num_examples={sel.get('num_examples')}, expected {n_train}")
            need(sel.get("batches_per_epoch") == bpe, f"batches_per_epoch={sel.get('batches_per_epoch')}, expected {bpe}")
            need(sel.get("stop_prune_step") == int(math.floor(0.875 * eff + 1e-9)), "stop_prune_step differs")
            need(sel.get("pruned_examples") == dropped, "policy pruned_examples differ from the result")
            need(len(sel.get("thresholds") or []) == math.ceil(eff / bpe), "one threshold per epoch expected")
            need(sel.get("empty_batch_fallbacks") == 0, f"empty_batch_fallbacks={sel.get('empty_batch_fallbacks')}")
            if multi_epoch:
                need(dropped > 0, "no example dropped in a run longer than one epoch")
    else:
        need(sel is None, f"unexpected selection block for {arm}")
    facts.update(accuracy=acc, loss=loss, wall_seconds=r.get("wall_seconds"), forward_skipped=fskip,
                 examples_dropped=dropped, units=units_of(rows) if rows else None)
    return dict(base, gpu=gpu, ok=not fails, fails=fails, facts=facts,
                manifest=str(mpath.relative_to(out)), log_rows=rows)


def load_reused(step5, arm, seed):
    """A Step 5 main-study QNLI run, lightly re-checked (the Step 5 checker verified it in full)."""
    name = f"{arm}_seed{seed}"
    res = {"name": f"step5:{name}", "task": "qnli", "arm": arm, "seed": seed, "fails": [], "facts": {}}
    found = sorted((step5 / "runs" / name).rglob("execution_manifest.json"))
    if len(found) != 1:
        res["fails"].append(f"{len(found)} manifests found")
        res["ok"] = False
        return res
    m = json.loads(found[0].read_text())
    c, r = m.get("config", {}), m.get("result", {})
    if m.get("status") != "OK":
        res["fails"].append(f"status {m.get('status')}")
    for k, v in (("task", "qnli"), ("arm", arm), ("policy_seed", seed),
                 ("total_steps", STEP5_HORIZON["total_steps"]), ("min_step", STEP5_HORIZON["min_step"])):
        if c.get(k) != v:
            res["fails"].append(f"config {k}={c.get(k)!r}, expected {v!r}")
    blf = m.get("batch_log_file") or {}
    lpath = found[0].parent / str(blf.get("file", "batch_log.csv"))
    rows = []
    if not lpath.is_file() or sha256_file(lpath) != blf.get("sha256"):
        res["fails"].append("batch log missing or its hash differs from the manifest")
    else:
        rows = read_log(lpath)[1]
    res["facts"] = {"accuracy": r.get("final_eval_accuracy"), "loss": r.get("final_eval_loss"),
                    "wall_seconds": r.get("wall_seconds"), "units": units_of(rows) if rows else None}
    res["ok"] = not res["fails"]
    return res


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def curve_at(points, c):
    """Straight lines through (compute, accuracy) points; None outside their range."""
    pts = sorted(points)
    if len(pts) < 2 or c < pts[0][0] - 1e-12 or c > pts[-1][0] + 1e-12:
        return None
    for (c0, a0), (c1, a1) in zip(pts, pts[1:]):
        if c0 - 1e-12 <= c <= c1 + 1e-12:
            return a0 if c1 == c0 else a0 + (a1 - a0) * (c - c0) / (c1 - c0)
    return None


def summarize_gaps(gaps):
    vals = [g for g in gaps.values() if isinstance(g, (int, float))]
    n = len(vals)
    m, sd = mean_sd(vals)
    out = {"n": n, "mean": m, "sd": sd, "positive": sum(1 for g in vals if g > 0), "by_seed": gaps}
    if n >= 2 and sd is not None and (n - 1) in T975:
        half = T975[n - 1] * sd / math.sqrt(n)
        out["ci95"] = [m - half, m + half]
    return out


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True)
    ap.add_argument("--step5", required=True, help="the Step 5 main study's folder (.../LERNA_step5_main/main)")
    ap.add_argument("--r12", required=True, help="round 12's smoke folder (.../LERNA_r12/smoke)")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json needed)", file=sys.stderr)
        return 2
    step5, r12 = Path(a.step5).resolve(), Path(a.r12).resolve()
    plan = json.loads((out / "plan.json").read_text())
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    runs = [check_run(p, ends.get(p["name"]), out) for p in plan["plan"]]
    reused = [load_reused(step5, arm, s) for arm in STEP5_REUSED for s in SEEDS]
    integrity_fails = []
    # reproduction of round 12's seed-11 runs
    repro = {}
    by_name = {x["name"]: x for x in runs}
    for mine, theirs in R12_PAIRS.items():
        x = by_name.get(mine)
        found = sorted((r12 / "runs" / theirs).rglob("execution_manifest.json"))
        if x is None or not x.get("log_rows") or len(found) != 1:
            repro[mine] = {"comparable": False}
            integrity_fails.append(f"reproduction of {theirs} not comparable")
            continue
        m = json.loads(found[0].read_text())
        old_rows = read_log(found[0].parent / "batch_log.csv")[1] if (found[0].parent / "batch_log.csv").is_file() else []
        rr = m.get("result", {})
        same = {"same_accuracy": rr.get("final_eval_accuracy") == x["facts"].get("accuracy"),
                "same_loss": rr.get("final_eval_loss") == x["facts"].get("loss"),
                "same_batch_log": old_rows == x["log_rows"]}
        repro[mine] = dict(comparable=True, **same)
        if not all(same.values()):
            integrity_fails.append(f"{mine} does not reproduce round 12's {theirs} bit for bit")
    # every run, new and reused, keyed by (task, arm, seed)
    table = {}
    for x in runs + reused:
        table[(x["task"], x["arm"], x["seed"])] = x
    for x in runs + reused:
        if not x["ok"]:
            integrity_fails.append(f"{x['name']}: " + "; ".join(x["fails"][:3]))
    # measured compute against full fine-tuning of the same task and seed
    for x in runs + reused:
        full = table.get((x["task"], "full_finetune", x["seed"]))
        u, fu = x["facts"].get("units"), (full or {}).get("facts", {}).get("units")
        x["facts"]["compute"] = (u / fu) if (u and fu and full.get("ok")) else None
    # the reading
    analysis = {}
    for task in ("qnli", "sst-2"):
        curves = {}
        for s in SEEDS:
            pts = []
            for arm in CURVE_ARMS:
                x = table.get((task, arm, s))
                if x and x["ok"] and isinstance(x["facts"].get("compute"), (int, float)):
                    pts.append((x["facts"]["compute"], 100.0 * x["facts"]["accuracy"]))
            curves[s] = pts
        methods = {}
        for meth in METHODS:
            gaps, comps, walls, accs, excluded = {}, [], [], [], {}
            for s in SEEDS:
                x = table.get((task, meth, s))
                if not x or not x["ok"]:
                    excluded[s] = "run missing or failed its checks"
                    continue
                c = x["facts"].get("compute")
                accs.append(100.0 * x["facts"]["accuracy"])
                walls.append(x["facts"].get("wall_seconds"))
                comps.append(c)
                cv = curve_at(curves[s], c) if isinstance(c, (int, float)) else None
                if len(curves[s]) < len(CURVE_ARMS):
                    excluded.setdefault(s, f"curve has {len(curves[s])} of {len(CURVE_ARMS)} points")
                if cv is None:
                    gaps[s] = "outside the curve"
                else:
                    gaps[s] = 100.0 * x["facts"]["accuracy"] - cv
            summ = summarize_gaps(gaps)
            summ.update(mean_compute=mean_sd(comps)[0], mean_accuracy=mean_sd(accs)[0], sd_accuracy=mean_sd(accs)[1],
                        mean_wall_seconds=mean_sd(walls)[0], notes=excluded)
            methods[meth] = summ
        arms = {}
        for arm in sorted({k[1] for k in table if k[0] == task}):
            xs = [table[(task, arm, s)] for s in SEEDS if (task, arm, s) in table and table[(task, arm, s)]["ok"]]
            arms[arm] = {"n": len(xs),
                         "mean_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[0],
                         "sd_accuracy": mean_sd([100.0 * x["facts"]["accuracy"] for x in xs])[1],
                         "mean_compute": mean_sd([x["facts"].get("compute") for x in xs])[0],
                         "mean_wall_seconds": mean_sd([x["facts"].get("wall_seconds") for x in xs])[0]}
        analysis[task] = {"methods": methods, "arms": arms,
                          "curves": {str(s): sorted(v) for s, v in curves.items()}}
    screening = {}
    for v in VARIANTS:
        ms = [analysis[t]["methods"][v].get("mean") for t in ("qnli", "sst-2")]
        enough = all(analysis[t]["methods"][v]["n"] >= 3 for t in ("qnli", "sst-2"))
        if not enough:
            screening[v] = "not enough seeds with a gap on both tasks: no reading"
        elif all(isinstance(m, (int, float)) and m > 0 for m in ms):
            screening[v] = "GOES ON to confirmation (mean gap above 0 on both tasks)"
        else:
            screening[v] = "STOPS (mean gap not above 0 on both tasks)"
    verdict = "PASS" if not integrity_fails else "FAIL"
    report = {"version": VERSION, "integrity": verdict, "integrity_fails": integrity_fails,
              "runs_ok": sum(1 for x in runs if x["ok"]), "runs_planned": len(runs),
              "reused_ok": sum(1 for x in reused if x["ok"]), "reused_expected": len(reused),
              "reproduction": repro, "analysis": analysis, "screening": screening,
              "runs": [{k: v for k, v in x.items() if k != "log_rows"} for x in runs],
              "reused": reused}
    (out / "check_report.json").write_text(json.dumps(report, indent=1, default=str))

    def num(v, fmt):
        return format(v, fmt) if isinstance(v, (int, float)) else "-"

    lines = [f"DEVELOPMENT ROUND CHECK ({VERSION}): integrity {verdict}; "
             f"{report['runs_ok']} of {len(runs)} new runs and {report['reused_ok']} of {len(reused)} reused Step 5 runs pass",
             "  reproduction of round 12 (seed 11): " +
             ", ".join(f"{k}: {'identical' if all(v.get(z) for z in ('same_accuracy', 'same_loss', 'same_batch_log')) else 'DIFFERS'}"
                       if v.get("comparable") else f"{k}: not comparable" for k, v in repro.items())]
    for task in ("qnli", "sst-2"):
        lines.append(f"  {task}: arms (mean accuracy %, SD, measured compute vs full, mean wall seconds)")
        for arm, d in analysis[task]["arms"].items():
            lines.append(f"    {arm:<20} n {d['n']}  {num(d['mean_accuracy'], '.2f'):>6}  sd {num(d['sd_accuracy'], '.2f'):>5}  "
                         f"compute {num(d['mean_compute'], '.3f'):>6}  wall {num(d['mean_wall_seconds'], '.0f'):>5}")
        lines.append(f"  {task}: gap to the plain-run curve, accuracy points (mean, 95% t-interval, positive seeds)")
        for meth in METHODS:
            d = analysis[task]["methods"][meth]
            ci = d.get("ci95")
            lines.append(f"    {METHOD_LABEL[meth]:<24} n {d['n']}  mean {num(d['mean'], '+.3f'):>7}  "
                         f"[{num(ci[0] if ci else None, '+.3f')}, {num(ci[1] if ci else None, '+.3f')}]  "
                         f"positive {d['positive']} of {d['n']}  compute {num(d['mean_compute'], '.3f')}")
            for s, why in d["notes"].items():
                lines.append(f"      seed {s}: {why}")
    lines.append("  screening rule (plan section 4): a variant goes on only if its mean gap is above 0 on both tasks")
    for v in VARIANTS:
        lines.append(f"    {METHOD_LABEL[v]}: {screening[v]}")
    for msg in integrity_fails:
        lines.append(f"  FAIL: {msg}")
    lines.append("  Development round: a screening result, not a claim. Confirmation needs untouched tasks.")
    text = "\n".join(lines)
    (out / "CHECK_SUMMARY.txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""LERNA round 13: the development round's launcher (6 November 2026).

It runs the development round fixed in claude/LERNA_R13_DEV_PLAN_2026-11-06.md, in qwen-v100,
one GPU per run, seeds 11, 13, 17, 19 and 23, with the Step 5 recipe (linear decay, warmup 6%
of each arm's length, eager attention, FP32):
  - QNLI (T=6548, min_step=392): M1 (stale_s1_p4), InfoBatch and the plain runs at 30%, 50% and
    70% of T: 25 runs. QNLI's other arms are the Step 5 main study's runs for the same seeds.
  - SST-2 (T=4210, min_step=252): full fine-tuning, LERNA (gate_s1_p4), random skipping
    (control_uniform_p4), M1, InfoBatch, the equal-compute and reduced plain runs, and the plain
    runs at 30%, 50% and 70%: 50 runs.
The 75 runs share one queue, longest first, and whichever GPU is free takes the next run. There
are no retries and no seed changes.

Each GPU has one private copy of each task's prepared cache, used by its runs one after
another, so no two runs ever write into the same cache at the same time.

With --resume on an existing --out it continues an interrupted launch. It skips the runs that
finished, never reruns a failed run, and holds back any run that started but has no end record
(an interrupted run), listing it for a decision.

It writes only into --out, which must not exist:
  ds_cache/   per GPU, one private copy of each task's prepared cache, checked byte for byte
  runs/       one output folder per run
  logs/       one log per run
  ledger.jsonl and DONE.json

Usage:
  python -s -B LERNA_R13_DEV_LAUNCH.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "LERNA_R13_DEV_LAUNCH 2026-11-06"
EXPECT = {
    "head": "c8e521688bf02bd52b4116f4e5feaa908eca2dc2",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
FILES = {
    "scripts/run_controller_ablation.py": "45eff33375018482c11ff2c99ac1ad0899eabe3a0ae757869f1602eb49b9fb37",
    "lerna/trainers/true_skip_trainer.py": "4c7b0cf6169065a2cdd0e82653edee08fd77292beb5f85a745b454f3ae09fcca",
    "lerna/utils/stale_selection.py": "f25e284b6c156eed38c73954ace55eec3bcc9c3876a4298911af7c8fcf036a3d",
    "lerna/utils/forward_gate.py": "8633b5fd4e985708c2c2facac56f0f60a0927de507da6ae096d83245dc47657c",
}
MODEL_REV = "45d08642849e5c5701b162671ac811b7654bfd9f"
GLUE_REV = "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c"
CACHE_FILES = ["dataset_info.json", "glue-train.arrow", "glue-validation.arrow", "glue-test.arrow"]
GLUE_CONFIG = {"qnli": "qnli", "sst-2": "sst2"}
SHORT = {"qnli": "qnli", "sst-2": "sst2"}
HORIZON = {"qnli": {"total_steps": 6548, "min_step": 392}, "sst-2": {"total_steps": 4210, "min_step": 252}}
SEEDS = (11, 13, 17, 19, 23)
# arm: score source, controller, phases
ARM_SPEC = {
    "full_finetune": ("uniform", "legacy_v4", 1),
    "gate_s1_p4": ("s1", "phase_exact_v1", 4),
    "control_uniform_p4": ("uniform", "phase_exact_v1", 4),
    "stale_s1_p4": ("s1_stale", "phase_exact_v1", 4),
    "infobatch": ("uniform", "legacy_v4", 1),
    "equal_compute": ("uniform", "legacy_v4", 1),
    "reduced_steps": ("uniform", "legacy_v4", 1),
    "plain_030": ("uniform", "legacy_v4", 1),
    "plain_050": ("uniform", "legacy_v4", 1),
    "plain_070": ("uniform", "legacy_v4", 1),
}
# (task, arm) in the order of their measured length in round 12, longest first
ORDER = [
    ("qnli", "infobatch"), ("qnli", "plain_070"), ("qnli", "stale_s1_p4"), ("qnli", "plain_050"),
    ("sst-2", "full_finetune"), ("qnli", "plain_030"), ("sst-2", "infobatch"), ("sst-2", "plain_070"),
    ("sst-2", "gate_s1_p4"), ("sst-2", "control_uniform_p4"), ("sst-2", "equal_compute"),
    ("sst-2", "stale_s1_p4"), ("sst-2", "plain_050"), ("sst-2", "reduced_steps"), ("sst-2", "plain_030"),
]
PLAN = [(f"{SHORT[task]}_{arm}_seed{seed}", task, seed, arm) + ARM_SPEC[arm] + (HORIZON[task],)
        for task, arm in ORDER for seed in SEEDS]
MIN_FREE_GB = 30
RUN_TIMEOUT = 3 * 3600


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def cache_dir(root, task):
    return Path(root) / "glue" / GLUE_CONFIG[task] / "0.0.0" / GLUE_REV


def command(a, name, task, seed, arm, source, controller, phases, horizon):
    cmd = [a.python, "-s", "-B", str(Path(a.repo) / "scripts" / "run_controller_ablation.py"),
           "--task", task, "--arm", arm, "--score-source", source, "--controller-version", controller,
           "--n-phases", str(phases), "--total-steps", str(horizon["total_steps"]),
           "--min-step", str(horizon["min_step"]), "--skip-rate", "0.60", "--max-consecutive-skips", "4",
           "--policy-seed", str(seed), "--lr-schedule-shape", "linear", "--lr-warmup-ratio", "0.06",
           "--device", "cuda",
           "--model-revision", MODEL_REV, "--tokenizer-revision", MODEL_REV, "--dataset-revision", GLUE_REV,
           "--output-dir", str(Path(a.out) / "runs" / name), "--attempt-id", name]
    if task == "qnli":
        cmd += ["--probe-exclusions-file", str(Path(a.repo) / "experiments" / "probe_indices_v4.json"),
                "--probe-exclusions-hash", EXPECT["probe_file_sha256"]]
    return cmd


def gpu_memory_used():
    r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=60)
    used = {}
    for line in r.stdout.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[0].isdigit():
            used[int(parts[0])] = int(float(parts[1]))
    return used


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--python", default="/raid/qwen-v100/bin/python")
    ap.add_argument("--source-cache", default="/raid/hf_cache/datasets")
    ap.add_argument("--skip-gpu-check", action="store_true", help="for tests only")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    ap.add_argument("--plan-names", nargs="*", default=None, help="run only these plan entries (tests)")
    ap.add_argument("--gpus", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    ap.add_argument("--resume", action="store_true", help="continue an interrupted launch in --out")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        if k in FILES:
            FILES[k] = v
        else:
            EXPECT[k] = v
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists() and not a.resume:
        print(f"--out {out} already exists; choose a new folder, or add --resume", file=sys.stderr)
        return 2
    if a.resume and not (out / "plan.json").is_file():
        print(f"--resume needs an earlier launch in {out}", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    problems = []
    head = git(repo, "rev-parse", "HEAD")
    if head != EXPECT["head"]:
        problems.append(f"HEAD is {head}, expected {EXPECT['head']}")
    if git(repo, "status", "--porcelain"):
        problems.append("the checkout is not clean")
    for rel, want in FILES.items():
        p = repo / rel
        if not p.is_file() or sha256_file(p) != want:
            problems.append(f"{rel} is missing or not the committed round-12 version")
    probe = repo / "experiments" / "probe_indices_v4.json"
    if not probe.is_file() or sha256_file(probe) != EXPECT["probe_file_sha256"]:
        problems.append("the probe file is missing or differs")
    plan = [p for p in PLAN if a.plan_names is None or p[0] in a.plan_names]
    gpus = [int(g) for g in a.gpus.split(",") if g.strip() != ""]
    if not a.skip_gpu_check:
        try:
            used = gpu_memory_used()
            busy = [g for g in gpus if used.get(g, 10 ** 9) >= 500]
            if busy:
                problems.append(f"GPUs not idle (>= 500 MiB used or missing): {busy}; memory used: {used}")
        except Exception as e:
            problems.append(f"nvidia-smi failed: {type(e).__name__}: {e}")
    try:
        free_gb = shutil.disk_usage(out if out.exists() else (out.parent if out.parent.exists() else "/")).free / 1e9
        if free_gb < a.min_free_gb:
            problems.append(f"only {free_gb:.1f} GB free under {out.parent}; at least {a.min_free_gb:g} GB needed")
    except Exception as e:
        problems.append(f"disk check failed: {type(e).__name__}: {e}")
    tasks = sorted({p[1] for p in plan})
    for task in tasks:
        src = cache_dir(a.source_cache, task)
        for f in CACHE_FILES:
            if not (src / f).is_file():
                problems.append(f"prepared cache file missing: {src / f}")
    if problems:
        for p in problems:
            print("STOP: " + p, file=sys.stderr)
        return 2

    held_back = []
    if a.resume:
        meta = json.loads((out / "plan.json").read_text())
        if [x["name"] for x in meta["plan"]] != [p[0] for p in plan]:
            print("STOP: the plan in plan.json differs from this launcher's plan", file=sys.stderr)
            return 2
        starts, ends = set(), {}
        for line in (out / "ledger.jsonl").read_text().splitlines():
            e = json.loads(line)
            if e["event"] == "start":
                starts.add(e["name"])
            elif e["event"] == "end":
                ends[e["name"]] = e
        held_back = sorted(n for n in starts if n not in ends)
        plan = [p for p in plan if p[0] not in starts]
        meta.setdefault("resumes", []).append({"time": now(), "argv": sys.argv, "finished": len(ends),
                                               "held_back_interrupted": held_back, "to_run": len(plan)})
        (out / "plan.json").write_text(json.dumps(meta, indent=1))
        print(json.dumps({"resume": True, "already_finished": len(ends), "interrupted_held_back": held_back,
                          "to_run": len(plan)}, indent=1))
    else:
        out.mkdir(parents=True)
        (out / "runs").mkdir()
        (out / "logs").mkdir()
        source_sha = {t: {f: sha256_file(cache_dir(a.source_cache, t) / f) for f in CACHE_FILES} for t in tasks}
        copies = {"source_sha256": source_sha, "gpus": {}}
        for g in gpus:
            for t in tasks:
                dst = cache_dir(out / "ds_cache" / f"gpu{g}", t)
                dst.mkdir(parents=True)
                for f in CACHE_FILES:
                    shutil.copy2(cache_dir(a.source_cache, t) / f, dst / f)
                same = all(sha256_file(dst / f) == source_sha[t][f] for f in CACHE_FILES)
                copies["gpus"][f"{g}/{t}"] = same
                if not same:
                    print(f"STOP: the private {t} cache copy for GPU {g} differs from its source", file=sys.stderr)
                    return 2
        meta = {"version": VERSION, "started": now(), "argv": sys.argv, "repo_head": head, "files": FILES,
                "python": a.python, "seeds": list(SEEDS), "gpus": gpus, "cache_copy": copies,
                "plan": [{"name": p[0], "task": p[1], "seed": p[2], "arm": p[3], "score_source": p[4],
                          "controller": p[5], "n_phases": p[6], **p[7]} for p in plan]}
        (out / "plan.json").write_text(json.dumps(meta, indent=1))

    env_base = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env_base.update({"HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                     "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false"})
    lock = threading.Lock()
    ledger = out / "ledger.jsonl"

    def record(entry):
        with lock:
            with open(ledger, "a") as f:
                f.write(json.dumps(entry) + "\n")

    queue = list(plan)

    def worker(gpu):
        while True:
            with lock:
                if not queue:
                    return
                p = queue.pop(0)
            name = p[0]
            cmd = command(a, *p)
            env = dict(env_base, CUDA_VISIBLE_DEVICES=str(gpu), HF_DATASETS_CACHE=str(out / "ds_cache" / f"gpu{gpu}"))
            t0 = time.time()
            record({"event": "start", "name": name, "gpu": gpu, "time": now(), "cmd": cmd})
            with open(out / "logs" / f"{name}.log", "wb") as log:
                try:
                    rc = subprocess.run(cmd, cwd=str(repo), env=env, stdout=log, stderr=subprocess.STDOUT,
                                        timeout=RUN_TIMEOUT).returncode
                except subprocess.TimeoutExpired:
                    rc = "timeout"
            manifests = sorted(str(m) for m in (out / "runs" / name).rglob("execution_manifest.json"))
            record({"event": "end", "name": name, "gpu": gpu, "time": now(), "exit": rc,
                    "seconds": round(time.time() - t0, 1), "manifests": manifests})

    threads = [threading.Thread(target=worker, args=(g,)) for g in gpus]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    ends = [json.loads(l) for l in ledger.read_text().splitlines() if '"event": "end"' in l]
    done = {"finished": now(), "runs": len(ends), "exit_zero": sum(1 for e in ends if e["exit"] == 0),
            "failed": [e["name"] for e in ends if e["exit"] != 0], "held_back_interrupted": held_back}
    (out / "DONE.json").write_text(json.dumps(done, indent=1))
    print(json.dumps(done, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

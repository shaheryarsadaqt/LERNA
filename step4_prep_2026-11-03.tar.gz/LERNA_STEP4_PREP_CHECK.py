#!/usr/bin/env python3
"""LERNA Step 4 preparation check, version 1 (3 November 2026). Read-only.

Collects what Step 4 needs, without downloading, training or changing anything:
  A. the environment and the git state of the checkout;
  B. the local Hugging Face cache: the Ettin model and GLUE snapshots, with every cached
     file checked against the content address it is stored under;
  C. offline loads: the model and tokenizer through the project's own loader
     (lerna.utils.model_loader), one forward pass on two short sentences, and the GLUE
     tasks through datasets.load_dataset, including QNLI's idx-equals-row check;
  D. a search for the original QNLI probe-exclusion file, and for records that mention
     the probe IDs or the pinned Ettin revision;
  E. the AdamW settings that the runner's TrainingArguments resolve to.

Usage (outside the repository):
  python -B LERNA_STEP4_PREP_CHECK.py --repo /home/nanhangproj/LERNA --out <new folder>

It forces offline mode and hides GPUs before importing any library. It writes only into
--out, which must not exist yet. It never writes into the repository, never unpickles a
file, and never edits, copies or moves a file it finds. Exit 0 means the report was
written, whatever it found; exit 2 means bad arguments or an existing --out.
"""
import os
import sys

FORCED_ENV = {
    "CUDA_VISIBLE_DEVICES": "",
    "HF_HUB_OFFLINE": "1",
    "HF_DATASETS_OFFLINE": "1",
    "TRANSFORMERS_OFFLINE": "1",
    "HF_HUB_DISABLE_TELEMETRY": "1",
    "TOKENIZERS_PARALLELISM": "false",
}
for _k, _v in FORCED_ENV.items():
    os.environ[_k] = _v
sys.dont_write_bytecode = True

import argparse
import datetime
import hashlib
import json
import platform
import re
import shutil
import subprocess
import time
import traceback
from pathlib import Path

VERSION = "LERNA_STEP4_PREP_CHECK v1 (2026-11-03)"
ACCEPTED_RUNNER_SHA256 = "50a967ba1de3b9c0ad8e705497709e64ea852990ea2490775f5b938c79a62df8"
EXPECTED_HEAD_PREFIX = "38ae658"
GLUE_TASKS = {"qnli": "qnli", "sst-2": "sst2", "mrpc": "mrpc", "rte": "rte"}
DATASET_IDS = ("glue", "nyu-mll/glue")
NAME_RE = re.compile(r"(exclu|probe)", re.IGNORECASE)
TEXT_EXT = {".json", ".jsonl", ".yaml", ".yml", ".txt", ".md", ".log", ".csv", ".tsv", ".cfg", ".ini", ".toml"}
NEVER_OPEN_EXT = {".pkl", ".pickle", ".pt", ".pth", ".bin", ".joblib", ".ckpt", ".safetensors"}
SKIP_DIRS = {".git", "__pycache__", ".kilo", "node_modules", "site-packages", ".cache", "miniconda3",
             "anaconda3", ".conda", "blobs", ".ipynb_checkpoints", ".venv", "venv"}
MAX_TEXT_SCAN = 5 * 1024 * 1024
MAX_HASH = 200 * 1024 * 1024
MAX_JSON_PARSE = 50 * 1024 * 1024
MAX_MATCHES_KEPT = 200


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def err(e):
    return f"{type(e).__name__}: {e}"[:800]


def run_cmd(cmd, timeout=60, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return {"cmd": cmd, "exit": p.returncode, "stdout": p.stdout[-20000:], "stderr": p.stderr[-4000:]}
    except FileNotFoundError as e:
        return {"cmd": cmd, "exit": None, "error": err(e)}
    except subprocess.TimeoutExpired:
        return {"cmd": cmd, "exit": None, "error": f"timed out after {timeout} s"}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def content_hashes(p):
    """SHA-256 and git-blob SHA-1 of a file, in one read."""
    size = p.stat().st_size
    h256, h1 = hashlib.sha256(), hashlib.sha1()
    h1.update(b"blob %d\0" % size)
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h256.update(chunk)
            h1.update(chunk)
    return h256.hexdigest(), h1.hexdigest(), size


# ----------------------------------------------------------------------------- A
def section_environment(repo, out):
    env = {
        "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "cpu_count": os.cpu_count(), "forced_env": FORCED_ENV,
        "hf_env": {k: os.environ.get(k) for k in ("HF_HOME", "HF_HUB_CACHE", "HUGGINGFACE_HUB_CACHE",
                                                  "TRANSFORMERS_CACHE", "HF_DATASETS_CACHE", "XDG_CACHE_HOME")},
    }
    try:
        env["meminfo"] = {l.split(":")[0]: l.split(":")[1].strip()
                          for l in Path("/proc/meminfo").read_text().splitlines()
                          if l.startswith(("MemTotal", "MemAvailable"))}
    except Exception as e:
        env["meminfo"] = err(e)
    versions = {}
    for name in ("torch", "transformers", "datasets", "accelerate", "tokenizers", "safetensors",
                 "huggingface_hub", "numpy", "pyarrow"):
        try:
            versions[name] = __import__(name).__version__
        except Exception as e:
            versions[name] = "not importable: " + err(e)
    env["versions"] = versions
    try:
        import torch
        env["torch_cuda_visible_to_this_process"] = bool(torch.cuda.is_available())
    except Exception as e:
        env["torch_cuda_visible_to_this_process"] = err(e)
    env["nvidia_smi"] = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,driver_version",
                                 "--format=csv"], timeout=30)
    disk = {}
    for p in {repo, Path.home(), out.parent}:
        try:
            disk[str(p)] = round(shutil.disk_usage(p).free / 1e9, 1)
        except Exception as e:
            disk[str(p)] = err(e)
    env["disk_free_gb"] = disk
    return env


def section_git(repo):
    g = {
        "head": run_cmd(["git", "-C", str(repo), "rev-parse", "HEAD"]),
        "log": run_cmd(["git", "-C", str(repo), "log", "--oneline", "-5"]),
        "status_porcelain": run_cmd(["git", "-C", str(repo), "status", "--porcelain"]),
        "exclusion_file_history": run_cmd(["git", "-C", str(repo), "log", "--all", "--date=iso",
                                           "--format=%H %ad %s", "--name-status", "--",
                                           ":(icase)*exclu*", ":(icase)*probe*"], timeout=120),
    }
    head = (g["head"].get("stdout") or "").strip()
    runner = repo / "scripts" / "run_controller_ablation.py"
    g["summary"] = {
        "head": head,
        "head_is_38ae658": head.startswith(EXPECTED_HEAD_PREFIX),
        "runner_sha256": sha256_file(runner) if runner.is_file() else None,
        "porcelain_entries": len([l for l in (g["status_porcelain"].get("stdout") or "").splitlines() if l.strip()]),
    }
    g["summary"]["runner_is_accepted"] = g["summary"]["runner_sha256"] == ACCEPTED_RUNNER_SHA256
    g["summary"]["tree_clean"] = g["summary"]["porcelain_entries"] == 0 and g["status_porcelain"].get("exit") == 0
    return g


# ----------------------------------------------------------------------------- B
def hub_cache_roots():
    env = os.environ
    cands = [env.get("HF_HUB_CACHE"), env.get("HUGGINGFACE_HUB_CACHE"), env.get("TRANSFORMERS_CACHE")]
    if env.get("HF_HOME"):
        cands.append(str(Path(env["HF_HOME"]) / "hub"))
    if env.get("XDG_CACHE_HOME"):
        cands.append(str(Path(env["XDG_CACHE_HOME"]) / "huggingface" / "hub"))
    cands.append(str(Path.home() / ".cache" / "huggingface" / "hub"))
    try:
        from huggingface_hub import constants
        cands.append(str(constants.HF_HUB_CACHE))
    except Exception:
        pass
    return dedupe_dirs(cands)


def datasets_cache_roots():
    env = os.environ
    cands = [env.get("HF_DATASETS_CACHE")]
    if env.get("HF_HOME"):
        cands.append(str(Path(env["HF_HOME"]) / "datasets"))
    cands.append(str(Path.home() / ".cache" / "huggingface" / "datasets"))
    try:
        import datasets.config
        cands.append(str(datasets.config.HF_DATASETS_CACHE))
    except Exception:
        pass
    return dedupe_dirs(cands)


def dedupe_dirs(cands):
    seen, roots = set(), []
    for c in cands:
        if not c:
            continue
        p = Path(c).expanduser()
        try:
            r = p.resolve()
        except Exception:
            continue
        if r.is_dir() and r not in seen:
            seen.add(r)
            roots.append(r)
    return roots


def scan_cached_repo(d):
    info = {"path": str(d), "refs": {}, "snapshots": {}}
    refs = d / "refs"
    if refs.is_dir():
        for r in sorted(refs.rglob("*")):
            if r.is_file():
                info["refs"][str(r.relative_to(refs))] = r.read_text().strip()
    snaps = d / "snapshots"
    if snaps.is_dir():
        for s in sorted(snaps.iterdir()):
            files = []
            for f in sorted(p for p in s.rglob("*") if p.is_file() or p.is_symlink()):
                entry = {"file": str(f.relative_to(s))}
                try:
                    target = f.resolve(strict=True)
                    blob = target.name if f.is_symlink() else None
                    if target.stat().st_size > 20 * 1024 ** 3:
                        entry.update(size=target.stat().st_size, content_check="not hashed (over 20 GB)")
                    else:
                        h256, h1, size = content_hashes(target)
                        entry.update(size=size, sha256=h256, blob=blob)
                        if blob and re.fullmatch(r"[0-9a-f]{64}", blob):
                            entry["content_check"] = "ok" if blob == h256 else "MISMATCH"
                        elif blob and re.fullmatch(r"[0-9a-f]{40}", blob):
                            entry["content_check"] = "ok" if blob == h1 else "MISMATCH"
                        else:
                            entry["content_check"] = "not checkable (not a link to a content-addressed blob)"
                except Exception as e:
                    entry["content_check"] = "ERROR " + err(e)
                files.append(entry)
            info["snapshots"][s.name] = files
    return info


def section_hf_cache():
    res = {"hub_cache_roots": [str(r) for r in hub_cache_roots()], "repos_in_cache": {}, "ettin": [], "glue": []}
    for root in hub_cache_roots():
        names = sorted(p.name for p in root.iterdir() if p.is_dir() and "--" in p.name)
        res["repos_in_cache"][str(root)] = names
        for n in names:
            low = n.lower()
            if low.startswith("models--") and "ettin" in low:
                res["ettin"].append(scan_cached_repo(root / n))
            elif low.startswith("datasets--") and "glue" in low:
                res["glue"].append(scan_cached_repo(root / n))
    ds_roots = datasets_cache_roots()
    res["datasets_cache_roots"] = [str(r) for r in ds_roots]
    listing = []
    for root in ds_roots:
        for dirpath, dirnames, filenames in os.walk(root):
            rel = Path(dirpath).relative_to(root)
            if len(rel.parts) >= 4:
                dirnames[:] = []
            if "glue" in str(rel).lower():
                size = 0
                for f in filenames:
                    try:
                        size += (Path(dirpath) / f).stat().st_size
                    except OSError:
                        pass
                listing.append({"dir": str(Path(dirpath)), "files": len(filenames), "bytes_here": size})
            if len(listing) >= 300:
                break
    res["datasets_cache_glue_dirs"] = listing
    return res


# ----------------------------------------------------------------------------- C
def section_model(repo):
    res = {}
    sys.path.insert(0, str(repo))
    try:
        from lerna.utils import ettin_constants as ec
        res["ETTIN_MODEL_ID"], res["ETTIN_REVISION"] = ec.ETTIN_MODEL_ID, ec.ETTIN_REVISION
        from lerna.utils.model_loader import load_tokenizer, load_model_and_tokenizer
    except Exception as e:
        res["import_error"] = err(e)
        res["traceback"] = traceback.format_exc()[-3000:]
        return res
    try:
        tok = load_tokenizer(ec.ETTIN_MODEL_ID, revision=ec.ETTIN_REVISION, local_files_only=True)
        res["tokenizer"] = {"ok": True, "class": type(tok).__name__, "pad_token_id": tok.pad_token_id,
                            "padding_side": getattr(tok, "padding_side", None), "vocab_len": len(tok),
                            "name_or_path": str(getattr(tok, "name_or_path", None))}
    except Exception as e:
        res["tokenizer"] = {"ok": False, "error": err(e), "traceback": traceback.format_exc()[-3000:]}
    try:
        import torch
        model, tok2 = load_model_and_tokenizer(ec.ETTIN_MODEL_ID, num_labels=2, revision=ec.ETTIN_REVISION,
                                               local_files_only=True)
        first = next(model.parameters())
        res["model"] = {"ok": True, "class": type(model).__name__,
                        "parameters": int(sum(p.numel() for p in model.parameters())),
                        "model_type": getattr(model.config, "model_type", None),
                        "attn_implementation": getattr(model.config, "_attn_implementation", None),
                        "dtype": str(first.dtype), "device": str(first.device),
                        "num_labels": getattr(model.config, "num_labels", None),
                        "note": "the classification head is newly initialised by design; warnings about it are expected"}
        try:
            model.eval()
            batch = tok2(["the film was fine", "a dull and tired story that never ends"],
                         padding=True, return_tensors="pt")
            with torch.no_grad():
                logits = model(**batch).logits
            res["model"]["forward"] = {"ok": True, "logits_shape": list(logits.shape),
                                       "finite": bool(torch.isfinite(logits).all())}
        except Exception as e:
            res["model"]["forward"] = {"ok": False, "error": err(e), "traceback": traceback.format_exc()[-3000:]}
        del model
    except Exception as e:
        res["model"] = {"ok": False, "error": err(e), "traceback": traceback.format_exc()[-3000:]}
    return res


def dataset_entry(ds, check_idx):
    e = {"ok": True, "num_rows": int(ds.num_rows), "columns": list(ds.column_names),
         "fingerprint": getattr(ds, "_fingerprint", None),
         "first_cache_file": (ds.cache_files[0].get("filename") if getattr(ds, "cache_files", None) else None)}
    if check_idx:
        if "idx" not in ds.column_names:
            e["idx_equals_row"] = "no idx column"
        else:
            idx = list(ds["idx"])
            bad = next((i for i, v in enumerate(idx) if int(v) != i), None)
            e["idx_equals_row"] = bad is None
            if bad is not None:
                e["first_idx_mismatch_row"] = bad
    return e


def section_datasets(glue_revisions):
    res = {"tried": []}
    try:
        from datasets import load_dataset
    except Exception as e:
        res["import_error"] = err(e)
        return res
    revs = list(dict.fromkeys(glue_revisions))
    for dataset_id in DATASET_IDS:
        for rev in revs:
            for task, cfg in GLUE_TASKS.items():
                for split in ("train", "validation"):
                    item = {"dataset_id": dataset_id, "revision": rev, "task": task, "config": cfg, "split": split}
                    try:
                        ds = load_dataset(dataset_id, cfg, split=split, revision=rev)
                        item.update(dataset_entry(ds, check_idx=(task == "qnli" and split == "train")))
                    except Exception as e:
                        item.update(ok=False, error=err(e))
                    res["tried"].append(item)
        for task, cfg in (("qnli", "qnli"), ("sst-2", "sst2")):
            item = {"dataset_id": dataset_id, "revision": None, "task": task, "config": cfg, "split": "train",
                    "note": "without a revision; for information only (the runner requires a 40-hex revision)"}
            try:
                ds = load_dataset(dataset_id, cfg, split="train")
                item.update(dataset_entry(ds, check_idx=False))
            except Exception as e:
                item.update(ok=False, error=err(e))
            res["tried"].append(item)
    return res


# ----------------------------------------------------------------------------- D
def summarize_json(obj, depth=0):
    if isinstance(obj, dict):
        s = {"type": "object", "n_keys": len(obj)}
        keys = list(obj)[:40]
        s["keys"] = {str(k): summarize_json(obj[k], depth + 1) for k in keys} if depth < 2 else [str(k) for k in keys]
        return s
    if isinstance(obj, list):
        s = {"type": "list", "len": len(obj)}
        ints = [x for x in obj if isinstance(x, int) and not isinstance(x, bool)]
        if obj and len(ints) == len(obj):
            s.update(all_int=True, min=min(ints), max=max(ints), unique=len(set(ints)))
        else:
            s["element_types"] = sorted({type(x).__name__ for x in obj[:1000]})
        return s
    if isinstance(obj, str):
        return {"type": "str", "len": len(obj), "start": obj[:80]}
    return {"type": type(obj).__name__, "value": obj}


def runner_format_check(obj, qnli_train_rows):
    """The same checks as the runner's QNLI preflight, plus the row bound the loader applies."""
    if not (isinstance(obj, dict) and "probe_s_ids" in obj and "probe_e_ids" in obj):
        return None
    reasons = []
    s, e = obj["probe_s_ids"], obj["probe_e_ids"]
    for key, lst in (("probe_s_ids", s), ("probe_e_ids", e)):
        if not isinstance(lst, list):
            reasons.append(f"{key} is not a list")
            continue
        if not lst:
            reasons.append(f"{key} is empty")
        if any(isinstance(x, bool) or not isinstance(x, int) or x < 0 for x in lst):
            reasons.append(f"{key} has an entry that is not a non-negative integer")
    out = {"probe_s_ids_len": len(s) if isinstance(s, list) else None,
           "probe_e_ids_len": len(e) if isinstance(e, list) else None}
    if not reasons:
        ss, es = set(s), set(e)
        if ss & es:
            reasons.append(f"probe_s_ids and probe_e_ids overlap in {len(ss & es)} IDs")
        union = ss | es
        out.update(union=len(union), max_id=max(union))
        if isinstance(qnli_train_rows, int) and max(union) >= qnli_train_rows:
            reasons.append(f"max id {max(union)} >= QNLI train rows {qnli_train_rows}")
    out["passes_runner_checks"] = not reasons
    out["reasons"] = reasons
    return out


def describe_candidate(p, qnli_train_rows):
    d = {"path": str(p)}
    try:
        st = p.stat()
    except OSError as e:
        d["error"] = err(e)
        return d
    d["size"] = st.st_size
    d["mtime"] = datetime.datetime.fromtimestamp(st.st_mtime).astimezone().isoformat(timespec="seconds")
    if st.st_size <= MAX_HASH:
        try:
            d["sha256"] = sha256_file(p)
        except OSError as e:
            d["sha256"] = err(e)
    suffix = p.suffix.lower()
    if suffix in NEVER_OPEN_EXT:
        d["note"] = "binary; not opened (never unpickled)"
    elif suffix in (".npy", ".npz"):
        try:
            import numpy as np
            arr = np.load(p, allow_pickle=False, mmap_mode="r") if suffix == ".npy" else np.load(p, allow_pickle=False)
            if suffix == ".npy":
                d["npy"] = {"shape": list(arr.shape), "dtype": str(arr.dtype)}
            else:
                d["npz"] = {k: {"shape": list(arr[k].shape), "dtype": str(arr[k].dtype)} for k in list(arr.files)[:20]}
        except Exception as e:
            d["npy_error"] = err(e)
    elif suffix == ".json" and st.st_size <= MAX_JSON_PARSE:
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
            d["json_summary"] = summarize_json(obj)
            fmt = runner_format_check(obj, qnli_train_rows)
            if fmt is not None:
                d["runner_format"] = fmt
        except Exception as e:
            d["json_error"] = err(e)
    elif suffix in TEXT_EXT and st.st_size <= MAX_TEXT_SCAN:
        try:
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            d["text"] = {"lines": len(lines), "first_line": (lines[0][:200] if lines else "")}
        except Exception as e:
            d["text_error"] = err(e)
    return d


def search_root(root, max_depth, seconds, patterns, exclude, qnli_train_rows):
    res = {"root": str(root), "max_depth": max_depth, "seconds_allowed": seconds, "exists": root.is_dir(),
           "excluded": [str(x) for x in exclude], "name_matches": [], "name_matches_total": 0,
           "content_matches": [], "content_matches_total": 0, "files_seen": 0, "truncated": False}
    if not root.is_dir():
        return res
    deadline = time.time() + seconds
    pats = [(p, p.encode()) for p in patterns]
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        here = Path(dirpath)
        if any(here == x or x in here.parents for x in exclude):
            dirnames[:] = []
            continue
        depth = len(here.relative_to(root).parts)
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("checkpoint-"))
        if max_depth is not None and depth >= max_depth:
            dirnames[:] = []
        for f in sorted(filenames):
            p = here / f
            res["files_seen"] += 1
            if NAME_RE.search(f) and p.suffix.lower() != ".py":
                res["name_matches_total"] += 1
                if len(res["name_matches"]) < MAX_MATCHES_KEPT:
                    res["name_matches"].append(describe_candidate(p, qnli_train_rows))
            if p.suffix.lower() in TEXT_EXT:
                try:
                    if p.is_symlink() or p.stat().st_size > MAX_TEXT_SCAN:
                        continue
                    data = p.read_bytes()
                except OSError:
                    continue
                hit = [s for s, b in pats if b in data]
                if hit:
                    res["content_matches_total"] += 1
                    if len(res["content_matches"]) < MAX_MATCHES_KEPT:
                        line = next((l for l in data.decode("utf-8", "replace").splitlines()
                                     if any(s in l for s in hit)), "")
                        entry = {"path": str(p), "patterns": hit, "line": line.strip()[:300]}
                        if {"probe_s_ids", "probe_e_ids"} <= set(hit) and p.suffix.lower() == ".json":
                            entry["candidate"] = describe_candidate(p, qnli_train_rows)
                        res["content_matches"].append(entry)
            if time.time() > deadline:
                res["truncated"] = True
                return res
    return res


# ----------------------------------------------------------------------------- E
def section_optimizer(out):
    res = {}
    try:
        from transformers import TrainingArguments
        ta = TrainingArguments(output_dir=str(out / "training_args_probe"), max_steps=1, learning_rate=2e-5,
                               per_device_train_batch_size=32, gradient_accumulation_steps=1, warmup_steps=12,
                               weight_decay=0.01, lr_scheduler_type="constant_with_warmup", max_grad_norm=1.0,
                               optim="adamw_torch", eval_strategy="no", save_strategy="no", logging_strategy="no",
                               report_to=[], disable_tqdm=True, use_cpu=True, seed=0, fp16=False, bf16=False)
        for k in ("optim", "adam_beta1", "adam_beta2", "adam_epsilon", "weight_decay", "max_grad_norm",
                  "lr_scheduler_type", "warmup_steps", "optim_args"):
            v = getattr(ta, k, "absent")
            res[k] = v if isinstance(v, (int, float, str, type(None))) else str(v)
        res["note"] = ("built with the runner's TrainingArguments settings; betas and epsilon are the "
                       "library defaults, because the runner does not set them")
    except Exception as e:
        res["error"] = err(e)
        res["traceback"] = traceback.format_exc()[-3000:]
    return res


# ----------------------------------------------------------------------------- summary
def glance(rep):
    m, hf = rep.get("model", {}), rep.get("hf_cache", {})
    rev = m.get("ETTIN_REVISION")
    snaps = [r["snapshots"][rev] for r in hf.get("ettin", []) if rev in r.get("snapshots", {})]
    verified = bool(snaps) and all(f.get("content_check") == "ok" for files in snaps for f in files)
    loads = bool(m.get("tokenizer", {}).get("ok") and m.get("model", {}).get("ok")
                 and m.get("model", {}).get("forward", {}).get("ok"))
    ok_sets = {}
    for i in rep.get("datasets", {}).get("tried", []):
        if i.get("ok") and i.get("revision"):
            ok_sets.setdefault((i["dataset_id"], i["revision"]), set()).add((i["task"], i["split"]))
    full = [f"{d} @ {r}" for (d, r), got in ok_sets.items() if len(got) == 2 * len(GLUE_TASKS)]
    part = [f"{d} @ {r} ({len(got)} of {2 * len(GLUE_TASKS)})" for (d, r), got in ok_sets.items()
            if len(got) < 2 * len(GLUE_TASKS)]
    cands = []
    for srch in rep.get("search", []):
        for c in srch.get("name_matches", []):
            if (c.get("runner_format") or {}).get("passes_runner_checks"):
                cands.append(c["path"])
        for c in srch.get("content_matches", []):
            if ((c.get("candidate") or {}).get("runner_format") or {}).get("passes_runner_checks"):
                cands.append(c["path"])
    cands = list(dict.fromkeys(cands))
    g = rep.get("git", {}).get("summary", {})
    return ["AT A GLANCE",
            f"   model and tokenizer pin {rev}: cached {bool(snaps)}, all files of that snapshot verified {verified}, "
            f"loads offline with one forward pass {loads}",
            f"   GLUE revisions that load offline for all four tasks, train and validation: {full or 'none'}"
            + (f"; partly: {part}" if part else ""),
            f"   QNLI exclusion files that pass the runner's checks: {len(cands)}"
            + "".join(f"\n      {c}" for c in cands[:10]),
            f"   git: HEAD {g.get('head')}, accepted runner {g.get('runner_is_accepted')}, tree clean {g.get('tree_clean')}",
            ""]


def summary_lines(rep):
    L = [VERSION, f"started {rep['started']}, finished {rep.get('finished')}",
         f"script sha256 {rep['script_sha256']}", ""]
    try:
        L += glance(rep)
    except Exception as e:
        L += ["AT A GLANCE could not be built: " + err(e), ""]
    g = rep.get("git", {}).get("summary", {})
    L += ["1. Git", f"   HEAD {g.get('head')} (expected {EXPECTED_HEAD_PREFIX}...: {g.get('head_is_38ae658')})",
          f"   accepted runner (50a967ba...): {g.get('runner_is_accepted')}",
          f"   tree clean: {g.get('tree_clean')} ({g.get('porcelain_entries')} entries in git status --porcelain)", ""]
    m = rep.get("model", {})
    hf = rep.get("hf_cache", {})
    rev = m.get("ETTIN_REVISION")
    L.append(f"2. Model and tokenizer {m.get('ETTIN_MODEL_ID')} @ {rev}")
    if not hf.get("ettin"):
        L.append("   no Ettin model folder in the Hugging Face cache")
    for r in hf.get("ettin", []):
        checks = [f.get("content_check", "") for files in r["snapshots"].values() for f in files]
        L.append(f"   cache folder {r['path']}")
        L.append(f"   refs {r['refs']}; snapshots {list(r['snapshots'])}")
        L.append(f"   pinned revision cached: {rev in r['snapshots']}; files ok {checks.count('ok')}, "
                 f"MISMATCH {checks.count('MISMATCH')}, other {len(checks) - checks.count('ok') - checks.count('MISMATCH')}")
    if "import_error" in m:
        L.append(f"   project loader import FAILED: {m['import_error']}")
    t, mo = m.get("tokenizer", {}), m.get("model", {})
    L.append(f"   tokenizer load: {'ok' if t.get('ok') else 'FAILED ' + str(t.get('error'))}"
             + (f" ({t.get('class')}, pad_token_id {t.get('pad_token_id')}, padding_side {t.get('padding_side')})"
                if t.get("ok") else ""))
    L.append(f"   model load: {'ok' if mo.get('ok') else 'FAILED ' + str(mo.get('error'))}"
             + (f" ({mo.get('class')}, {mo.get('parameters'):,} parameters, attention {mo.get('attn_implementation')}, "
                f"{mo.get('dtype')})" if mo.get("ok") else ""))
    fw = mo.get("forward", {})
    if mo.get("ok"):
        L.append(f"   one forward pass: {'ok, logits ' + str(fw.get('logits_shape')) + ', finite ' + str(fw.get('finite')) if fw.get('ok') else 'FAILED ' + str(fw.get('error'))}")
    L.append("")
    L.append("3. GLUE")
    if not hf.get("glue"):
        L.append("   no GLUE dataset folder in the Hugging Face hub cache")
    for r in hf.get("glue", []):
        checks = [f.get("content_check", "") for files in r["snapshots"].values() for f in files]
        L.append(f"   cache folder {r['path']}; refs {r['refs']}; snapshots {list(r['snapshots'])}")
        L.append(f"   files ok {checks.count('ok')}, MISMATCH {checks.count('MISMATCH')}, "
                 f"other {len(checks) - checks.count('ok') - checks.count('MISMATCH')}")
    for item in rep.get("datasets", {}).get("tried", []):
        if item.get("ok"):
            extra = f", idx equals row: {item['idx_equals_row']}" if "idx_equals_row" in item else ""
            L.append(f"   ok  {item['dataset_id']} @ {item['revision']} {item['config']}/{item['split']}: "
                     f"{item['num_rows']:,} rows{extra}")
    n_fail = sum(1 for i in rep.get("datasets", {}).get("tried", []) if not i.get("ok"))
    L.append(f"   ({n_fail} other combinations did not load offline; see report.json)")
    L.append("")
    L.append("4. QNLI exclusion file and related records")
    for s in rep.get("search", []):
        L.append(f"   {s['root']}: exists {s['exists']}, {s['files_seen']:,} files seen, truncated {s['truncated']}, "
                 f"{s['name_matches_total']} name matches, {s['content_matches_total']} content matches")
        for c in s["name_matches"][:25]:
            fmt = c.get("runner_format")
            tag = (" RUNNER FORMAT, passes checks: " + str(fmt["passes_runner_checks"])) if fmt else ""
            L.append(f"      name: {c['path']} ({c.get('size')} bytes, sha256 {str(c.get('sha256'))[:16]}...){tag}")
        for c in s["content_matches"][:25]:
            L.append(f"      text: {c['path']} {c['patterns']}")
    L.append("")
    o = rep.get("optimizer", {})
    L.append(f"5. AdamW as the runner builds it: optim {o.get('optim')}, betas ({o.get('adam_beta1')}, "
             f"{o.get('adam_beta2')}), epsilon {o.get('adam_epsilon')}" + (f"; ERROR {o['error']}" if "error" in o else ""))
    L.append("")
    e = rep.get("environment", {})
    smi = e.get("nvidia_smi", {})
    L.append("6. Environment")
    L.append(f"   CPUs {e.get('cpu_count')}, memory {e.get('meminfo')}, disk free (GB) {e.get('disk_free_gb')}")
    L.append(f"   versions {e.get('versions')}")
    L.append("   nvidia-smi: " + ((smi.get("stdout") or "").strip().replace("\n", " | ") or str(smi.get("error"))))
    if rep.get("section_errors"):
        L += ["", "Sections that raised (details in report.json):"] + [f"   {k}: {v}" for k, v in rep["section_errors"].items()]
    return L


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--search-root", action="append", default=[],
                    help="extra folder to search for the QNLI exclusion file (repeatable)")
    a = ap.parse_args()
    repo, out = Path(a.repo).resolve(), Path(a.out).resolve()
    if not (repo / "scripts" / "run_controller_ablation.py").is_file():
        print(f"--repo {repo} does not look like the LERNA checkout", file=sys.stderr)
        return 2
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if out == repo or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "cwd": os.getcwd(),
           "script_sha256": sha256_file(Path(__file__).resolve()), "section_errors": {}}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e), "traceback": traceback.format_exc()[-3000:]}
            rep["section_errors"][name] = err(e)
        rep.setdefault("seconds", {})[name] = round(time.time() - t0, 1)
        save()
        print(f"[{now()}] {name} done in {rep['seconds'][name]} s", flush=True)

    section("environment", section_environment, repo, out)
    section("git", section_git, repo)
    section("hf_cache", section_hf_cache)
    section("model", section_model, repo)
    glue_revs = [sha for r in (rep.get("hf_cache") or {}).get("glue", []) for sha in r.get("snapshots", {})]
    section("datasets", section_datasets, glue_revs)
    qnli_rows = next((i["num_rows"] for i in (rep.get("datasets") or {}).get("tried", [])
                      if i.get("ok") and i["task"] == "qnli" and i["split"] == "train" and i["revision"]), None)
    patterns = ["probe_s_ids", "probe_e_ids", "probe_exclusion", "exclusion_probe", "excluded_probe",
                "matched_probe", "matched-probe", "45d08642"]
    own = [out] if out.parent == repo.parent else [out, out.parent]
    stage2, sst2 = Path("/raid/stage2_confirmatory"), Path("/raid/sst2_replication")
    roots = [(repo, None, 180, own),
             (stage2, None, 300, own),
             (sst2, None, 180, own),
             (Path("/raid"), 2, 60, own + [stage2, sst2]),
             (repo.parent, 3, 120, own + [repo])]
    roots += [(Path(r).resolve(), None, 300, own) for r in a.search_root]

    def do_search():
        return [search_root(r, d, s, patterns, x, qnli_rows) for r, d, s, x in roots]
    section("search", do_search)
    section("optimizer", section_optimizer, out)
    rep["finished"] = now()
    save()
    (out / "SUMMARY.txt").write_text("\n".join(summary_lines(rep)) + "\n")
    print((out / "SUMMARY.txt").read_text())
    return 0


if __name__ == "__main__":
    sys.exit(main())

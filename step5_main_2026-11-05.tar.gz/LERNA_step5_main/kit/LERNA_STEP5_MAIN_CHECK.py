#!/usr/bin/env python3
"""LERNA Step 5, round 11: checks and the pre-specified analysis of the main study (5 November 2026). Read-only.

It reads the launcher's folder (plan.json, ledger.jsonl, runs/, logs/) and writes only
check_report.json and CHECK_SUMMARY.txt into that folder. Exit 0 means the report was
written; the verdict is inside it. Exit 2 means the folder isn't a finished launcher folder.

Per run, it checks:
  - the exit code and the manifest status;
  - the config: arm, controller, phases, score source, seed, recipe, revisions, device;
  - the exact counts: forwards, backwards, skips and scheduler steps;
  - the warmup steps, and that the final LR is 0;
  - the runtime block: interpreter, versions, GPU, parameter count, LayerNorm biases,
    attention, AdamW betas and eps, the pinned GPU;
  - the batch log: its row count, its hash, its skip count, and the sanity of its tokens.
It then runs the analysis fixed in claude/LERNA_STEP5_ANALYSIS_PLAN_2026-11-05.md (sections
4-7), on the runs that pass every check:
  - co-primary C1 = A1 - A2 and C2 = A1 - A9, paired by seed, in accuracy points: mean, SD,
    95% paired t-interval, two-sided paired t-test, Holm across the two, and a percentile
    bootstrap interval (10,000 resamples of seeds, resampling seed 20261105);
  - the eight secondary contrasts, exploratory and uncorrected;
  - the reading of C1 and C2 by the plan's fixed rule;
  - the table of all nine arms;
  - the reproduction of the pilot's seeds 11, 13 and 17 (--reference), batch log by batch log.
If any arm loses more than 2 of the 24 seeds, it withholds the contrasts (plan section 6).
"""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

VERSION = "LERNA_STEP5_MAIN_CHECK 2026-11-05"
EXPECT = {
    "executable_prefix": "/raid/qwen-v100/",
    "torch": "2.7.1+cu126",
    "transformers": "4.56.0",
    "datasets": "5.0.1",
    "device": "cuda",
    "model_device": "cuda:0",
    "gpu_name_contains": "V100",
    "parameters": "149606402",
    "attn_implementation": "eager",
    "model_revision": "45d08642849e5c5701b162671ac811b7654bfd9f",
    "dataset_revision": "bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c",
    "probe_file_sha256": "234d1a48c822894e954d442d05ee6ff91d3c0569db191fde8e3a8a86aeb2d408",
}
RATE = 0.60


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_counts(arm, T):
    q = int(round(RATE * T))
    if arm == "full_finetune":
        eff, skips = T, 0
    elif arm == "reduced_steps":
        eff, skips = T - q, 0
    elif arm == "equal_compute":
        eff, skips = T - (2 * q + 2) // 3, 0
    else:
        eff, skips = T, q
    return {"effective_total": eff, "skipped": skips, "backwards": eff - skips,
            "warmup": int(math.floor(0.06 * eff + 1e-9))}


def read_log(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def check_run(p, end, out):
    name = p["name"]
    gpu = end.get("gpu") if end else None
    fails, notes, facts = [], [], {}

    def need(cond, msg):
        if not cond:
            fails.append(msg)

    need(end is not None, "no end record in the ledger")
    if end is None:
        return {"name": name, "ok": False, "fails": fails}
    need(end["exit"] == 0, f"exit code {end['exit']}")
    # Found relative to the launcher folder, so the check also works on a moved or unpacked copy.
    found = sorted((out / "runs" / name).rglob("execution_manifest.json"))
    need(len(found) == 1, f"{len(found)} execution manifests found")
    if len(found) != 1:
        return {"name": name, "ok": False, "fails": fails}
    mpath = found[0]
    m = json.loads(mpath.read_text())
    need(m.get("status") == "OK", f"status {m.get('status')}: {str(m.get('reason'))[:300]}")
    c, r, rt = m.get("config", {}), m.get("result", {}), m.get("runtime", {})
    exp = expected_counts(p["arm"], p["total_steps"])
    # config
    for k, v in (("arm", p["arm"]), ("controller_version", p["controller"]), ("n_phases", p["n_phases"]),
                 ("score_source", p["score_source"]), ("policy_seed", p["seed"]), ("total_steps", p["total_steps"]),
                 ("min_step", p["min_step"]), ("lr_schedule_shape", "linear"), ("lr_warmup_ratio", 0.06),
                 ("device", EXPECT["device"]), ("model_revision", EXPECT["model_revision"]),
                 ("tokenizer_revision", EXPECT["model_revision"]), ("dataset_revision", EXPECT["dataset_revision"]),
                 ("probe_exclusions_hash", EXPECT["probe_file_sha256"]), ("precision", "fp32"),
                 ("attention", "eager"), ("dry_run", False)):
        need(c.get(k) == v, f"config {k}={c.get(k)!r}, expected {v!r}")
    # counts and schedule
    for k in ("effective_total", "skipped", "backwards"):
        need(r.get(k) == exp[k], f"{k}={r.get(k)}, expected {exp[k]}")
    need(r.get("forwards") == exp["effective_total"], f"forwards={r.get('forwards')}")
    need(r.get("scheduler_advances") == exp["effective_total"], f"scheduler_advances={r.get('scheduler_advances')}")
    need(r.get("optimizer_updates") == exp["backwards"], f"optimizer_updates={r.get('optimizer_updates')}")
    need(r.get("lr_warmup_steps") == exp["warmup"], f"lr_warmup_steps={r.get('lr_warmup_steps')}, expected {exp['warmup']}")
    flr = r.get("final_learning_rate")
    need(isinstance(flr, (int, float)) and abs(flr) < 1e-12, f"final_learning_rate={flr}")
    acc, loss = r.get("final_eval_accuracy"), r.get("final_eval_loss")
    need(isinstance(acc, (int, float)) and 0.0 <= acc <= 1.0, f"final_eval_accuracy={acc}")
    need(isinstance(loss, (int, float)) and math.isfinite(loss), f"final_eval_loss={loss}")
    # runtime block
    need(str(rt.get("executable", "")).startswith(EXPECT["executable_prefix"]), f"executable={rt.get('executable')}")
    v = rt.get("versions", {})
    for k in ("torch", "transformers", "datasets"):
        need(v.get(k) == EXPECT[k], f"{k} version {v.get(k)}, expected {EXPECT[k]}")
    need(rt.get("device") == EXPECT["device"], f"runtime device {rt.get('device')}")
    need(rt.get("model_device") == EXPECT["model_device"], f"model_device {rt.get('model_device')}")
    if EXPECT["gpu_name_contains"]:
        need(EXPECT["gpu_name_contains"] in str((rt.get("cuda") or {}).get("name", "")), f"GPU {(rt.get('cuda') or {}).get('name')}")
        need(str(rt.get("cuda_visible_devices")) == str(gpu), f"CUDA_VISIBLE_DEVICES={rt.get('cuda_visible_devices')}, ledger {gpu}")
        need((rt.get("cuda") or {}).get("device_count") == 1, f"visible GPUs {(rt.get('cuda') or {}).get('device_count')}")
    need(str(rt.get("parameters")) == EXPECT["parameters"], f"parameters={rt.get('parameters')}")
    need(rt.get("layernorms_with_bias") == 0, f"layernorms_with_bias={rt.get('layernorms_with_bias')}")
    if EXPECT["attn_implementation"]:
        need(rt.get("attn_implementation") == EXPECT["attn_implementation"], f"attn_implementation={rt.get('attn_implementation')}")
    opt = rt.get("optimizer") or {}
    need(opt.get("betas") == [0.9, 0.999], f"betas={opt.get('betas')}")
    need(isinstance(opt.get("eps"), (int, float)) and abs(opt["eps"] - 1e-8) < 1e-15, f"eps={opt.get('eps')}")
    # batch log
    blf = m.get("batch_log_file") or {}
    lpath = mpath.parent / str(blf.get("file", "batch_log.csv"))
    need(lpath.is_file(), "batch_log.csv missing")
    rows = []
    if lpath.is_file():
        need(sha256_file(lpath) == blf.get("sha256"), "batch_log.csv hash differs from the manifest")
        header, rows = read_log(lpath)
        need(header == ["decision_index", "real_tokens", "padded_tokens", "batch_size", "skipped", "forward_loss"],
             f"batch log header {header}")
        need(len(rows) == exp["effective_total"], f"batch log rows {len(rows)}, expected {exp['effective_total']}")
        need([int(x[0]) for x in rows] == list(range(len(rows))), "batch log indices aren't 0..N-1")
        need(sum(int(x[4]) for x in rows) == exp["skipped"], "batch log skip count differs")
        need(all(0 < int(x[1]) <= int(x[2]) for x in rows), "real tokens must be positive and at most the padded tokens")
        need(all(0 < int(x[3]) <= 32 for x in rows), "batch sizes outside 1..32")
        need(all(math.isfinite(float(x[5])) for x in rows), "non-finite forward loss in the log")
        s = r.get("batch_log_summary") or {}
        facts["compute_units_padded"] = s.get("compute_units_padded")
        facts["padded_tokens_all"] = s.get("padded_tokens_all")
    facts.update(accuracy=acc, loss=loss, wall_seconds=r.get("wall_seconds"),
                 seconds_per_step=(r.get("wall_seconds") / exp["effective_total"]) if r.get("wall_seconds") else None,
                 run_seconds=end.get("seconds"), cuda=rt.get("cuda"), cudnn_deterministic=rt.get("cudnn_deterministic"))
    if p["total_steps"] == 6548 and isinstance(acc, (int, float)) and acc < 0.85:
        notes.append(f"full-length accuracy {acc:.4f} is below 0.85: look at the log before any pilot")
    return {"name": name, "gpu": gpu, "seed": p["seed"], "arm": p["arm"], "ok": not fails, "fails": fails,
            "notes": notes, "facts": facts, "manifest": str(mpath.relative_to(out)), "log_rows": rows}


def compare_pair(a, b):
    res = {"names": [a["name"], b["name"]]}
    fa, fb = a.get("facts", {}), b.get("facts", {})
    if all(isinstance(x.get("accuracy"), (int, float)) for x in (fa, fb)):
        res["accuracy"] = [fa["accuracy"], fb["accuracy"]]
        res["accuracy_diff_points"] = 100 * (fa["accuracy"] - fb["accuracy"])
        res["loss_diff"] = fa["loss"] - fb["loss"]
    ra, rb = a.get("log_rows") or [], b.get("log_rows") or []
    if ra and rb and len(ra) == len(rb):
        res["same_batches"] = all(x[:5] == y[:5] for x, y in zip(ra, rb))
        diffs = [abs(float(x[5]) - float(y[5])) for x, y in zip(ra, rb)]
        res["forward_loss_max_abs_diff"] = max(diffs)
        first = next((i for i, d in enumerate(diffs) if d > 1e-6), None)
        res["first_step_loss_differs_1e-6"] = first
    return res


ARM_ORDER = ["gate_s1_p4", "control_uniform_p4", "gate_loss_p4", "gate_s1inv_p4", "gate_s1_p1",
             "control_uniform_p1", "full_finetune", "reduced_steps", "equal_compute"]
LABEL = {"gate_s1_p4": "A1", "control_uniform_p4": "A2", "gate_loss_p4": "A3", "gate_s1inv_p4": "A4",
         "gate_s1_p1": "A5", "control_uniform_p1": "A6", "full_finetune": "A7", "reduced_steps": "A8",
         "equal_compute": "A9"}


def mean_sd(xs):
    xs = [x for x in xs if isinstance(x, (int, float))]
    if not xs:
        return None, None
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else None
    return m, sd


def reference_runs(ref):
    """The smoke test's seed-11 full-length runs, found inside the reference folder."""
    res = {}
    for smoke_name, arm in (("full_gate_s1_p4", "gate_s1_p4"), ("full_full_finetune_a", "full_finetune")):
        found = sorted((ref / "runs" / smoke_name).rglob("execution_manifest.json"))
        if len(found) == 1:
            m = json.loads(found[0].read_text())
            log = found[0].parent / "batch_log.csv"
            res[arm] = {"smoke_run": smoke_name, "accuracy": (m.get("result") or {}).get("final_eval_accuracy"),
                        "loss": (m.get("result") or {}).get("final_eval_loss"),
                        "rows": read_log(log)[1] if log.is_file() else None}
    return res


CO_PRIMARY = [("C1", "gate_s1_p4", "control_uniform_p4", "S1 P4 - uniform P4"),
              ("C2", "gate_s1_p4", "equal_compute", "S1 P4 - equal-compute")]
SECONDARY = [("A1 - A3", "gate_s1_p4", "gate_loss_p4"), ("A1 - A4", "gate_s1_p4", "gate_s1inv_p4"),
             ("A1 - A5", "gate_s1_p4", "gate_s1_p1"), ("A2 - A6", "control_uniform_p4", "control_uniform_p1"),
             ("A1 - A7", "gate_s1_p4", "full_finetune"), ("A1 - A8", "gate_s1_p4", "reduced_steps"),
             ("A9 - A8", "equal_compute", "reduced_steps"), ("A9 - A7", "equal_compute", "full_finetune")]
BOOT_RESAMPLES = 10000
BOOT_SEED = 20261105


def paired(by, x, y, seeds):
    d = []
    for s in seeds:
        rx, ry = by.get((x, s)), by.get((y, s))
        if rx and ry and rx["ok"] and ry["ok"]:
            d.append((s, 100 * (rx["facts"]["accuracy"] - ry["facts"]["accuracy"])))
    return d


def t_stats(values):
    import numpy as np
    from scipy import stats
    v = np.asarray(values, dtype=float)
    n = len(v)
    res = {"n": n, "mean": float(v.mean()) if n else None}
    if n < 2:
        return res
    sd = float(v.std(ddof=1))
    tq = float(stats.t.ppf(0.975, n - 1))
    se = sd / np.sqrt(n)
    res.update(sd=sd, se=se, t_quantile=tq, ci95=[res["mean"] - tq * se, res["mean"] + tq * se])
    if sd > 0:
        tstat = res["mean"] / se
        res.update(t=float(tstat), p_two_sided=float(2 * stats.t.sf(abs(tstat), n - 1)))
    else:
        res.update(t=None, p_two_sided=1.0 if res["mean"] == 0 else 0.0)
    return res


def bootstrap_ci(values):
    import numpy as np
    v = np.asarray(values, dtype=float)
    if len(v) < 2:
        return None
    rng = np.random.default_rng(BOOT_SEED)
    idx = rng.integers(0, len(v), size=(BOOT_RESAMPLES, len(v)))
    means = v[idx].mean(axis=1)
    return [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]


def holm(pvals):
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    adj, running = [None] * len(pvals), 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(pvals) - rank) * pvals[i]))
        adj[i] = running
    return adj


def reading(ci):
    if ci is None:
        return "not enough seeds"
    lo, hi = ci
    if lo > 0:
        return "entirely above 0: a candidate main claim, to be confirmed in Steps 7-8 on untouched tasks"
    if hi < 0:
        return "entirely below 0: the method loses on this question"
    return "contains 0: inconclusive at this n; Steps 7-8 test it with a preregistered margin"


def reproduction(by, ref_dir, seeds):
    res = {}
    for p in sorted(Path(ref_dir).glob("runs/*_seed*")):
        name = p.name
        arm, _, s = name.rpartition("_seed")
        if not s.isdigit() or int(s) not in seeds:
            continue
        found = sorted(p.rglob("execution_manifest.json"))
        mine = by.get((arm, int(s)))
        if len(found) != 1 or not mine or not mine.get("ok"):
            res[name] = {"comparable": False}
            continue
        m = json.loads(found[0].read_text())
        log = found[0].parent / "batch_log.csv"
        res[name] = {"comparable": True,
                     "same_accuracy": (m.get("result") or {}).get("final_eval_accuracy") == mine["facts"]["accuracy"],
                     "same_batch_log": (read_log(log)[1] if log.is_file() else None) == mine.get("log_rows")}
    return res


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--out", required=True, help="the launcher's --out folder")
    ap.add_argument("--reference", default=None, help="the pilot's folder, for the reproduction of seeds 11, 13, 17")
    ap.add_argument("--expect", action="append", default=[], help="key=value override (tests)")
    a = ap.parse_args()
    for kv in a.expect:
        k, v = kv.split("=", 1)
        EXPECT[k] = v
    out = Path(a.out)
    if not (out / "plan.json").is_file() or not (out / "ledger.jsonl").is_file() or not (out / "DONE.json").is_file():
        print("not a finished launcher folder (plan.json, ledger.jsonl and DONE.json are needed)", file=sys.stderr)
        return 2
    import numpy
    import scipy
    plan = json.loads((out / "plan.json").read_text())["plan"]
    ends = {}
    for line in (out / "ledger.jsonl").read_text().splitlines():
        e = json.loads(line)
        if e.get("event") == "end":
            ends[e["name"]] = e
    runs = []
    for p in plan:
        try:
            r = check_run(p, ends.get(p["name"]), out)
            if p["seed"] not in (11, 13, 17):
                r.pop("log_rows", None)  # only the pilot seeds' logs are compared
            runs.append(r)
        except Exception as e:
            runs.append({"name": p["name"], "seed": p["seed"], "arm": p["arm"], "ok": False,
                         "fails": [f"checker error: {type(e).__name__}: {e}"]})
    by = {(r.get("arm"), r.get("seed")): r for r in runs}
    seeds = sorted({p["seed"] for p in plan})
    lost = {arm: sum(1 for s in seeds if not (by.get((arm, s)) or {}).get("ok")) for arm in ARM_ORDER}
    withheld = any(v > 2 for v in lost.values())
    table = {}
    for arm in ARM_ORDER:
        accs = [100 * by[(arm, s)]["facts"]["accuracy"] for s in seeds if (by.get((arm, s)) or {}).get("ok")]
        walls = [by[(arm, s)]["facts"]["wall_seconds"] for s in seeds if (by.get((arm, s)) or {}).get("ok")]
        fr = []
        for s in seeds:
            r, f = by.get((arm, s)) or {}, by.get(("full_finetune", s)) or {}
            if r.get("ok") and f.get("ok"):
                fr.append(r["facts"]["compute_units_padded"] / f["facts"]["compute_units_padded"])
        m, sd = mean_sd(accs)
        table[arm] = {"label": LABEL[arm], "n": len(accs), "lost_seeds": lost[arm], "mean": m, "sd": sd,
                      "wall_mean": mean_sd(walls)[0], "compute_fraction_mean": mean_sd(fr)[0]}
    analysis = None
    if not withheld:
        co = []
        for cid, x, y, label in CO_PRIMARY:
            d = paired(by, x, y, seeds)
            st = t_stats([v for _, v in d])
            st.update(id=cid, label=label, by_seed=dict(d), bootstrap_ci95=bootstrap_ci([v for _, v in d]))
            co.append(st)
        ps = [c.get("p_two_sided", 1.0) for c in co]
        for c, adj in zip(co, holm(ps)):
            c["p_holm"] = adj
            c["reading"] = reading(c.get("ci95"))
        sec = []
        for label, x, y in SECONDARY:
            d = paired(by, x, y, seeds)
            st = t_stats([v for _, v in d])
            st.update(label=label, arms=[x, y], exploratory=True)
            sec.append(st)
        analysis = {"co_primary": co, "secondary": sec}
    repro = reproduction(by, a.reference, {11, 13, 17}) if a.reference else None
    for r in runs:
        r.pop("log_rows", None)
    rep = {"version": VERSION, "runs_ok": sum(r["ok"] for r in runs), "runs_planned": len(plan),
           "lost_seeds_by_arm": lost, "analysis_withheld": withheld, "table": table, "analysis": analysis,
           "pilot_reproduction": repro, "numpy": numpy.__version__, "scipy": scipy.__version__,
           "runs": runs, "expect": EXPECT}
    (out / "check_report.json").write_text(json.dumps(rep, indent=1, default=str))

    def num(v, fmt):
        return "-" if v is None else format(v, fmt)

    L = [f"MAIN STUDY CHECK ({VERSION}): {rep['runs_ok']} of {len(plan)} runs pass every check"]
    for r in runs:
        if not r["ok"]:
            L.append(f"  FAIL {r['name']} (gpu {r.get('gpu')})")
            for x in r.get("fails", [])[:6]:
                L.append(f"        - {x}")
    L.append("  arms: mean accuracy %, SD, seeds used, measured compute vs full fine-tuning, mean wall seconds")
    for arm in ARM_ORDER:
        t = table[arm]
        L.append(f"  {t['label']} {arm:<20} {num(t['mean'], '.2f')}  sd {num(t['sd'], '.2f')}  n {t['n']}"
                 f"  compute {num(t['compute_fraction_mean'], '.4f')}  wall {num(t['wall_mean'], '.0f')}")
    if withheld:
        L.append("  ANALYSIS WITHHELD: an arm lost more than 2 seeds; review before any analysis (plan section 6)")
    else:
        for c in analysis["co_primary"]:
            L.append(f"  {c['id']} ({c['label']}), n {c['n']}: mean {num(c['mean'], '+.3f')} points,"
                     f" 95% CI [{num((c.get('ci95') or [None, None])[0], '+.3f')}, {num((c.get('ci95') or [None, None])[1], '+.3f')}],"
                     f" bootstrap [{num((c.get('bootstrap_ci95') or [None, None])[0], '+.3f')}, {num((c.get('bootstrap_ci95') or [None, None])[1], '+.3f')}],"
                     f" p {num(c.get('p_two_sided'), '.4f')}, Holm p {num(c.get('p_holm'), '.4f')}")
            L.append(f"      reading: {c['reading']}")
        L.append("  secondary (exploratory, uncorrected): mean points [95% CI]")
        for s in analysis["secondary"]:
            ci = s.get("ci95") or [None, None]
            L.append(f"    {s['label']:<8} {num(s['mean'], '+.3f')} [{num(ci[0], '+.3f')}, {num(ci[1], '+.3f')}]  n {s['n']}")
    if repro is not None:
        same = sum(1 for v in repro.values() if v.get("comparable") and v["same_accuracy"] and v["same_batch_log"])
        L.append(f"  pilot reproduction (seeds 11, 13, 17): {same} of {len(repro)} runs identical in accuracy and batch log")
    (out / "CHECK_SUMMARY.txt").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())

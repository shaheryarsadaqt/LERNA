#!/bin/bash
set -u
export HF_HOME=/raid/hf_cache TORCH_COMPILE_DISABLE=1 TORCHDYNAMO_DISABLE=1 TOKENIZERS_PARALLELISM=false
PY=/home/fy/miniconda3/envs/py310/bin/python3.10
REPO=/home/nanhangproj/LERNA
OUT=/raid/stage2_e3_fixed
LOGDIR=/raid/e3_fixed_logs
cd "$REPO" || exit 1
for spec in "19 4" "37 5" "53 7"; do
  set -- $spec; seed=$1; gpu=$2
  CUDA_VISIBLE_DEVICES=$gpu "$PY" "$REPO/scripts/stage2_confirmatory.py" \
    --seeds "$seed" --single-cell --arm reduced_steps --single-seed "$seed" \
    --score s1 --rate 0.60 --total-steps 258 --reduced-steps 103 \
    --task rte --model jhu-clsp/ettin-encoder-150m --model-rev 45d0864 \
    --output-dir "$OUT/rte" --gpu "$gpu" --post-hoc > "$LOGDIR/rte_${seed}.log" 2>&1
  rc=$?
  [ $rc -ne 0 ] && echo "FAIL rte seed=$seed gpu=$gpu rc=$rc" || echo "OK   rte seed=$seed gpu=$gpu"
done
echo "RERUN DONE"

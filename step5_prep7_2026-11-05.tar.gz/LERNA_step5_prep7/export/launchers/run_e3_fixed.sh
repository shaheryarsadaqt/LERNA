#!/bin/bash
# E3 defect-fix rerun: reduced_steps arms with the correct per-task step budget.
#   MRPC: 151 steps (= 377 - round(0.60*377) backward passes of gate/control)
#   RTE:  103 steps (= 258 - round(0.60*258) backward passes of gate/control)
# 12 seeds x 2 tasks = 24 cells.
set -u
export HF_HOME=/raid/hf_cache
export TORCH_COMPILE_DISABLE=1
export TORCHDYNAMO_DISABLE=1
export TOKENIZERS_PARALLELISM=false
PY=/home/fy/miniconda3/envs/py310/bin/python3.10
REPO=/home/nanhangproj/LERNA
OUT=/raid/stage2_e3_fixed
LOGDIR=/raid/e3_fixed_logs
mkdir -p "$OUT" "$LOGDIR"
cd "$REPO" || exit 1

GPUS=(4 5 7)          # idle V100s
PARALLEL=6            # total concurrent cells (<= 2 per GPU in the common case)
SEEDS="11 13 17 19 23 29 31 37 41 43 47 53"

JOBFILE=/raid/e3_fixed_jobs.txt
: > "$JOBFILE"
i=0
for s in $SEEDS; do echo "mrpc 377 151 $s ${GPUS[$((i % 3))]}" >> "$JOBFILE"; i=$((i+1)); done
for s in $SEEDS; do echo "rte 258 103 $s ${GPUS[$((i % 3))]}" >> "$JOBFILE"; i=$((i+1)); done

run_one() {
  local task="$1" total="$2" steps="$3" seed="$4" gpu="$5"
  CUDA_VISIBLE_DEVICES="$gpu" "$PY" "$REPO/scripts/stage2_confirmatory.py" \
    --seeds "$seed" --single-cell --arm reduced_steps --single-seed "$seed" \
    --score s1 --rate 0.60 --total-steps "$total" --reduced-steps "$steps" \
    --task "$task" --model jhu-clsp/ettin-encoder-150m --model-rev 45d0864 \
    --output-dir "$OUT/$task" --gpu "$gpu" --post-hoc \
    > "$LOGDIR/${task}_${seed}.log" 2>&1
  local rc=$?
  if [ $rc -ne 0 ]; then
    echo "FAIL task=$task seed=$seed gpu=$gpu rc=$rc"
  else
    echo "OK   task=$task seed=$seed gpu=$gpu"
  fi
  return 0
}
export -f run_one
export PY REPO OUT LOGDIR

xargs -a "$JOBFILE" -P "$PARALLEL" -L 1 bash -c 'run_one "$@"' _
echo "ALL DONE"

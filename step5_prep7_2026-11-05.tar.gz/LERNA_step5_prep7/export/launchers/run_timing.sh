#!/bin/bash
# Run timing cells as isolated subprocesses to avoid in-process hangs
cd /home/nanhangproj/LERNA
export HF_HOME=/raid/hf_cache
export TORCH_COMPILE_DISABLE=1
export TORCHDYNAMO_DISABLE=1
export CUDA_VISIBLE_DEVICES=0

SCORE=s1
RATE=0.60
TOTAL_STEPS=6548
MODEL=jhu-clsp/ettin-encoder-150m
MODEL_REV=45d0864
OUTPUT=/raid/stage2_timing
SEEDS="11 13 17"

for seed in $SEEDS; do
  for arm in gate control full_finetune reduced_steps; do
    echo "=== $arm seed=$seed ==="
    /home/fy/miniconda3/envs/py310/bin/python3.10 scripts/stage2_confirmatory.py \
      --score $SCORE --seeds $seed --rate $RATE --total-steps $TOTAL_STEPS \
      --model $MODEL --model-rev $MODEL_REV --output-dir $OUTPUT \
      --single-cell --arm $arm --single-seed $seed --gpu 0
    echo "Done: $arm seed=$seed"
  done
done

echo "=== All timing cells complete ==="

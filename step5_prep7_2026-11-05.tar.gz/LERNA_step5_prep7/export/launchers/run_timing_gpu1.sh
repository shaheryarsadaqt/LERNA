#!/bin/bash
# Run timing cells as isolated subprocesses on GPU 1
cd /home/nanhangproj/LERNA
export HF_HOME=/raid/hf_cache
export TORCH_COMPILE_DISABLE=1
export TORCHDYNAMO_DISABLE=1

SCORE=s1
RATE=0.60
TOTAL_STEPS=6548
MODEL=jhu-clsp/ettin-encoder-150m
MODEL_REV=45d0864
OUTPUT=/raid/stage2_timing
SEEDS="11 13 17"

for seed in $SEEDS; do
  for arm in gate control full_finetune reduced_steps; do
    # Skip if already done
    if [ -f "$OUTPUT/$arm/$seed/results.json" ]; then
      echo "SKIP $arm seed=$seed (already done)"
      continue
    fi
    echo "=== START $arm seed=$seed ==="
    CUDA_VISIBLE_DEVICES=1 /home/fy/miniconda3/envs/py310/bin/python3.10 scripts/stage2_confirmatory.py \
      --score $SCORE --seeds $seed --rate $RATE --total-steps $TOTAL_STEPS \
      --model $MODEL --model-rev $MODEL_REV --output-dir $OUTPUT \
      --single-cell --arm $arm --single-seed $seed --gpu 1
    echo "=== DONE $arm seed=$seed ==="
  done
done

echo "=== All timing cells complete ==="

#!/bin/bash
export HF_HOME=/raid/hf_cache
export TORCH_COMPILE_DISABLE=1
export TORCHDYNAMO_DISABLE=1
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
export PYTHON=/home/fy/miniconda3/envs/py310/bin/python3.10

exec $PYTHON scripts/run_stage2_multi_gpu.py \
  --score s1 \
  --seeds 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97 107 109 113 \
  --rate 0.60 \
  --total-steps 6548 \
  --model jhu-clsp/ettin-encoder-150m \
  --model-rev 45d0864 \
  --n-gpus 8 \
  --output-dir /raid/stage2_confirmatory/

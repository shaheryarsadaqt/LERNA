#!/usr/bin/env python3
"""LERNA Step 5 preparation, round 7: read-only export and environment evidence (5 November 2026).

It writes only into --out, which must not exist. It never writes into the repository or /raid.
Each section is independent: a failure is recorded and the next section still runs. Exit 0
means the report was written, whatever it found; exit 2 means a bad argument or an existing --out.

Sections:
  code_export  the committed text files at HEAD (code, tests, configs, docs), copied byte for
               byte from git into code_HEAD.tar.gz, with a manifest of every tracked file
  launchers    copies of the launcher scripts and launcher logs at the top of /raid
  log_scan     environment prefixes (for example /new_raid/.../conda_envs/lerna) found in the
               text logs under each root, from paths such as <prefix>/lib/python3.10/site-packages

Usage:
  python -s -B LERNA_STEP5_PREP7_EXPORT.py --repo /home/nanhangproj/LERNA --out <new folder>
"""
import argparse
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
import time
from pathlib import Path

VERSION = "LERNA_STEP5_PREP7_EXPORT 2026-11-05"
TEXT_EXT = {".py", ".md", ".txt", ".toml", ".cfg", ".ini", ".yaml", ".yml", ".sh", ".json", ".patch", ".diff",
            ".rst", ".in", ".lock"}
TEXT_NAMES = {"Makefile", "LICENSE", "README", "Dockerfile", ".gitignore", ".gitattributes"}
MAX_FILE = 1_000_000
MAX_JSON = 200_000
MAX_TOTAL = 40_000_000
LAUNCHERS = ["launch_stage2.sh", "run_timing.sh", "run_timing_gpu1.sh", "run_timing_subprocess.sh", "run_e3_fixed.sh",
             "rerun_failed.sh", "e3_fixed_jobs.txt", "stage2_launcher.log", "sst2_launcher.log", "e3_fixed_launcher.log",
             "stage2_timing.log", "stage2_timing_gpu1.log", "stage2_timing_subprocess.log", "stage0_real.log",
             "stage0_debug.log"]
MAX_COPY = 5_000_000
ROOTS = ["/raid/stage0_real", "/raid/stage2_confirmatory", "/raid/stage2_timing", "/raid/stage2_e1", "/raid/stage2_e3",
         "/raid/stage2_e3_fixed", "/raid/e3_fixed_logs", "/raid/sst2_replication", "/raid/smoke_forward_gate_mrpc",
         "/raid/lerna-pilot-plan-output", "/raid/phase1_2_baselines", "/raid/phase1_2_test", "/raid/phase1_2_test2",
         "/raid/phase1_2_test3", "/raid/stage2_lrcheck", "/raid/stage2_calib", "/raid/stage0_smoke", "/raid/sst2_test",
         "/raid/nanhangproj", "/raid/data_modal", "/home/nanhangproj/LERNA/experiments",
         "/home/nanhangproj/LERNA/lerna-pilot-plan-output"]
LOG_EXT = (".log", ".txt", ".out", ".err", ".sh")
MAX_LOG_FILES = 20000
MAX_LOG_READ = 20_000_000
PREFIX = re.compile(r"((?:/[\w.+-]+)+?)/(?:lib/python3\.\d+/site-packages|bin/python(?:3(?:\.\d+)?)?)(?![\w.])")


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def err(e):
    return f"{type(e).__name__}: {e}"


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo, *args, inp=None, timeout=600):
    r = subprocess.run(["git", "-C", str(repo), *args], input=inp, capture_output=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(f"git {' '.join(args[:3])} failed ({r.returncode}): {r.stderr.decode(errors='replace')[:300].strip()}")
    return r.stdout


def wanted(path, size):
    name = path.rsplit("/", 1)[-1]
    ext = os.path.splitext(name)[1].lower()
    if size > MAX_FILE:
        return False, "larger than 1 MB"
    if ext == ".json" and size > MAX_JSON:
        return False, "JSON larger than 200 KB"
    if ext in TEXT_EXT or name in TEXT_NAMES:
        return True, ""
    return False, f"type {ext or name} not exported"


def section_code_export(repo, out):
    head = git(repo, "rev-parse", "HEAD").decode().strip()
    ctime = int(git(repo, "show", "-s", "--format=%ct", "HEAD").decode().strip())
    raw = git(repo, "ls-tree", "-r", "-l", "-z", "HEAD")
    entries = []
    for rec in raw.split(b"\0"):
        if not rec:
            continue
        meta, path = rec.split(b"\t", 1)
        mode, typ, oid, size = meta.split()
        entries.append({"path": path.decode("utf-8", errors="replace"), "mode": mode.decode(), "type": typ.decode(),
                        "blob": oid.decode(), "size": int(size) if size != b"-" else 0})
    total = 0
    chosen = []
    for e in entries:
        if e["type"] != "blob" or e["mode"] == "120000":
            e["exported"], e["reason"] = False, "not a regular file"
            continue
        ok, why = wanted(e["path"], e["size"])
        if ok and total + e["size"] > MAX_TOTAL:
            ok, why = False, "total export cap reached"
        e["exported"], e["reason"] = ok, why
        if ok:
            total += e["size"]
            chosen.append(e)
    data = git(repo, "cat-file", "--batch", inp="".join(e["blob"] + "\n" for e in chosen).encode()) if chosen else b""
    pos = 0
    tar_path = out / "code_HEAD.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tar:
        for e in chosen:
            nl = data.index(b"\n", pos)
            oid, typ, size = data[pos:nl].decode().split()
            size = int(size)
            body = data[nl + 1: nl + 1 + size]
            pos = nl + 1 + size + 1
            if oid != e["blob"] or len(body) != size:
                raise RuntimeError(f"git cat-file returned an unexpected object for {e['path']}")
            if hashlib.sha1(b"blob %d\0" % size + body).hexdigest() != oid:
                raise RuntimeError(f"blob id does not recompute for {e['path']}")
            e["sha256"] = sha256_bytes(body)
            ti = tarfile.TarInfo("LERNA_HEAD/" + e["path"])
            ti.size = size
            ti.mtime = ctime
            ti.mode = 0o755 if e["mode"] == "100755" else 0o644
            tar.addfile(ti, io.BytesIO(body))
    (out / "code_manifest.json").write_text(json.dumps({"head": head, "files": entries}, indent=1))
    skipped = {}
    for e in entries:
        if not e["exported"]:
            skipped[e["reason"]] = skipped.get(e["reason"], 0) + 1
    return {"head": head, "tracked_files": len(entries), "exported_files": len(chosen), "exported_bytes": total,
            "skipped_by_reason": skipped, "tar": tar_path.name, "tar_sha256": sha256_file(tar_path),
            "tar_bytes": tar_path.stat().st_size}


def env_prefixes(text):
    res = {}
    for m in PREFIX.finditer(text):
        p = m.group(1)
        res[p] = res.get(p, 0) + 1
    return res


def section_launchers(raid, out):
    dest = out / "launchers"
    dest.mkdir()
    res = {}
    for name in LAUNCHERS:
        p = Path(raid) / name
        e = {"exists": p.is_file()}
        res[name] = e
        if not e["exists"]:
            continue
        st = p.stat()
        e.update(size=st.st_size, mtime=time.strftime("%Y-%m-%d %H:%M %z", time.localtime(st.st_mtime)), sha256=sha256_file(p))
        with open(p, "rb") as f:
            if st.st_size <= MAX_COPY:
                body = f.read()
            else:
                head = f.read(2_000_000)
                f.seek(st.st_size - 1_000_000)
                body = head + b"\n\n[... middle omitted by the export ...]\n\n" + f.read()
                e["truncated"] = True
        (dest / name).write_bytes(body)
        e["env_prefixes"] = env_prefixes(body.decode("utf-8", errors="replace"))
    return res


def section_log_scan(roots):
    res = {}
    for root in roots:
        r = {"exists": os.path.isdir(root)}
        res[root] = r
        if not r["exists"]:
            continue
        n = 0
        truncated = False
        by = {}
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames.sort()
            for fn in sorted(filenames):
                if not fn.endswith(LOG_EXT):
                    continue
                if n >= MAX_LOG_FILES:
                    truncated = True
                    break
                n += 1
                p = os.path.join(dirpath, fn)
                rel = os.path.relpath(p, root).split(os.sep)
                sub = rel[0] if len(rel) > 1 else "."
                b = by.setdefault(sub, {"files": 0, "prefixes": {}})
                b["files"] += 1
                try:
                    with open(p, "rb") as f:
                        text = f.read(MAX_LOG_READ).decode("utf-8", errors="replace")
                except Exception as e:
                    b.setdefault("errors", []).append(f"{p}: {err(e)}")
                    continue
                for k, v in env_prefixes(text).items():
                    b["prefixes"][k] = b["prefixes"].get(k, 0) + v
            if truncated:
                break
        r.update(log_files=n, truncated=truncated, by_subdir=by)
    return res


def glance(rep):
    L = [f"AT A GLANCE ({VERSION})"]
    c = rep.get("code_export", {})
    if "error" in c:
        L.append(f"code export: {c['error']}")
    elif c:
        L.append(f"code export: HEAD {c['head'][:8]}, {c['exported_files']} of {c['tracked_files']} tracked files "
                 f"({c['exported_bytes']} bytes); {c['tar']} {c['tar_bytes']} bytes, sha256 {c['tar_sha256'][:16]}")
    la = rep.get("launchers", {})
    if "error" in la:
        L.append(f"launchers: {la['error']}")
    else:
        found = [k for k, v in la.items() if v.get("exists")]
        L.append(f"launchers copied: {len(found)} of {len(la)}")
        for k in found:
            pre = la[k].get("env_prefixes") or {}
            L.append(f"   {k}: " + (", ".join(f"{p} x{n}" for p, n in sorted(pre.items())) or "no environment path"))
    ls = rep.get("log_scan", {})
    if "error" in ls:
        L.append(f"log scan: {ls['error']}")
    for root, v in (ls.items() if isinstance(ls, dict) and "error" not in ls else []):
        if not v.get("exists"):
            L.append(f"log scan {root}: missing")
            continue
        tot = {}
        for b in v["by_subdir"].values():
            for p, n in b["prefixes"].items():
                tot[p] = tot.get(p, 0) + n
        L.append(f"log scan {root}: {v['log_files']} files; " + (", ".join(f"{p} x{n}" for p, n in sorted(tot.items())) or "no environment path"))
    if rep.get("section_errors"):
        L.append("section errors: " + ", ".join(sorted(rep["section_errors"])))
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description=VERSION)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--raid", default="/raid")
    ap.add_argument("--roots", nargs="*", default=ROOTS)
    a = ap.parse_args()
    out = Path(a.out).resolve()
    repo = Path(a.repo).resolve()
    if out.exists():
        print(f"--out {out} already exists; choose a new folder", file=sys.stderr)
        return 2
    if repo == out or repo in out.parents:
        print("--out must be outside the repository", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    rep = {"version": VERSION, "started": now(), "argv": sys.argv, "python": sys.executable,
           "script_sha256": sha256_file(Path(__file__).resolve()), "section_errors": {}, "seconds": {}}

    def save():
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))

    def section(name, fn, *args):
        t0 = time.time()
        try:
            rep[name] = fn(*args)
        except Exception as e:
            rep[name] = {"error": err(e)}
            rep["section_errors"][name] = err(e)
        rep["seconds"][name] = round(time.time() - t0, 1)
        save()

    section("code_export", section_code_export, repo, out)
    section("launchers", section_launchers, a.raid, out)
    section("log_scan", section_log_scan, a.roots)
    rep["finished"] = now()
    g = glance(rep)
    rep["glance"] = g
    save()
    (out / "glance.txt").write_text(g + "\n")
    print(g)
    return 0


if __name__ == "__main__":
    sys.exit(main())
